#include "Stdafx.h"
#include "AndroidUserItemSink.h"

//////////////////////////////////////////////////////////////////////////

//����ʱ��
#define TIME_LESS					1									//����ʱ��

//��Ϸʱ��
#define TIME_OUT_CARD				2									//����ʱ��
#define TIME_START_GAME				5									//��ʼʱ��
#define TIME_OPERATE_CARD			3									//����ʱ��
#define TIME_HEAR_STATUS			3									//����ʱ�䰴



//��Ϸʱ��
#define IDI_OUT_CARD				(IDI_ANDROID_ITEM_SINK+0)			//����ʱ��
#define IDI_START_GAME				(IDI_ANDROID_ITEM_SINK+1)			//��ʼʱ��
#define IDI_OPERATE_CARD			(IDI_ANDROID_ITEM_SINK+2)			//����ʱ��
#define IDI_TIMER_DIAOYU_SEL		(IDI_ANDROID_ITEM_SINK+3)			//����ѡ��ʱ��			//����ѡ��ʱ��
#define IDI_TIMER_ADDSCORE_DELAY	(IDI_ANDROID_ITEM_SINK+4)			//������ʱ
#define IDI_TIMER_QUEMEN_SEL		(IDI_ANDROID_ITEM_SINK+5)			//ȱ��ѡ��ʱ��
#define IDI_TIMER_CHANGCARD_SEL		(IDI_ANDROID_ITEM_SINK+6)			//����ѡ��ʱ��
#define IDI_TIMER_AIUSER_HU			(IDI_ANDROID_ITEM_SINK+7)			//AI����ʱ��
#define IDI_TIMER_BAOTING_SEL		(IDI_ANDROID_ITEM_SINK+8)			//����ʱ��
//////////////////////////////////////////////////////////////////////////

//���캯��
CAndroidUserItemSink::CAndroidUserItemSink()
{
	//��Ϸ����
	m_wBankerUser=INVALID_CHAIR;
	m_wCurrentUser=INVALID_CHAIR;

	//״̬����
	m_bHearStatus=false;
	m_bActionMask = WIK_NULL;
	m_cbFirstActionMask = WIK_NULL;
	m_cbActionCard=0;

	//������Ϣ
	m_cbOutCardData=0;
	m_LaiZi = 1;
	m_wOutCardUser=INVALID_CHAIR;
	ZeroMemory(m_cbDiscardCard,sizeof(m_cbDiscardCard));
	ZeroMemory(m_cbDiscardCount,sizeof(m_cbDiscardCount));
	m_cbSendCardData = 0;
	//m_cbTingCardData = 0;

	//����˿�
	ZeroMemory(m_cbWeaveCount,sizeof(m_cbWeaveCount));
	ZeroMemory(m_WeaveItemArray,sizeof(m_WeaveItemArray));
	ZeroMemory(m_cbQueMen,sizeof(m_cbQueMen));

	//�˿˱���
	m_cbLeftCardCount=0;
	ZeroMemory(m_cbCardIndex,sizeof(m_cbCardIndex));
	ZeroMemory(m_cbRepertoryCard,sizeof(m_cbRepertoryCard));
	RepositUserItemSink();
	return;
}

//��������
CAndroidUserItemSink::~CAndroidUserItemSink()
{

}

//�ӿڲ�ѯ
void * __cdecl CAndroidUserItemSink::QueryInterface(REFGUID Guid, DWORD dwQueryVer)
{
	QUERYINTERFACE(IAndroidUserItemSink,Guid,dwQueryVer);
	QUERYINTERFACE_IUNKNOWNEX(IAndroidUserItemSink,Guid,dwQueryVer);
	return NULL;
}

//��ʼ�ӿ�
bool __cdecl CAndroidUserItemSink::InitUserItemSink(IUnknownEx * pIUnknownEx)
{
	//��ѯ�ӿ�
	m_pIAndroidUserItem=QUERY_OBJECT_PTR_INTERFACE(pIUnknownEx,IAndroidUserItem);
	if (m_pIAndroidUserItem==NULL) return false;
	
	return true;
}

//���ýӿ�
bool __cdecl CAndroidUserItemSink::RepositUserItemSink()
{
	//��Ϸ����
	m_wBankerUser=INVALID_CHAIR;
	m_wCurrentUser=INVALID_CHAIR;

	//״̬����
	m_bHearStatus=false;
	m_bActionMask = WIK_NULL;
	m_cbFirstActionMask = WIK_NULL;
	m_cbActionCard=0;

	//������Ϣ
	m_cbOutCardData=0;
	m_wOutCardUser=INVALID_CHAIR;
	ZeroMemory(m_cbDiscardCard,sizeof(m_cbDiscardCard));
	ZeroMemory(m_cbDiscardCount,sizeof(m_cbDiscardCount));
	m_cbSendCardData = 0;

	//����˿�
	ZeroMemory(m_cbWeaveCount,sizeof(m_cbWeaveCount));
	ZeroMemory(m_WeaveItemArray,sizeof(m_WeaveItemArray));
	ZeroMemory(m_cbQueMen,sizeof(m_cbQueMen));

	ZeroMemory(&m_bPiaoQiHasSel,sizeof(m_bPiaoQiHasSel));
	ZeroMemory(&m_bChangCardHasSel,sizeof(m_bChangCardHasSel));
	//�˿˱���
	m_cbLeftCardCount=0;
	ZeroMemory(m_cbCardIndex,sizeof(m_cbCardIndex));
	ZeroMemory(m_cbRepertoryCard,sizeof(m_cbRepertoryCard));
	m_bFirstHearOutCard = true;
	m_bFengZhang = false;
	m_cbAIQueYaojiu = false;
	m_cbJiePeng = false;
	m_bHasOutCard = false;
	m_myLastOutCardData = 0;
	m_cHasAIHupai = false;
	m_bPiaoqi = false;
	return true;
}

//ʱ����Ϣ
bool __cdecl CAndroidUserItemSink::OnEventTimer(UINT nTimerID)
{
	//CString strFile,strTemp;
	/*strFile.Format("log\\CurrentUser.log");

	strTemp.Format("into CurrentUser%d ChairID%d ActionMask%d SendCardData%d OutCardData%d OnEventTimer",m_wCurrentUser,m_pIAndroidUserItem->GetChairID(),m_bActionMask,m_cbSendCardData,m_cbOutCardData);
	WriteLog(strFile, strTemp);*/
	switch (nTimerID)
	{
	case IDI_START_GAME:		//��ʼ��Ϸ
		{
			//��ʼ�ж�
			IServerUserItem * pIServerUserItem=m_pIAndroidUserItem->GetMeUserItem();
			if( pIServerUserItem->GetUserStatus() < US_READY )
			{
				m_pIAndroidUserItem->SendUserReady(NULL,0);
			}
			return true;
		}
	case IDI_OPERATE_CARD:		//������ʱ��
		{
			WORD wMeChair=m_pIAndroidUserItem->GetChairID();
			
			if((m_bActionMask!=WIK_NULL)/*&&(m_wCurrentUser!=m_pIAndroidUserItem->GetChairID())*/)
			{
				if((m_bActionMask&WIK_CHI_HU))
				{
					/*strTemp.Format("into CurrentUser%d ActionMask%d SendCardData%d OutCardData%d OnUserChiHU",m_wCurrentUser,m_bActionMask,m_cbSendCardData,m_cbOutCardData);
					WriteLog(strFile, strTemp);*/
					OnOperateCard(WIK_CHI_HU,0);
					////����
					//strFile.Format("log\\CurrentUser.log");
					//strTemp.Format(" OutWIK_CHI_HU %d table %d\n", wMeChair, m_pIAndroidUserItem->GetTableID());
					//WriteLog(strFile,strTemp);
					return true;
				}
				if(m_bActionMask&WIK_GANG)
				{
					/*strTemp.Format("into CurrentUser%d ActionMask%d SendCardData%d OutCardData%d OnWIK_GANG",m_wCurrentUser,m_bActionMask,m_cbSendCardData,m_cbOutCardData);
					WriteLog(strFile, strTemp);*/
					OnOperateCard(WIK_GANG,0);
					////����
					//strFile.Format("log\\CurrentUser.log");
					//strTemp.Format(" OutWIK_GANG %d table %d\n", wMeChair, m_pIAndroidUserItem->GetTableID());
					//WriteLog(strFile,strTemp);
					return true;
				}
				//�����Ժ���
				
				if((m_bActionMask!=WIK_NULL)&&(m_bHearStatus==false))
				{
					if (m_cbActionCard==0)
					{
						return false;
					}
					WORD cbOperateCode=GetTheBestOperate(m_bActionMask,m_cbActionCard);
					ASSERT( m_cbActionCard!=0xFF);
					ASSERT(m_cbActionCard!=0);
					
					//����Ʊ�������ְ�һ
					int curChairID = m_pIAndroidUserItem->GetChairID();
					int weaveCount = m_cbWeaveCount[curChairID];
					if (weaveCount >= 3)
					{
						//�ж��ǲ���ȫ����
						bool beAllPeng = true;
						for (int i = 0; i < weaveCount; i++)
						{
							WORD cbWeaveKind = m_WeaveItemArray[curChairID][i].cbWeaveKind;
							if ((cbWeaveKind&(WIK_LEFT|WIK_CENTER|WIK_RIGHT))!=0)
							{
								beAllPeng = false;
								break;
							}
						}
						//�������ȫ����
						if (beAllPeng == false || (cbOperateCode != WIK_PENG))
						{
							cbOperateCode = WIK_NULL;
						}
					}
					if(cbOperateCode==WIK_NULL)
						m_cbActionCard=0;
					//OnOperateCard(m_bActionMask,m_cbActionCard);
					/*strTemp.Format("into CurrentUser%d ActionMask%d OperateCode%d SendCardData%d OutCardData%d ActionCard%d OnTheBestOperate",m_wCurrentUser,m_bActionMask,cbOperateCode,m_cbSendCardData,m_cbOutCardData,m_cbActionCard);
					WriteLog(strFile, strTemp);*/
					OnOperateCard(cbOperateCode,m_cbActionCard);
					////����
					//strFile.Format("log\\CurrentUser.log");
					//strTemp.Format(" OutWIK_PEN %d table %d\n", wMeChair, m_pIAndroidUserItem->GetTableID());
					//WriteLog(strFile,strTemp);
				}
				
				if(m_wCurrentUser==wMeChair)
				{
					UINT nElapse = rand()%TIME_OPERATE_CARD+TIME_LESS;
					m_pIAndroidUserItem->SetGameTimer(IDI_OPERATE_CARD,nElapse*1000);
					return true;
				}
			}
			if(m_wCurrentUser==wMeChair)
			{
				if((m_bHearStatus==true))
				{
					BYTE cbCardData=m_cbSendCardData;
					//����Ч��
					if (VerdictOutCard(cbCardData)==false)
					{
						for (BYTE i=0;i<(MAX_INDEX-1);i++)
						{
							//����Ч��
							if (m_cbCardIndex[wMeChair][i]==0) continue;
							if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;

							//���ñ���
							cbCardData=m_GameLogic.SwitchToCardData(i);
							break;
						}
					}
					/*strTemp.Format("into CurrentUser%d ActionMask%d SendCardData%d CardData%d OnUserHearOutCard",m_wCurrentUser,m_bActionMask,m_cbSendCardData,cbCardData);
					WriteLog(strFile, strTemp);*/
					//���ƶ���
					OnOutCard(cbCardData);
					return true;
				}

				//���ܳ���
				BYTE cbCardData=GetIsolatedCard();
				if((cbCardData!=0xFF)&&(m_bHearStatus==false))
				{
					/*strTemp.Format("into CurrentUser%d ActionMask%d SendCardData%d CardData%d OnIsolatedCard",m_wCurrentUser,m_bActionMask,m_cbSendCardData,cbCardData);
					WriteLog(strFile, strTemp);*/
					OnOutCard(cbCardData);
					////����
					//strFile.Format("log\\CurrentUser.log");
					//strTemp.Format(" OutOnOutCard %d table %d\n", m_wCurrentUser, m_pIAndroidUserItem->GetTableID());
					//WriteLog(strFile,strTemp);
					return true;
				}				
				//�쳣����
				if (1)
				{
					for (int i=0;i<27;i++)
					{
						if((m_cbCardIndex[wMeChair][i]==1))
						{
							cbCardData=m_GameLogic.SwitchToCardData(i);
							if (VerdictOutCard(cbCardData)==false)
							{
								for (BYTE i=26;i>=0;i--)
								{
									if (m_cbCardIndex[wMeChair][i]==0) continue;
									if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;
									//���ñ���
									cbCardData=m_GameLogic.SwitchToCardData(i);
									break;
								}
							}
							break;
						}						
					}					
					if (cbCardData == 0xFF)
					{
						for (int i=0;i<27;i++)
						{
							if((m_cbCardIndex[wMeChair][i]>0))
							{
								cbCardData=m_GameLogic.SwitchToCardData(i);
								if (VerdictOutCard(cbCardData)==false)
								{
									for (BYTE i=26;i>=9;i--)
									{
										if (m_cbCardIndex[wMeChair][i]==0) continue;
										if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;
										//���ñ���
										cbCardData=m_GameLogic.SwitchToCardData(i);
										break;
									}
								}
								break;
							}							
						}
					}
					if (cbCardData != 0xFF)
					{
						OnOutCard(cbCardData);							
						return true;
					}
					//else
					//{
					//	for (int i=0;i<MAX_INDEX;i++)
					//	{
					//		if(i>8&&i<27) continue;
					//		if((m_cbCardIndex[wMeChair][i]==1))
					//		{
					//			cbCardData=m_GameLogic.SwitchToCardData(i);
					//			if (VerdictOutCard(cbCardData)==false)
					//			{
					//				for (BYTE i=MAX_INDEX-1;i>=0;i--)
					//				{
					//					if(i>8&&i<18) continue;
					//					if (m_cbCardIndex[wMeChair][i]==0) continue;
					//					if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;
					//					//���ñ���
					//					cbCardData=m_GameLogic.SwitchToCardData(i);
					//					break;
					//				}
					//			}
					//			break;
					//		}							
					//	}
					//	if (cbCardData == 0xFF)
					//	{
					//		for (int i=0;i<MAX_INDEX;i++)
					//		{
					//			if(i>8&&i<27) continue;
					//			if((m_cbCardIndex[wMeChair][i]>0))
					//			{
					//				cbCardData=m_GameLogic.SwitchToCardData(i);
					//				if (VerdictOutCard(cbCardData)==false)
					//				{
					//					for (BYTE i=MAX_INDEX-1;i>=0;i--)
					//					{
					//						if(i>8&&i<18) continue;
					//						if (m_cbCardIndex[wMeChair][i]==0) continue;
					//						if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;
					//						//���ñ���
					//						cbCardData=m_GameLogic.SwitchToCardData(i);
					//						break;
					//					}
					//				}
					//				break;
					//			}								
					//		}
					//	}
					//	if (cbCardData != 0xff)
					//	{
					//		OnOutCard(cbCardData);
					//	}							
					//	return true;
					//}
				}
				//switch(m_cbQueMen[wMeChair])
				//{
				//case 0://MAX_INDEX
				//	#pragma region
				//	for (int i=0;i<9;i++)
				//	{
				//		if((m_cbCardIndex[wMeChair][i]==1))
				//		{
				//			cbCardData=m_GameLogic.SwitchToCardData(i);
				//			if (VerdictOutCard(cbCardData)==false)
				//			{
				//				for (BYTE i=8;i>=0;i--)
				//				{
				//					if (m_cbCardIndex[wMeChair][i]==0) continue;
				//					if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;
				//					//���ñ���
				//					cbCardData=m_GameLogic.SwitchToCardData(i);
				//					break;
				//				}
				//			}
				//			break;
				//		}
				//	}					
				//	if (cbCardData == 0xFF)
				//	{
				//		for (int i=0;i<9;i++)
				//		{
				//			if((m_cbCardIndex[wMeChair][i]>0))
				//			{
				//				cbCardData=m_GameLogic.SwitchToCardData(i);
				//				if (VerdictOutCard(cbCardData)==false)
				//				{
				//					for (BYTE i=8;i>=0;i--)
				//					{
				//						if (m_cbCardIndex[wMeChair][i]==0) continue;
				//						if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;
				//						//���ñ���
				//						cbCardData=m_GameLogic.SwitchToCardData(i);
				//						break;
				//					}
				//				}
				//				break;
				//			}							
				//		}
				//	}
				//	if (cbCardData != 0xFF)
				//	{
				//		OnOutCard(cbCardData);							
				//		return true;
				//	}
				//	else
				//	{
				//		for (int i=9;i<MAX_INDEX;i++)
				//		{
				//			if((m_cbCardIndex[wMeChair][i]==1))
				//			{
				//				cbCardData=m_GameLogic.SwitchToCardData(i);
				//				if (VerdictOutCard(cbCardData)==false)
				//				{
				//					for (BYTE i=MAX_INDEX-1;i>=9;i--)
				//					{
				//						if (m_cbCardIndex[wMeChair][i]==0) continue;
				//						if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;
				//						//���ñ���
				//						cbCardData=m_GameLogic.SwitchToCardData(i);
				//						break;
				//					}
				//				}
				//				break;
				//			}
				//		}
				//		if (cbCardData == 0xFF)
				//		{
				//			for (int i=9;i<MAX_INDEX;i++)
				//			{
				//				if((m_cbCardIndex[wMeChair][i]>0))
				//				{
				//					cbCardData=m_GameLogic.SwitchToCardData(i);
				//					if (VerdictOutCard(cbCardData)==false)
				//					{
				//						for (BYTE i=MAX_INDEX-1;i>=9;i--)
				//						{
				//							if (m_cbCardIndex[wMeChair][i]==0) continue;
				//							if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;
				//							//���ñ���
				//							cbCardData=m_GameLogic.SwitchToCardData(i);
				//							break;
				//						}
				//					}
				//					break;
				//				}
				//				
				//			}
				//		}
				//		if (cbCardData != 0xff)
				//		{
				//			OnOutCard(cbCardData);
				//		}						
				//		return true;
				//	}					
				//	#pragma endregion
				//	break;
				//case 1:
				//	#pragma region
				//	for (int i=9;i<18;i++)
				//	{
				//		if((m_cbCardIndex[wMeChair][i]==1))
				//		{
				//			cbCardData=m_GameLogic.SwitchToCardData(i);
				//			if (VerdictOutCard(cbCardData)==false)
				//			{
				//				for (BYTE i=17;i>=9;i--)
				//				{
				//					if (m_cbCardIndex[wMeChair][i]==0) continue;
				//					if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;
				//					//���ñ���
				//					cbCardData=m_GameLogic.SwitchToCardData(i);
				//					break;
				//				}
				//			}
				//			break;
				//		}						
				//	}					
				//	if (cbCardData == 0xFF)
				//	{
				//		for (int i=9;i<18;i++)
				//		{
				//			if((m_cbCardIndex[wMeChair][i]>0))
				//			{
				//				cbCardData=m_GameLogic.SwitchToCardData(i);
				//				if (VerdictOutCard(cbCardData)==false)
				//				{
				//					for (BYTE i=17;i>=9;i--)
				//					{
				//						if (m_cbCardIndex[wMeChair][i]==0) continue;
				//						if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;
				//						//���ñ���
				//						cbCardData=m_GameLogic.SwitchToCardData(i);
				//						break;
				//					}
				//				}
				//				break;
				//			}							
				//		}
				//	}
				//	if (cbCardData != 0xFF)
				//	{
				//		OnOutCard(cbCardData);							
				//		return true;
				//	}
				//	else
				//	{
				//		for (int i=0;i<MAX_INDEX;i++)
				//		{
				//			if(i>8&&i<18) continue;
				//			if((m_cbCardIndex[wMeChair][i]==1))
				//			{
				//				cbCardData=m_GameLogic.SwitchToCardData(i);
				//				if (VerdictOutCard(cbCardData)==false)
				//				{
				//					for (BYTE i=MAX_INDEX-1;i>=0;i--)
				//					{
				//						if(i>8&&i<18) continue;
				//						if (m_cbCardIndex[wMeChair][i]==0) continue;
				//						if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;
				//						//���ñ���
				//						cbCardData=m_GameLogic.SwitchToCardData(i);
				//						break;
				//					}
				//				}
				//				break;
				//			}							
				//		}
				//		if (cbCardData == 0xFF)
				//		{
				//			for (int i=0;i<MAX_INDEX;i++)
				//			{
				//				if(i>8&&i<18) continue;
				//				if((m_cbCardIndex[wMeChair][i]>0))
				//				{
				//					cbCardData=m_GameLogic.SwitchToCardData(i);
				//					if (VerdictOutCard(cbCardData)==false)
				//					{
				//						for (BYTE i=MAX_INDEX-1;i>=0;i--)
				//						{
				//							if(i>8&&i<18) continue;
				//							if (m_cbCardIndex[wMeChair][i]==0) continue;
				//							if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;
				//							//���ñ���
				//							cbCardData=m_GameLogic.SwitchToCardData(i);
				//							break;
				//						}
				//					}
				//					break;
				//				}								
				//			}
				//		}
				//		if (cbCardData != 0xff)
				//		{
				//			OnOutCard(cbCardData);
				//		}							
				//		return true;
				//	}
				//	#pragma endregion
				//	break;
				//case 2:
				//	#pragma region
				//	for (int i=18;i<27;i++)
				//	{
				//		if((m_cbCardIndex[wMeChair][i]==1))
				//		{
				//			cbCardData=m_GameLogic.SwitchToCardData(i);
				//			if (VerdictOutCard(cbCardData)==false)
				//			{
				//				for (BYTE i=26;i>=18;i--)
				//				{
				//					if (m_cbCardIndex[wMeChair][i]==0) continue;
				//					if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;
				//					//���ñ���
				//					cbCardData=m_GameLogic.SwitchToCardData(i);
				//					break;
				//				}
				//			}
				//			break;
				//		}						
				//	}					
				//	if (cbCardData == 0xFF)
				//	{
				//		for (int i=18;i<27;i++)
				//		{
				//			if((m_cbCardIndex[wMeChair][i]>0))
				//			{
				//				cbCardData=m_GameLogic.SwitchToCardData(i);
				//				if (VerdictOutCard(cbCardData)==false)
				//				{
				//					for (BYTE i=26;i>=18;i--)
				//					{
				//						if (m_cbCardIndex[wMeChair][i]==0) continue;
				//						if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;
				//						//���ñ���
				//						cbCardData=m_GameLogic.SwitchToCardData(i);
				//						break;
				//					}
				//				}
				//				break;
				//			}							
				//		}
				//	}
				//	if (cbCardData != 0xFF)
				//	{
				//		OnOutCard(cbCardData);							
				//		return true;
				//	}
				//	else
				//	{
				//		for (int i=0;i<18;i++)
				//		{
				//			if((m_cbCardIndex[wMeChair][i]==1))
				//			{
				//				cbCardData=m_GameLogic.SwitchToCardData(i);
				//				if (VerdictOutCard(cbCardData)==false)
				//				{
				//					for (BYTE i=17;i>=0;i--)
				//					{
				//						if (m_cbCardIndex[wMeChair][i]==0) continue;
				//						if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;
				//						//���ñ���
				//						cbCardData=m_GameLogic.SwitchToCardData(i);
				//						break;
				//					}
				//				}
				//				break;
				//			}							
				//		}
				//		if (cbCardData == 0xFF)
				//		{
				//			for (int i=0;i<18;i++)
				//			{
				//				if((m_cbCardIndex[wMeChair][i]>0))
				//				{
				//					cbCardData=m_GameLogic.SwitchToCardData(i);
				//					if (VerdictOutCard(cbCardData)==false)
				//					{
				//						for (BYTE i=17;i>=0;i--)
				//						{
				//							if (m_cbCardIndex[wMeChair][i]==0) continue;
				//							if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false)continue;
				//							//���ñ���
				//							cbCardData=m_GameLogic.SwitchToCardData(i);
				//							break;
				//						}
				//					}
				//					break;
				//				}								
				//			}
				//		}
				//		if (cbCardData != 0xff)
				//		{
				//			OnOutCard(cbCardData);
				//		}							
				//		return true;
				//	}
				//	#pragma endregion
				//	break;
				//}
				//����
				/*if (cbCardData==255)
				{
					int i=0;
				}
				strTemp.Format("into CurrentUser%d ActionMask%d SendCardData%d CardData%d On����",m_wCurrentUser,m_bActionMask,m_cbSendCardData,cbCardData);
				WriteLog(strFile, strTemp);*/
				//���ƶ���
				if (cbCardData != 0xff)
				{
					OnOutCard(cbCardData);
				}
				////����
				//strFile.Format("log\\CurrentUser.log");
				//strTemp.Format(" OutOnOutCard %d table %d\n", m_wCurrentUser, m_pIAndroidUserItem->GetTableID());
				//WriteLog(strFile,strTemp);
				return true;

				ASSERT(FALSE);

			}
			return true;
		}
		/*case IDI_TIMER_DIAOYU_SEL:
			{
				int time = rand()%2 == 0 ? 5 : 0;
				CMD_S_DiaoYu diaoYu;
				diaoYu.wChiarID = m_pIAndroidUserItem->GetChairID();
				diaoYu.wAddTimes = time;
				m_pIAndroidUserItem->SendSocketData(SUB_C_DIAOYU_SELECT,&diaoYu,sizeof(diaoYu));
				return true;
			}*/
		case IDI_TIMER_ADDSCORE_DELAY:	//��ʱ����
			{
				//��ʼ�ж�

				//m_pIAndroidUserItem->SetQuickChatEvent(7);
				return true;
			}
		//case IDI_TIMER_QUEMEN_SEL:
		//	{
		//		WORD wChiarID = m_pIAndroidUserItem->GetChairID();
		//		int type = 0;
		//		/*int wanzi=0;
		//		int tiaozi=0;
		//		int tongzi=0;
		//		for (int i=0;i<MAX_INDEX;i++)
		//		{
		//			if (m_cbCardIndex[wChiarID][i]==0)  continue;
		//			if (m_cbCardIndex[wChiarID][i]>0)
		//			{
		//				if (i<9)
		//				    wanzi+=m_cbCardIndex[wChiarID][i];
		//				else if(i>8&&i<18)
		//					tiaozi+=m_cbCardIndex[wChiarID][i];
		//				else if(i>17)
		//					tongzi+=m_cbCardIndex[wChiarID][i];
		//			}
		//		}
		//		if (wanzi==tiaozi && tiaozi==tongzi)
		//			type = rand()%3;
		//		else if( wanzi<=tiaozi && wanzi<=tongzi) 
		//			type = 0;
		//		else if( tiaozi<=wanzi && tiaozi<=tongzi) 
		//			type = 1;
		//		else if( tongzi<=wanzi && tongzi<=tiaozi)
		//			type = 2;*/
		//		if (m_bPiaoqi==false)
		//		{
		//			int randnum = rand()%100;;
		//			if (randnum>=50)
		//				type = 5;
		//		}
		//		else
		//		{
		//			type = 5;
		//		}
		//		CMD_S_PiaoQi piaoqi;
		//		piaoqi.wChiarID = wChiarID;
		//		piaoqi.wSelType = type;
		//		m_cbQueMen[wChiarID] = 0;//type;
		//		m_pIAndroidUserItem->SendSocketData(SUB_C_PIAOQI_SELECT,&piaoqi,sizeof(piaoqi));
		//		return true;
		//	}
		//case IDI_TIMER_CHANGCARD_SEL:
		//	{
		//		WORD wChiarID = m_pIAndroidUserItem->GetChairID();
		//		CMD_S_ChangCard changcard;
		//		BYTE ChooseCount = 0;
		//		changcard.wChiarID = wChiarID;
		//		#pragma region   //ѡ��19���ƻ���������
		//		//ѡ19����
		//		for (int i=0;i<3;i++)
		//		{		
		//			if (ChooseCount>2) break;
		//			if(m_cbCardIndex[wChiarID][i*9]==1)
		//			{
		//				if((m_cbCardIndex[wChiarID][i*9+1]==0)&&(m_cbCardIndex[wChiarID][i*9+2]==0))
		//				{
		//					if (ChooseCount<3)
		//					{
		//						changcard.cbCardData[ChooseCount] = m_GameLogic.SwitchToCardData(i*9);
		//						ChooseCount++;
		//					}								
		//				}
		//			}
		//			if(m_cbCardIndex[wChiarID][i*9+8]==1)
		//			{
		//				if((m_cbCardIndex[wChiarID][i*9+7]==0)&&(m_cbCardIndex[wChiarID][i*9+6]==0))
		//				{
		//					if (ChooseCount<3)
		//					{
		//						changcard.cbCardData[ChooseCount] = m_GameLogic.SwitchToCardData(i*9+8);
		//						ChooseCount++;
		//					}
		//				}
		//			}
		//		}
		//		//û������ʱ��ѡ������ͨ����
		//		for(int i=0; i<27; i++)
		//		{
		//			if (ChooseCount>2) break;						
		//			if(m_cbCardIndex[wChiarID][i]==1)
		//			{
		//				BYTE cbTmp = i%9;
		//				switch(cbTmp)
		//				{
		//				case 0:
		//					if((m_cbCardIndex[wChiarID][i+1]==0)&& (m_cbCardIndex[wChiarID][i+2]==0))
		//					{
		//						int k=0;
		//						for (k=0;k<ChooseCount;k++)
		//						{
		//							if (changcard.cbCardData[k]==m_GameLogic.SwitchToCardData(i))
		//								break;
		//						}
		//						if (k==ChooseCount && ChooseCount<3)
		//						{
		//							changcard.cbCardData[ChooseCount] = m_GameLogic.SwitchToCardData(i);
		//							ChooseCount++;
		//						}								
		//					}
		//					break;
		//				case 1:
		//					if((m_cbCardIndex[wChiarID][i+1]==0)&&(m_cbCardIndex[wChiarID][i+2]==0)
		//						&&(m_cbCardIndex[wChiarID][i-1]==0))
		//					{
		//						int k=0;
		//						for (k=0;k<ChooseCount;k++)
		//						{
		//							if (changcard.cbCardData[k]==m_GameLogic.SwitchToCardData(i))
		//								break;
		//						}
		//						if (k==ChooseCount && ChooseCount<3)
		//						{
		//							changcard.cbCardData[ChooseCount] = m_GameLogic.SwitchToCardData(i);
		//							ChooseCount++;
		//						}
		//					}
		//					break;
		//				case 2:
		//				case 3:
		//				case 4:
		//				case 5:
		//				case 6:
		//					if((m_cbCardIndex[wChiarID][i+1]==0)
		//						&&(m_cbCardIndex[wChiarID][i+2]==0)
		//						&&(m_cbCardIndex[wChiarID][i-1]==0)
		//						&& (m_cbCardIndex[wChiarID][i-2]==0))
		//					{
		//						int k=0;
		//						for (k=0;k<ChooseCount;k++)
		//						{
		//							if (changcard.cbCardData[k]==m_GameLogic.SwitchToCardData(i))
		//								break;
		//						}
		//						if (k==ChooseCount && ChooseCount<3)
		//						{
		//							changcard.cbCardData[ChooseCount] = m_GameLogic.SwitchToCardData(i);
		//							ChooseCount++;
		//						}
		//					}
		//					break;
		//				case 7:
		//					if((m_cbCardIndex[wChiarID][i-1]==0)
		//						&&(m_cbCardIndex[m_pIAndroidUserItem->GetChairID()][i-2]==0)
		//						&&(m_cbCardIndex[m_pIAndroidUserItem->GetChairID()][i+1]==0))
		//					{
		//						int k=0;
		//						for (k=0;k<ChooseCount;k++)
		//						{
		//							if (changcard.cbCardData[k]==m_GameLogic.SwitchToCardData(i))
		//								break;
		//						}
		//						if (k==ChooseCount && ChooseCount<3)
		//						{
		//							changcard.cbCardData[ChooseCount] = m_GameLogic.SwitchToCardData(i);
		//							ChooseCount++;
		//						}
		//					}
		//					break;
		//				case 8:
		//					if((m_cbCardIndex[wChiarID][i-1]==0)
		//						&&(m_cbCardIndex[m_pIAndroidUserItem->GetChairID()][i-2]==0))
		//					{
		//						int k=0;
		//						for (k=0;k<ChooseCount;k++)
		//						{
		//							if (changcard.cbCardData[k]==m_GameLogic.SwitchToCardData(i))
		//								break;
		//						}
		//						if (k==ChooseCount && ChooseCount<3)
		//						{
		//							changcard.cbCardData[ChooseCount] = m_GameLogic.SwitchToCardData(i);
		//							ChooseCount++;
		//						}
		//					}
		//					break;
		//				}
		//				if(cbTmp < 3)
		//				{
		//					i += 5;
		//				}
		//				else
		//				{
		//					i = (i/9+1)*9 - 1;
		//				}
		//			}	
		//		}
		//		//����
		//		//��19����
		//		for(int i=0; i<3; i++)
		//		{
		//			if(ChooseCount>2) break;
		//			if(m_cbCardIndex[wChiarID][i*9] == 1)
		//			{
		//				if(m_cbCardIndex[wChiarID][i*9+1] == 0
		//					|| m_cbCardIndex[wChiarID][i*9+2] == 0)
		//				{
		//					int k=0;
		//					for (k=0;k<ChooseCount;k++)
		//					{
		//						if (changcard.cbCardData[k]==m_GameLogic.SwitchToCardData(i*9))
		//							break;
		//					}
		//					if (k==ChooseCount && ChooseCount<3)
		//					{
		//						changcard.cbCardData[ChooseCount] = m_GameLogic.SwitchToCardData(i*9);
		//						ChooseCount++;
		//					}
		//				}
		//			}
		//			if(m_cbCardIndex[wChiarID][i*9+8] == 1)
		//			{
		//				if(m_cbCardIndex[wChiarID][i*9+7] == 0
		//					|| m_cbCardIndex[wChiarID][i*9+6] == 0)
		//				{
		//					int k=0;
		//					for (k=0;k<ChooseCount;k++)
		//					{
		//						if (changcard.cbCardData[k]==m_GameLogic.SwitchToCardData(i*9+8))
		//							break;
		//					}
		//					if (k==ChooseCount && ChooseCount<3)
		//					{
		//						changcard.cbCardData[ChooseCount] = m_GameLogic.SwitchToCardData(i*9+8);
		//						ChooseCount++;
		//					}
		//				}
		//			}
		//		}
		//		//����ͨ����
		//		for(int i=0; i<27; i++)
		//		{
		//			if(ChooseCount>2) break;
		//			if(m_cbCardIndex[wChiarID][i] == 1)
		//			{
		//				if((i%9) == 0)
		//				{
		//					i += 3;
		//					continue;
		//				}
		//				if((i+1)%9 == 0)
		//				{
		//					continue;
		//				}
		//				if(m_cbCardIndex[wChiarID][i+1] == 0
		//					&& m_cbCardIndex[wChiarID][i-1] == 0)
		//				{
		//					int k=0;
		//					for (k=0;k<ChooseCount;k++)
		//					{
		//						if (changcard.cbCardData[k]==m_GameLogic.SwitchToCardData(i))
		//							break;
		//					}
		//					if (k==ChooseCount && ChooseCount<3)
		//					{
		//						changcard.cbCardData[ChooseCount] = m_GameLogic.SwitchToCardData(i);
		//						ChooseCount++;
		//					}
		//				}
		//				i += 1;
		//			}	
		//		}					
		//		#pragma endregion				
		//		if (ChooseCount>0)
		//		{
		//			changcard.bChangeCard = true;
		//			if (ChooseCount>3)
		//				ChooseCount = 3;
		//			changcard.wAddTimes = ChooseCount;
		//		}
		//		else
		//		{
		//			changcard.bChangeCard = false;
		//			changcard.wAddTimes = 0;
		//		}
		//		m_pIAndroidUserItem->SendSocketData(SUB_C_CHANGCARD_SELECT,&changcard,sizeof(changcard));
		//		return true;
		//	}
		case IDI_TIMER_AIUSER_HU:
			{
				//��������
				CMD_C_HuCard HuCard;
				WORD wChiarID = m_pIAndroidUserItem->GetChairID();
				HuCard.wHuPaiUser=wChiarID;
				m_pIAndroidUserItem->SendSocketData(SUB_C_HU_CARD,&HuCard,sizeof(HuCard));	
				////����
				//CString strFile,strTemp;
				//strFile.Format("log\\CurrentUser.log");
				//strTemp.Format(" operateAIHupai %d table %d\n", wChiarID, m_pIAndroidUserItem->GetTableID());
				//WriteLog(strFile,strTemp);
				return true;
			}
		/*case IDI_TIMER_BAOTING_SEL:
			{
				if((m_bActionMask&WIK_CHI_HU)!=WIK_NULL)
				{
					OnOperateCard(WIK_CHI_HU,0);
					return true;
				}
				if((m_bActionMask&WIK_LISTEN)!=WIK_NULL &&(m_bHearStatus==false))
				{
					CMD_S_BaoTing wBaoTing;
					WORD wChiarID = m_pIAndroidUserItem->GetChairID();
					wBaoTing.wChiarID=wChiarID;
					wBaoTing.bBaoting = true;
					if( !m_pIAndroidUserItem->SendSocketData(SUB_C_LISTEN_CARD,&wBaoTing,sizeof(wBaoTing)))
					{
						ASSERT( FALSE );
						return false;
					}
				}
				else if((m_bActionMask&WIK_LISTEN)==WIK_NULL)
				{
					CMD_S_BaoTing wBaoTing;
					WORD wChiarID = m_pIAndroidUserItem->GetChairID();
					wBaoTing.wChiarID=wChiarID;
					wBaoTing.bBaoting = false;
					if( !m_pIAndroidUserItem->SendSocketData(SUB_C_LISTEN_CARD,&wBaoTing,sizeof(wBaoTing)))
					{
						ASSERT( FALSE );
						return false;
					}
				}
				return true;
			}*/
	}

	return false;
}

//��Ϸ��Ϣ
bool __cdecl CAndroidUserItemSink::OnEventGameMessage(WORD wSubCmdID, void * pData, WORD wDataSize)
{
	//test
	if (DEF_TEST)
	{
		WORD wMeChairId = m_pIAndroidUserItem->GetChairID();
		if ((wSubCmdID == SUB_S_OUT_CARD ||
			wSubCmdID == SUB_S_SEND_CARD ||
			wSubCmdID == SUB_S_OPERATE_NOTIFY ||
			wSubCmdID == SUB_S_OPERATE_RESULT ||
			wSubCmdID == SUB_S_GAME_END) 	
			/*&& m_wBankerUser != wMeChairId*/)
		{
			return true;
		}
	}
	//end
	switch (wSubCmdID)
	{
	case SUB_S_GAME_START:		//��Ϸ��ʼ
		{
			return OnSubGameStart(pData,wDataSize);
		}
	case SUB_S_OUT_CARD:		//�û�����
		{
			return OnSubOutCard(pData,wDataSize);
		}
	case SUB_S_SEND_CARD:		//������Ϣ
		{
			return OnSubSendCard(pData,wDataSize);
		}
	case SUB_S_OPERATE_NOTIFY:	//������ʾ
		{
			return OnSubOperateNotify(pData,wDataSize);
		}
	case SUB_S_OPERATE_RESULT:	//�������
		{
			return OnSubOperateResult(pData,wDataSize);
		}
	case SUB_S_LISTEN_CARD:		//����
		{
			return OnSubListenCard(pData,wDataSize);
		}
	case SUB_S_GAME_END:		//��Ϸ����
		{
			return OnSubGameEnd(pData,wDataSize);
		}
	case SUB_S_QIANG_GANG:		//��Ϸ����
		{
			return OnSubQiangGang(pData,wDataSize);
		}
	case SUB_S_START_DIAOYU:
		{
			return OnSubStartDiaoYu(pData,wDataSize);
		}
	case SUB_S_START_ANI_FINISH:
		{
			return OnSubStartAniFinish(pData,wDataSize);//true;//
		}
	case SUB_S_USER_HUPAI:
		{
			return OnSubHUPAI(pData,wDataSize);
		}
	case SUB_S_START_PIAOQI:
		{
			return OnSubStartPiaoQiSelect(pData,wDataSize);
		}
	case SUB_S_PIAOQI:
		{
			return OnSubQueMenSelect(pData,wDataSize);
		}
		/*case SUB_S_START_CHANGCARD:
		{
		return OnSubStartChangCardSelect(pData,wDataSize);
		}*/
	case SUB_S_CHANGCARD:
		{
			return OnSubChangCardSelect(pData,wDataSize);
		}
	case SUB_S_CHANGCARD_END:
		{
			return true;//OnSubChangCardSelectEnd(pData,wDataSize);
		}
	case SUB_S_GAME_SEND_LASTCARD:		//��Ϸ��ʼ
		{
			return OnSubGameLastcard(pData,wDataSize);
		}
	case SUB_S_BAOTING:
		{
			return OnSubBaoTingSelect(pData,wDataSize);
		}
	}

	return true;
}

//��Ϸ��Ϣ
bool __cdecl CAndroidUserItemSink::OnEventFrameMessage(WORD wSubCmdID, void * pData, WORD wDataSize)
{
	return true;
}

//������Ϣ
bool __cdecl CAndroidUserItemSink::OnEventGameScene(BYTE cbGameStatus, bool bLookonOther, void * pData, WORD wDataSize)
{
	switch (cbGameStatus)
	{
	case GS_MJ_FREE:	//����״̬
		{
			//Ч������
			if (wDataSize!=sizeof(CMD_S_StatusFree)) return false;
			CMD_S_StatusFree * pStatusFree=(CMD_S_StatusFree *)pData;
			IServerUserItem * pIServerUserItem=m_pIAndroidUserItem->GetMeUserItem();

			//��������
			m_wBankerUser=pStatusFree->wBankerUser;
			m_LaiZi = pStatusFree->nLaiZi;
			if( pIServerUserItem->GetUserStatus() != US_READY )
			{
				/*if(m_pIAndroidUserItem->GetIsQueueUser())
				{
					m_pIAndroidUserItem->SendUserReady(NULL, 0);
				}
				else*/
				{				
					UINT nElapse = rand()%TIME_START_GAME+TIME_LESS;
					//if (pIServerUserItem->GetAndroidPlayInTableCount() > 1)
					{
						m_pIAndroidUserItem->SetGameTimer(IDI_START_GAME,nElapse*1000);
					}
				}
			}
			return true;
		}
	case GS_MJ_PLAY:	//��Ϸ״̬
		{
			//Ч������
			if (wDataSize!=sizeof(CMD_S_StatusPlay)) return false;
			CMD_S_StatusPlay * pStatusPlay=(CMD_S_StatusPlay *)pData;

			//���ñ���
			m_wBankerUser=pStatusPlay->wBankerUser;
			m_wCurrentUser=pStatusPlay->wCurrentUser;
			m_cbLeftCardCount=pStatusPlay->cbLeftCardCount;

			////����״̬
			//WORD wMeChairID=m_pIAndroidUserItem->GetChairID();
			//m_bHearStatus=(pStatusPlay->cbHearStatus[wMeChairID]==TRUE)?true:false;

			//��ʷ����
			m_wOutCardUser=pStatusPlay->wOutCardUser;
			m_cbOutCardData=pStatusPlay->cbOutCardData;
			CopyMemory(m_cbDiscardCard,pStatusPlay->cbDiscardCard,sizeof(m_cbDiscardCard));
			CopyMemory(m_cbDiscardCount,pStatusPlay->cbDiscardCount,sizeof(m_cbDiscardCount));

			//�˿˱���
			CopyMemory(m_cbWeaveCount,pStatusPlay->cbWeaveCount,sizeof(m_cbWeaveCount));
			CopyMemory(m_WeaveItemArray,pStatusPlay->WeaveItemArray,sizeof(m_WeaveItemArray));
			//CopyMemory(m_cbQueMen,pStatusPlay->m_bQuemen,sizeof(m_cbQueMen));
			m_GameLogic.SwitchToCardIndex(pStatusPlay->cbCardData,pStatusPlay->cbCardCount,m_cbCardIndex[m_pIAndroidUserItem->GetChairID()]);

			//��������
			if ((pStatusPlay->cbActionMask!=WIK_NULL))
			{
				UINT nElapse = rand()%TIME_OPERATE_CARD+TIME_LESS;
				m_pIAndroidUserItem->SetGameTimer(IDI_OPERATE_CARD,nElapse*1000);
			}
			if (m_wCurrentUser==m_pIAndroidUserItem->GetChairID()) 
			{
				{
					UINT nElapse = rand()%TIME_OPERATE_CARD+TIME_LESS;
					m_pIAndroidUserItem->SetGameTimer(IDI_OPERATE_CARD,nElapse*1000);
				}

			}

			return true;
		}
	}

	return false;
}

//�û�����
void __cdecl CAndroidUserItemSink::OnEventUserEnter(IAndroidUserItem * pIAndroidUserItem, bool bLookonUser)
{
	return;
}

//�û��뿪
void __cdecl CAndroidUserItemSink::OnEventUserLeave(IAndroidUserItem * pIAndroidUserItem, bool bLookonUser)
{
	return;
}

//�û�����
void __cdecl CAndroidUserItemSink::OnEventUserScore(IAndroidUserItem * pIAndroidUserItem, bool bLookonUser)
{
	return;
}

//�û�״̬
void __cdecl CAndroidUserItemSink::OnEventUserStatus(IAndroidUserItem * pIAndroidUserItem, bool bLookonUser)
{
	return;
}

//�û���λ
void __cdecl CAndroidUserItemSink::OnEventUserSegment(IAndroidUserItem * pIAndroidUserItem, bool bLookonUser)
{
	return;
}

//ׯ����Ϣ
bool CAndroidUserItemSink::OnSubGameStart(void * pData, WORD wDataSize)
{
	//Ч������
	ASSERT(wDataSize==sizeof(CMD_S_GameStart));
	if (wDataSize!=sizeof(CMD_S_GameStart)) return false;

	//��������
	CMD_S_GameStart * pGameStart=(CMD_S_GameStart *)pData;

	//����״̬
	m_pIAndroidUserItem->SetGameStatus(GS_MJ_PLAY);
	m_bPiaoqi = false;
	//���ñ���
	m_bHearStatus=false;
	m_wBankerUser=pGameStart->wBankerUser;
	m_wCurrentUser=pGameStart->wCurrentUser;
	m_cbLeftCardCount=MAX_REPERTORY-GAME_PLAYER*(MAX_COUNT-1)-1;
	m_bActionMask = WIK_NULL;
	m_cbFirstActionMask = WIK_NULL;
	m_cbActionCard = 0;

	//������Ϣ
	m_cbOutCardData=0;
	m_wOutCardUser=INVALID_CHAIR;
	ZeroMemory(m_cbDiscardCard,sizeof(m_cbDiscardCard));
	ZeroMemory(m_cbDiscardCount,sizeof(m_cbDiscardCount));
	//m_cbSendCardData = 0;

	//����˿�
	ZeroMemory(m_cbWeaveCount,sizeof(m_cbWeaveCount));
	ZeroMemory(m_WeaveItemArray,sizeof(m_WeaveItemArray));
	//�����˿�
	WORD wMeChairId = m_pIAndroidUserItem->GetChairID();
	BYTE cbCardCount = (wMeChairId==m_wBankerUser)?MAX_COUNT:(MAX_COUNT-1);
	m_GameLogic.SwitchToCardIndex(pGameStart->cbCardData,cbCardCount,m_cbCardIndex[wMeChairId]);
	m_cbQueMen[wMeChairId] = pGameStart->cbQuemen;
	
	//��������
	if ((pGameStart->cbUserAction!=WIK_NULL) || pGameStart->wCurrentUser==m_pIAndroidUserItem->GetChairID())
	{
		m_bActionMask = pGameStart->cbUserAction;
		//UINT nElapse = rand()%TIME_OPERATE_CARD+TIME_LESS;
		//m_pIAndroidUserItem->SetGameTimer(IDI_OPERATE_CARD,(3+nElapse)*1000);
	}

	return true;
}

//��Ϸ����
bool CAndroidUserItemSink::OnSubGameEnd(void * pData, WORD wDataSize)
{
	//Ч������
	ASSERT(wDataSize==sizeof(CMD_S_GameEnd));
	if (wDataSize!=sizeof(CMD_S_GameEnd)) return false;

	
	//��Ϣ����
	CMD_S_GameEnd * pGameEnd=(CMD_S_GameEnd *)pData;

	//����״̬
	m_pIAndroidUserItem->SetGameStatus(GS_MJ_FREE);

	//ɾ����ʱ��
	m_pIAndroidUserItem->KillGameTimer(IDI_OPERATE_CARD);
	m_pIAndroidUserItem->KillGameTimer(IDI_TIMER_ADDSCORE_DELAY);

	//����	
	/*UINT nElapse = rand()%TIME_START_GAME+TIME_LESS+2;
	m_pIAndroidUserItem->SetGameTimer(IDI_START_GAME,nElapse*1000);*/
	RepositUserItemSink();
	return true;
}
	//��Ϸ����
bool CAndroidUserItemSink::OnSubHUPAI(void * pData, WORD wDataSize)
{
	//Ч������
	ASSERT(wDataSize==sizeof(CMD_S_HuPai));
	if (wDataSize!=sizeof(CMD_S_HuPai)) return false;

	m_cHasAIHupai = true;
	//��Ϣ����
	CMD_S_HuPai * pHuPai=(CMD_S_HuPai *)pData;

	////����״̬
	//m_pIAndroidUserItem->SetGameStatus(GS_MJ_FREE);

	//ɾ����ʱ��
	m_pIAndroidUserItem->KillGameTimer(IDI_OPERATE_CARD);
	m_pIAndroidUserItem->KillGameTimer(IDI_TIMER_ADDSCORE_DELAY);

	//����	
	if (pHuPai->winChairID==m_pIAndroidUserItem->GetChairID() && pHuPai->m_cbOperateOther==false)
	{
		UINT nElapse = 2;
		m_pIAndroidUserItem->SetGameTimer(IDI_TIMER_AIUSER_HU,nElapse*1000);
	}
	
	/*RepositUserItemSink();*/
	return true;
}




//������ʾ
bool CAndroidUserItemSink::OnSubOperateNotify( const void *pBuffer,WORD wDataSize )
{
	//Ч������
	ASSERT(wDataSize==sizeof(CMD_S_OperateNotify));
	if (wDataSize!=sizeof(CMD_S_OperateNotify)) return false;

	//��������
	CMD_S_OperateNotify * pOperateNotify=(CMD_S_OperateNotify *)pBuffer;

	//�û�����
	if ((pOperateNotify->cbActionMask!=WIK_NULL))
	{
		//��ȡ����
		WORD wMeChairID=m_pIAndroidUserItem->GetChairID();
		m_bActionMask = pOperateNotify->cbActionMask;
		m_cbActionCard=pOperateNotify->cbActionCard;
		if (m_cbActionCard==0)
		{
			return false;
		}
		////���� ����
		//if ((cbActionMask&WIK_QIANG_GANG)!=0 && (cbActionMask&WIK_PENG)!=0)
		//{
		//	//m_GameClientView.m_drawQiangPeng = true;
		//	//m_GameClientView.m_ControlWnd.m_cbUserQiangGang = true;
		//	//m_GameClientView.m_curOptCartoonPos = m_GameClientView.m_optCartoonPos[SwitchViewChairID(pOperateNotify->wResumeUser)];
		//	//m_GameClientView.m_hanimGang->setPosition(m_GameClientView.m_curOptCartoonPos.x,m_GameClientView.m_curOptCartoonPos.y);
		//	////��
		//	//if (!m_GameClientView.m_hanimGang->IsPlaying())
		//	//{
		//	//	m_GameClientView.m_hanimGang->Play();
		//	//	/*m_GameClientView.PlayRoleHeadAct(wOperateViewID, role_act_glad);*/
		//	//}
		//	//m_pITableFrame->SendTableData(pOperateNotify->wResumeUser,SUB_S_OPERATE_NOTIFY,&pOperateNotify,sizeof(pOperateNotify));
		//}
		//����ʱ��
		UINT nElapse = rand()%TIME_OPERATE_CARD+TIME_LESS;
		m_pIAndroidUserItem->SetGameTimer(IDI_OPERATE_CARD,nElapse*1000);
	}
	else
	{
		m_pIAndroidUserItem->SetGameTimer(IDI_TIMER_ADDSCORE_DELAY,6000);
	}

	return true;
}

//
bool CAndroidUserItemSink::OnSubOperateResult( const void *pBuffer,WORD wDataSize )
{
	//Ч����Ϣ
	ASSERT(wDataSize==sizeof(CMD_S_OperateResult));
	if (wDataSize!=sizeof(CMD_S_OperateResult)) return false;

	//��Ϣ����
	CMD_S_OperateResult * pOperateResult=(CMD_S_OperateResult *)pBuffer;
	
	//��������
	BYTE cbPublicCard=TRUE;
	WORD wOperateUser=pOperateResult->wOperateUser;
	BYTE cbOperateCard=pOperateResult->cbOperateCard;

	//���Ʊ���
	if (pOperateResult->cbOperateCode!=WIK_NULL)
	{
		m_cbOutCardData=0;
		m_wOutCardUser=INVALID_CHAIR;
	}

	//��������
	m_bActionMask = WIK_NULL;
	//m_cbFirstActionMask = WIK_NULL;
	m_cbActionCard =0;
	m_pIAndroidUserItem->KillGameTimer(IDI_OPERATE_CARD);
	m_pIAndroidUserItem->KillGameTimer(IDI_TIMER_ADDSCORE_DELAY);

	//�������
	switch (pOperateResult->cbOperateCode)
	{
	//case WIK_SPE_YAOGANG:		//������Ʋ���
	//case WIK_SPE_JIUGANG:		//������Ʋ���
	//case WIK_SPE_FENGGANG:		//������Ʋ���
	//case WIK_SPE_BAIGANG:		//������Ʋ���
	//	{
	//		//��������
	//		BYTE cbWeaveIndex=0xFF;
	//		BYTE cbCardIndex=m_GameLogic.SwitchToCardIndex(pOperateResult->cbOperateCard);
	//		WORD cbWeaveKindType=0;
	//		m_wCurrentUser=INVALID_CHAIR;
	//		//BYTE cbWeaveOldCount=m_cbWeaveCount[wOperateUser];
	//		//Ѱ����ϣ�����
	//		for (BYTE i=0;i<m_cbWeaveCount[wOperateUser];i++)
	//		{
	//			WORD cbWeaveKind=m_WeaveItemArray[wOperateUser][i].cbWeaveKind;
	//			if (cbWeaveKind==WIK_SPE_YAOGANG)
	//			{
	//				if (0==cbCardIndex)
	//				{
	//					m_WeaveItemArray[wOperateUser][i].cbCardIndex[0]++;
	//					//ɾ���˿�
	//					m_cbCardIndex[wOperateUser][cbCardIndex]--;
	//					cbWeaveIndex=i;
	//					cbWeaveKindType|=WIK_SPE_YAOGANG;
	//					break;
	//				}
	//				if (9==cbCardIndex)
	//				{
	//					m_WeaveItemArray[wOperateUser][i].cbCardIndex[1]++;
	//					//ɾ���˿�
	//					m_cbCardIndex[wOperateUser][cbCardIndex]--;
	//					cbWeaveIndex=i;
	//					cbWeaveKindType|=WIK_SPE_YAOGANG;
	//					break;
	//				}
	//				if (18==cbCardIndex)
	//				{
	//					m_WeaveItemArray[wOperateUser][i].cbCardIndex[2]++;
	//					//ɾ���˿�
	//					m_cbCardIndex[wOperateUser][cbCardIndex]--;
	//					cbWeaveIndex=i;
	//					cbWeaveKindType|=WIK_SPE_YAOGANG;
	//					break;
	//				}
	//			}
	//			if (cbWeaveKind==WIK_SPE_JIUGANG)
	//			{
	//				if (8==cbCardIndex)
	//				{
	//					m_WeaveItemArray[wOperateUser][i].cbCardIndex[0]++;
	//					//ɾ���˿�
	//					m_cbCardIndex[wOperateUser][cbCardIndex]--;
	//					cbWeaveIndex=i;
	//					cbWeaveKindType|=WIK_SPE_JIUGANG;
	//					break;
	//				}
	//				if (17==cbCardIndex)
	//				{
	//					m_WeaveItemArray[wOperateUser][i].cbCardIndex[1]++;
	//					//ɾ���˿�
	//					m_cbCardIndex[wOperateUser][cbCardIndex]--;
	//					cbWeaveIndex=i;
	//					cbWeaveKindType|=WIK_SPE_JIUGANG;
	//					break;
	//				}
	//				if (26==cbCardIndex)
	//				{
	//					m_WeaveItemArray[wOperateUser][i].cbCardIndex[2]++;
	//					//ɾ���˿�
	//					m_cbCardIndex[wOperateUser][cbCardIndex]--;
	//					cbWeaveIndex=i;
	//					cbWeaveKindType|=WIK_SPE_JIUGANG;
	//					break;
	//				}
	//			}
	//			if (cbWeaveKind==WIK_SPE_FENGGANG)
	//			{
	//				if (27==cbCardIndex)
	//				{
	//					m_WeaveItemArray[wOperateUser][i].cbCardIndex[0]++;
	//					//ɾ���˿�
	//					m_cbCardIndex[wOperateUser][cbCardIndex]--;
	//					cbWeaveIndex=i;
	//					cbWeaveKindType|=WIK_SPE_FENGGANG;
	//					break;
	//				}
	//				if (28==cbCardIndex)
	//				{
	//					m_WeaveItemArray[wOperateUser][i].cbCardIndex[1]++;
	//					//ɾ���˿�
	//					m_cbCardIndex[wOperateUser][cbCardIndex]--;
	//					cbWeaveIndex=i;
	//					cbWeaveKindType|=WIK_SPE_FENGGANG;
	//					break;
	//				}
	//				if (29==cbCardIndex)
	//				{
	//					m_WeaveItemArray[wOperateUser][i].cbCardIndex[2]++;
	//					//ɾ���˿�
	//					m_cbCardIndex[wOperateUser][cbCardIndex]--;
	//					cbWeaveIndex=i;
	//					cbWeaveKindType|=WIK_SPE_FENGGANG;
	//					break;
	//				}
	//				if (30==cbCardIndex)
	//				{
	//					m_WeaveItemArray[wOperateUser][i].cbCardIndex[3]++;
	//					//ɾ���˿�
	//					m_cbCardIndex[wOperateUser][cbCardIndex]--;
	//					cbWeaveIndex=i;
	//					cbWeaveKindType|=WIK_SPE_FENGGANG;
	//					break;
	//				}
	//			}
	//			if (cbWeaveKind==WIK_SPE_BAIGANG)
	//			{
	//				if (31==cbCardIndex)
	//				{
	//					m_WeaveItemArray[wOperateUser][i].cbCardIndex[0]++;
	//					//ɾ���˿�
	//					m_cbCardIndex[wOperateUser][cbCardIndex]--;
	//					cbWeaveIndex=i;
	//					cbWeaveKindType|=WIK_SPE_BAIGANG;
	//					break;
	//				}
	//				if (32==cbCardIndex)
	//				{
	//					m_WeaveItemArray[wOperateUser][i].cbCardIndex[1]++;
	//					//ɾ���˿�
	//					m_cbCardIndex[wOperateUser][cbCardIndex]--;
	//					cbWeaveIndex=i;
	//					cbWeaveKindType|=WIK_SPE_BAIGANG;
	//					break;
	//				}
	//				if (33==cbCardIndex)
	//				{
	//					m_WeaveItemArray[wOperateUser][i].cbCardIndex[2]++;
	//					//ɾ���˿�

	//					m_cbCardIndex[wOperateUser][cbCardIndex]--;
	//					cbWeaveIndex=i;
	//					cbWeaveKindType|=WIK_SPE_BAIGANG;
	//					break;
	//				}
	//			}
	//		}

	//		//�����
	//		if (cbWeaveIndex==0xFF)
	//		{
	//			switch(pOperateResult->cbOperateCode)
	//			{
	//			case WIK_SPE_YAOGANG:
	//				{
	//					//���ñ���
	//					m_wCurrentUser=pOperateResult->wOperateUser;
	//					cbWeaveIndex=m_cbWeaveCount[wOperateUser]++;
	//					ZeroMemory(m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex,sizeof(m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex));
	//					m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex[0]++;
	//					m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex[1]++;
	//					m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex[2]++;

	//					m_cbCardIndex[wOperateUser][0]--;
	//					m_cbCardIndex[wOperateUser][9]--;
	//					m_cbCardIndex[wOperateUser][18]--;
	//					cbWeaveKindType|=WIK_SPE_YAOGANG;
	//				}
	//				break;
	//			case WIK_SPE_JIUGANG:
	//				{
	//					//���ñ���
	//					m_wCurrentUser=pOperateResult->wOperateUser;
	//					cbWeaveIndex=m_cbWeaveCount[wOperateUser]++;
	//					ZeroMemory(m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex,sizeof(m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex));
	//					m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex[0]++;
	//					m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex[1]++;
	//					m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex[2]++;

	//					m_cbCardIndex[wOperateUser][8]--;
	//					m_cbCardIndex[wOperateUser][17]--;
	//					m_cbCardIndex[wOperateUser][26]--;
	//					cbWeaveKindType|=WIK_SPE_JIUGANG;
	//				}
	//				break;
	//			case WIK_SPE_FENGGANG:
	//				{
	//					cbWeaveIndex=m_cbWeaveCount[wOperateUser]++;
	//					ZeroMemory(m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex,sizeof(m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex));
	//					m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex[0]++;
	//					m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex[1]++;
	//					m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex[2]++;
	//					m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex[3]++;
	//					m_cbCardIndex[wOperateUser][27]--;
	//					m_cbCardIndex[wOperateUser][28]--;
	//					m_cbCardIndex[wOperateUser][29]--;
	//					m_cbCardIndex[wOperateUser][30]--;

	//					cbWeaveKindType|=WIK_SPE_FENGGANG;
	//				}
	//				break;
	//			case WIK_SPE_BAIGANG:
	//				{
	//					//���ñ���
	//					m_wCurrentUser=pOperateResult->wOperateUser;
	//					cbWeaveIndex=m_cbWeaveCount[wOperateUser]++;
	//					ZeroMemory(m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex,sizeof(m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex));
	//					m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex[0]++;
	//					m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex[1]++;
	//					m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCardIndex[2]++;

	//					m_cbCardIndex[wOperateUser][31]--;
	//					m_cbCardIndex[wOperateUser][32]--;
	//					m_cbCardIndex[wOperateUser][33]--;
	//					cbWeaveKindType|=WIK_SPE_BAIGANG;
	//				}
	//				break;
	//			}
	//		}
	//		//����˿�

	//		//�����ж�
	//		cbPublicCard=TRUE;

	//		//�����˿�
	//		m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbPublicCard=cbPublicCard;
	//		m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCenterCard=cbOperateCard;
	//		m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbWeaveKind=pOperateResult->cbOperateCode;
	//		m_WeaveItemArray[wOperateUser][cbWeaveIndex].wProvideUser=pOperateResult->wProvideUser;
	//	}
	//	break;
	case WIK_GANG:			//���Ʋ���
		{
			//���ñ���
			m_wCurrentUser=INVALID_CHAIR;

			//����˿�
			BYTE cbWeaveIndex=0xFF;
			for (BYTE i=0;i<m_cbWeaveCount[wOperateUser];i++)
			{
				WORD cbWeaveKind=m_WeaveItemArray[wOperateUser][i].cbWeaveKind;
				BYTE cbCenterCard=m_WeaveItemArray[wOperateUser][i].cbCenterCard;
				if ((cbCenterCard==cbOperateCard)&&(cbWeaveKind==WIK_PENG))
				{
					cbWeaveIndex=i;
					m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbPublicCard=TRUE;
					m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbWeaveKind=pOperateResult->cbOperateCode;
					m_WeaveItemArray[wOperateUser][cbWeaveIndex].wProvideUser=pOperateResult->wProvideUser;
					break;
				}
			}

			//����˿�
			if (cbWeaveIndex==0xFF)
			{
				//�����ж�
				cbPublicCard=(pOperateResult->wProvideUser==wOperateUser)?FALSE:TRUE;

				//�����˿�
				cbWeaveIndex=m_cbWeaveCount[wOperateUser]++;
				m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbPublicCard=cbPublicCard;
				m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCenterCard=cbOperateCard;
				m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbWeaveKind=pOperateResult->cbOperateCode;
				m_WeaveItemArray[wOperateUser][cbWeaveIndex].wProvideUser=pOperateResult->wProvideUser;
			}

			//�˿�����
			if(wOperateUser==m_pIAndroidUserItem->GetChairID())
				m_cbCardIndex[wOperateUser][m_GameLogic.SwitchToCardIndex(pOperateResult->cbOperateCard)]=0;
		}
		break;
	default:
		{
			//���ñ���
			m_wCurrentUser=pOperateResult->wOperateUser;

			//�������
			BYTE cbWeaveIndex=m_cbWeaveCount[wOperateUser]++;
			m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbPublicCard=TRUE;
			m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbCenterCard=cbOperateCard;
			m_WeaveItemArray[wOperateUser][cbWeaveIndex].cbWeaveKind=pOperateResult->cbOperateCode;
			m_WeaveItemArray[wOperateUser][cbWeaveIndex].wProvideUser=pOperateResult->wProvideUser;

			//��Ͻ���
			BYTE cbWeaveCard[4]={0,0,0,0},cbWeaveKind=pOperateResult->cbOperateCode;
			BYTE cbWeaveCardCount=m_GameLogic.GetWeaveCard(cbWeaveKind,cbOperateCard,cbWeaveCard);


			//ɾ���˿�
			if(wOperateUser==m_pIAndroidUserItem->GetChairID())
			{
				m_GameLogic.RemoveCard(cbWeaveCard,cbWeaveCardCount,&cbOperateCard,1);
				m_GameLogic.RemoveCard(m_cbCardIndex[wOperateUser],cbWeaveCard,cbWeaveCardCount-1);
			}
		}
	}

	if (/*pOperateResult->cbOperateCode == WIK_SPE_YAOGANG ||
		pOperateResult->cbOperateCode == WIK_SPE_JIUGANG || 
		pOperateResult->cbOperateCode == WIK_SPE_FENGGANG || 
		pOperateResult->cbOperateCode == WIK_SPE_BAIGANG || */
		pOperateResult->cbOperateCode == WIK_GANG)
	{
		/*if (m_wCurrentUser==m_pIAndroidUserItem->GetChairID())
		{
			m_pIAndroidUserItem->SetQuickChatEvent(7);
		}
		else
		{
			m_pIAndroidUserItem->SetQuickChatEvent(5);
		}*/
	}

	//����ʱ��
	if (m_wCurrentUser==m_pIAndroidUserItem->GetChairID())
	{
		//BYTE cbChiHuRight=0;
		////WORD cbActionMask=m_GameLogic.AnalyseTingCard(m_cbCardIndex[m_pIAndroidUserItem->GetChairID()],m_WeaveItemArray[m_pIAndroidUserItem->GetChairID()],m_cbWeaveCount[m_pIAndroidUserItem->GetChairID()],cbChiHuRight);
		//WORD cbActionMask=NULL;
		//if((cbActionMask==WIK_LISTEN)&&(m_bHearStatus==false))
		//{
		//	if( !m_pIAndroidUserItem->SendSocketData(SUB_C_LISTEN_CARD))
		//	{
		//		ASSERT( FALSE );
		//		return false;
		//	}

		//	m_bHearStatus=true;
		//}
		m_bHasOutCard = false;
		//����ʱ��
		UINT nElapse=rand()%TIME_OPERATE_CARD+TIME_LESS;
		if ((m_bHearStatus==true)) 
			nElapse=rand()%TIME_HEAR_STATUS+TIME_LESS;
		//ASSERT(FALSE);

		//����ʱ��
		m_pIAndroidUserItem->SetGameTimer(IDI_OPERATE_CARD,nElapse*1000);
	}

	return true;
}

//
bool CAndroidUserItemSink::OnSubOutCard( const void *pBuffer,WORD wDataSize )
{
	//Ч����Ϣ
	ASSERT(wDataSize==sizeof(CMD_S_OutCard));
	if (wDataSize!=sizeof(CMD_S_OutCard)) return false;

	//��Ϣ����
	CMD_S_OutCard * pOutCard=(CMD_S_OutCard *)pBuffer;

	//��������
	WORD wMeChairID=m_pIAndroidUserItem->GetChairID();

	//���ñ���
	m_wCurrentUser=INVALID_CHAIR;
	m_wOutCardUser=pOutCard->wOutCardUser;
	ASSERT( pOutCard->cbOutCardData != 0 );
	m_cbOutCardData=pOutCard->cbOutCardData;

	//�ر�˵��ʱ��
	m_pIAndroidUserItem->KillGameTimer(IDI_TIMER_ADDSCORE_DELAY);

	if ((pOutCard->wOutCardUser==wMeChairID))
	{
		//����ͻ���û����
		if (m_bHasOutCard == false && m_myLastOutCardData != pOutCard->cbOutCardData)
		{
			//���ñ���
			m_wCurrentUser=INVALID_CHAIR;
			m_bHasOutCard = true;
			m_GameLogic.RemoveCard(m_cbCardIndex[wMeChairID],pOutCard->cbOutCardData);

			//���ý���
			m_pIAndroidUserItem->KillGameTimer(IDI_OPERATE_CARD);
			m_cbSendCardData=0;
			//���ñ���
			m_bActionMask = WIK_NULL;
			m_cbFirstActionMask = WIK_NULL;
			

		}
	}
	//m_cbFirstActionMask = WIK_NULL;
	m_myLastOutCardData = 0;
	m_cbJiePeng = false;
	if (m_bFirstHearOutCard == true && m_bHearStatus == true && (pOutCard->wOutCardUser==wMeChairID))
	{
		m_bFirstHearOutCard = false;
	}
	return true;
}

//
bool CAndroidUserItemSink::OnSubSendCard( const void *pBuffer,WORD wDataSize )
{
	//Ч������
	ASSERT(wDataSize==sizeof(CMD_S_SendCard));
	if (wDataSize!=sizeof(CMD_S_SendCard)) return false;

	//��������
	CMD_S_SendCard * pSendCard=(CMD_S_SendCard *)pBuffer;
	m_bFengZhang = pSendCard->bFengZhang;
	//���ñ���
	WORD wMeChairID=m_pIAndroidUserItem->GetChairID();
	m_wCurrentUser=pSendCard->wCurrentUser;

	//�����˿�
	if ((m_wOutCardUser!=INVALID_CHAIR)&&(m_cbOutCardData!=0) && !m_cHasAIHupai)
	{
		//�����˿�
		m_cbDiscardCard[m_wOutCardUser][m_cbDiscardCount[m_wOutCardUser]++] = m_cbOutCardData;
		//���ñ���
		m_cbOutCardData=0;
		m_wOutCardUser=INVALID_CHAIR;
	}
	m_cHasAIHupai = false;
	//���ƴ���
	if ((pSendCard->cbCardData!=0)&&((m_wCurrentUser==wMeChairID)))
	{
		m_cbCardIndex[m_wCurrentUser][m_GameLogic.SwitchToCardIndex(pSendCard->cbCardData)]++;	
		//�۳��˿�
		m_cbLeftCardCount--;

	}

	//��ǰ�û�
	if ((m_wCurrentUser==wMeChairID))
	{
		m_cbSendCardData = pSendCard->cbCardData;
		//m_cbAICardColorCount = pSendCard->cbAICardColorCount;
		//m_cbAIQueYaojiu = pSendCard->cbAIQueYaojiu;
		//m_cbJiePeng = pSendCard->cbJiePeng;
		m_bHasOutCard = false;
	}

	//����ʱ��
	if( wMeChairID == m_wCurrentUser )
	{
		m_bActionMask = pSendCard->cbActionMask;

		//�Ȳ�������
		//if((m_bActionMask&WIK_LISTEN)&&(m_bHearStatus==false))
		//{
		//	if( !m_pIAndroidUserItem->SendSocketData(SUB_C_LISTEN_CARD))
		//	{
		//		ASSERT( FALSE );
		//		return false;
		//	}
		//}
		//����ʱ��
		UINT nElapse=rand()%TIME_OPERATE_CARD+TIME_LESS;
		if ((m_bHearStatus==true)&&(m_wCurrentUser==wMeChairID)) 
			nElapse=1;
		/*CString strFile,strTemp;
		strFile.Format("log\\CurrentUser.log");

		strTemp.Format("into CurrentUser%d MeChairID%d ActionMask%d SendCardData%d OnUserAndSendCard",m_wCurrentUser,wMeChairID,m_bActionMask,m_cbSendCardData);
		WriteLog(strFile, strTemp);*/
		//test
		//return true;
		//end
		m_pIAndroidUserItem->SetGameTimer(IDI_OPERATE_CARD,nElapse*1000);
	}
	if( wMeChairID != m_wCurrentUser )
	{
		m_pIAndroidUserItem->SetGameTimer(IDI_TIMER_ADDSCORE_DELAY,6000);
	}
	
	return true;
}
//�û�����
bool CAndroidUserItemSink::OnSubListenCard(const void * pBuffer, WORD wDataSize)
{
	//Ч������
	ASSERT(wDataSize==sizeof(CMD_S_ListenCard));
	if (wDataSize!=sizeof(CMD_S_ListenCard)) return false;

	//��������
	
	CMD_S_ListenCard * pListenCard=(CMD_S_ListenCard *)pBuffer;	
	if (pListenCard->wbListen)
	{
		if(pListenCard->wListenUser==m_pIAndroidUserItem->GetChairID())
		{
			m_bHearStatus=true;		
		}
	}
	
	return true;

}

bool CAndroidUserItemSink::OnSubQiangGang(const void * pBuffer,WORD wDataSize)
{
	//Ч������
	ASSERT(wDataSize==sizeof(CMD_S_QiangGang));
	if (wDataSize!=sizeof(CMD_S_QiangGang)) 
		return false;

	//��������
	CMD_S_QiangGang * pQiangGang=(CMD_S_QiangGang *)pBuffer;
	//if (GetMeChairID()==wOperateUser)
	if (pQiangGang->wResumeUser == m_pIAndroidUserItem->GetChairID())
	{
		//m_cbCardIndex[pQiangGang->wResumeUser][m_GameLogic.SwitchToCardIndex(pQiangGang->cbActionCard)]--;	
		m_wCurrentUser=INVALID_CHAIR;
		WORD wMeChairId = m_pIAndroidUserItem->GetChairID();
		m_GameLogic.RemoveCard(m_cbCardIndex[wMeChairId],pQiangGang->cbActionCard);
	}
	return true;
}

bool CAndroidUserItemSink::OnSubStartDiaoYu(const void * pBuffer,WORD wDataSize)
{

	UINT nElapse = rand()%3+1;
	m_pIAndroidUserItem->SetGameTimer(IDI_TIMER_DIAOYU_SEL,nElapse*1000);
	return true;
}
bool CAndroidUserItemSink::OnSubBaoTingSelect(const void * pBuffer,WORD wDataSize)
{

	//Ч������
	ASSERT(wDataSize==sizeof(CMD_S_BaoTing));
	if (wDataSize!=sizeof(CMD_S_BaoTing)) return false;

	//��������
	CMD_S_BaoTing * pOperateNotify=(CMD_S_BaoTing *)pBuffer;

	//�û�����
	//if ((pOperateNotify->cbActionMask!=WIK_NULL))
	{
		//��ȡ����
		WORD wMeChairID=m_pIAndroidUserItem->GetChairID();
		m_bActionMask = pOperateNotify->cbActionMask;
		//����ʱ��
		UINT nElapse = rand()%TIME_OPERATE_CARD+TIME_LESS;
		m_pIAndroidUserItem->SetGameTimer(IDI_TIMER_BAOTING_SEL,nElapse*1000);
	}
	/*else
	{
		m_pIAndroidUserItem->SetGameTimer(IDI_TIMER_ADDSCORE_DELAY,4000);
	}*/

	return true;
}

bool CAndroidUserItemSink::OnSubStartPiaoQiSelect(const void * pBuffer,WORD wDataSize)
{
	//Ч������
	ASSERT(wDataSize==sizeof(CMD_S_PiaoQiStart));
	if (wDataSize!=sizeof(CMD_S_PiaoQiStart)) 
		return false;
	//��������
	CMD_S_PiaoQiStart * pDiaoYuStart=(CMD_S_PiaoQiStart *)pBuffer;
	WORD wMeChair = m_pIAndroidUserItem->GetChairID();
	m_bPiaoqi = false;
	if (pDiaoYuStart->bPiaoqi[wMeChair])
	{
		m_bPiaoqi = true;
	}
	UINT nElapse = rand()%3+1;
	m_pIAndroidUserItem->SetGameTimer(IDI_TIMER_QUEMEN_SEL,nElapse*1000);
	return true;
}
bool CAndroidUserItemSink::OnSubQueMenSelect(const void * pBuffer,WORD wDataSize)
{	
	//Ч������
	ASSERT(wDataSize==sizeof(CMD_S_PiaoQi));
	if (wDataSize!=sizeof(CMD_S_PiaoQi)) 
		return false;
	////��������
	CMD_S_PiaoQi * piaoqi=(CMD_S_PiaoQi *)pBuffer;	
	WORD dateNum = piaoqi->wSelType;
	if (dateNum>=10)
	{		
		if (piaoqi->wChiarID==m_pIAndroidUserItem->GetChairID())
		{
			/*if (m_bPiaoQiHasSel[pQueMen->wChiarID] == true)
			{
				return false;
			}
			m_bPiaoQiHasSel[pQueMen->wChiarID] = true;*/
			m_cbQueMen[piaoqi->wChiarID] = dateNum%10;
			/*CMD_S_PiaoQi quemen;
			quemen.wChiarID = pQueMen->wChiarID;
			quemen.wSelType = dateNum%10;
			m_pIAndroidUserItem->SendSocketData(SUB_C_PIAOQI_SELECT,&quemen,sizeof(quemen));*/
		}		
	} 
	else if (m_wCurrentUser==m_pIAndroidUserItem->GetChairID() )
	{
		////Ч������
		//ASSERT(wDataSize==sizeof(CMD_S_PiaoQi));
		//if (wDataSize!=sizeof(CMD_S_PiaoQi)) 
		//	return false;
		////��������
		//CMD_S_PiaoQi * pQueMen=(CMD_S_PiaoQi *)pBuffer;		
		if (m_bPiaoQiHasSel[piaoqi->wChiarID] == true)
		{
			return false;
		}
		m_bPiaoQiHasSel[piaoqi->wChiarID] = true;

		for (int i = 0; i < GAME_PLAYER; i++)
		{
			if (m_bPiaoQiHasSel[i] == false)
			{
				return true;
			}
		}	
		/*UINT nElapse = rand()%TIME_OPERATE_CARD+TIME_LESS;
		m_pIAndroidUserItem->SetGameTimer(IDI_OPERATE_CARD,(nElapse)*1000);*/
	}
	
	return true;
}
bool CAndroidUserItemSink::OnSubStartChangCardSelect(const void * pBuffer,WORD wDataSize)
{
	UINT nElapse = rand()%4+2;
	m_pIAndroidUserItem->SetGameTimer(IDI_TIMER_CHANGCARD_SEL,nElapse*1000);
	return true;
}
bool CAndroidUserItemSink::OnSubChangCardSelect(const void * pBuffer,WORD wDataSize)
{	
	//Ч������
	ASSERT(wDataSize==sizeof(CMD_S_ChangCard));
	if (wDataSize!=sizeof(CMD_S_ChangCard)) 
		return false;		
	//��������
	CMD_S_ChangCard * pChangCard=(CMD_S_ChangCard *)pBuffer;
	if (/*m_wCurrentUser*/pChangCard->wChiarID==m_pIAndroidUserItem->GetChairID())
	{
		////Ч������
		//ASSERT(wDataSize==sizeof(CMD_S_ChangCard));
		//if (wDataSize!=sizeof(CMD_S_ChangCard)) 
		//	return false;		
		////��������
		//CMD_S_ChangCard * pChangCard=(CMD_S_ChangCard *)pBuffer;
		if (pChangCard->bChangeCardEnd)
		{
			if (m_bChangCardHasSel[pChangCard->wChiarID] == true)
			{
				return false;
			}
			m_bChangCardHasSel[pChangCard->wChiarID] = true;
			//if (pChangCard->wChiarID==m_pIAndroidUserItem->GetChairID())
			{
				if(pChangCard->bChangeCard)
				{
					for (int j=0;j<pChangCard->wAddTimes;j++)
					{					
						m_cbCardIndex[pChangCard->wChiarID][m_GameLogic.SwitchToCardIndex(pChangCard->cbCardData[j])]++;
					}
				}	
			}					
			for (int i = 0; i < GAME_PLAYER; i++)
			{
				if (m_bChangCardHasSel[i] == false)
				{
					return true;
				}
			}
		}
		else
		{
			if (pChangCard->wChiarID==m_pIAndroidUserItem->GetChairID())
			{
				if(pChangCard->bChangeCard)
				{
					for (int i=0;i<pChangCard->wAddTimes;i++)
					{
						m_GameLogic.RemoveCard(m_cbCardIndex[pChangCard->wChiarID],pChangCard->cbCardData[i]);
					}
				}
			}
			return true;
		}
		
	}	
	return true;
}
bool CAndroidUserItemSink::OnSubGameLastcard(const void * pBuffer,WORD wDataSize)
{
	//Ч������
	ASSERT(wDataSize==sizeof(CMD_S_GameLastCard));
	if (wDataSize!=sizeof(CMD_S_GameLastCard)) 
		return false;
	//��������
	CMD_S_GameLastCard * pGameLastCard=(CMD_S_GameLastCard *)pBuffer;
	//���ñ���
	WORD wMeChairID=m_pIAndroidUserItem->GetChairID();
	m_wCurrentUser=pGameLastCard->wCurrentUser;
	/*if (wMeChairID==m_wBankerUser)
	{
		m_cbCardIndex[m_wCurrentUser][m_GameLogic.SwitchToCardIndex(pGameLastCard->cbCardData)]++;
	}*/
	UINT nElapse = rand()%TIME_OPERATE_CARD+TIME_LESS;
	//��������
	if ((pGameLastCard->cbUserAction!=WIK_NULL) || pGameLastCard->wCurrentUser==m_pIAndroidUserItem->GetChairID())
	{
		m_bActionMask = pGameLastCard->cbUserAction;

		if(m_bHearStatus==true)
		{
			//�������ҳ������Ƶ���
			BYTE cbCardData = 0;
			for (BYTE i=9;i<MAX_INDEX;i++)
			{
				//����Ч��
				if (m_cbCardIndex[m_wCurrentUser][i]==0) continue;
				if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false) 
					continue;
				//���ñ���
				cbCardData=m_GameLogic.SwitchToCardData(i);
				break;
			}
			m_cbSendCardData = cbCardData;
			nElapse=0;
		}
		/*UINT nElapse = rand()%TIME_OPERATE_CARD+TIME_LESS;*/
		m_pIAndroidUserItem->SetGameTimer(IDI_OPERATE_CARD,(2+nElapse)*1000);
	}

	return true;
}
bool CAndroidUserItemSink::OnSubChangCardSelectEnd(const void * pBuffer,WORD wDataSize)
{
	//if (m_wCurrentUser==m_pIAndroidUserItem->GetChairID() )
	//{
	//	//Ч������
	//	ASSERT(wDataSize==sizeof(CMD_S_END_ChangCard));
	//	if (wDataSize!=sizeof(CMD_S_END_ChangCard)) 
	//		return false;
	//	//��������
	//	CMD_S_END_ChangCard * pChangCardEnd=(CMD_S_END_ChangCard *)pBuffer;
	//	/*if (pChangCardEnd->bChangeCardEnd)
	//	{
	//		UINT nElapse = rand()%TIME_OPERATE_CARD+TIME_LESS;
	//		m_pIAndroidUserItem->SetGameTimer(IDI_OPERATE_CARD,(nElapse)*1000);
	//	}*/
	//}
	return true;
}
//�ͻ��˶�������
bool CAndroidUserItemSink::OnSubStartAniFinish(const void * pBuffer,WORD wDataSize)
{
	if (m_wCurrentUser==m_pIAndroidUserItem->GetChairID() )
	{
		UINT nElapse = rand()%TIME_OPERATE_CARD+TIME_LESS;
		m_pIAndroidUserItem->SetGameTimer(IDI_OPERATE_CARD,(nElapse)*1000);
	}
	return true;
}

//�û�����
void CAndroidUserItemSink::OnOutCard( BYTE cbOutCard )
{
	//���Ų�������
	if (m_bFengZhang)
	{
		return;
	}
	if (cbOutCard==0||cbOutCard==0xff)
	{
		return;
	}
	//����Ѿ����ƾͲ��ܻ���	!m_bFirstHearOutCard ��ʾ���ǵ�һ�����ƺ����
	if (!m_bFirstHearOutCard)
	{
		//��������õ����Ʋ��ܳ�
		if (cbOutCard != m_cbSendCardData)
		{
			return;
		}

		//����Ч��
		if (VerdictOutCard(m_cbSendCardData)==false)
		{
			return;
		}
	}
	WORD wMeChairId = m_pIAndroidUserItem->GetChairID();
	//�����ж�
	if (((m_bHearStatus==true))&&(VerdictOutCard(cbOutCard)==false))
	{
		m_bFirstHearOutCard = false;
		for (BYTE i=0;i<MAX_INDEX;i++)
		{
			//����Ч��
			if (m_cbCardIndex[wMeChairId][i]==0) continue;
			if (VerdictOutCard(m_GameLogic.SwitchToCardData(i))==false) 
				continue;
			//���ñ���
			cbOutCard=m_GameLogic.SwitchToCardData(i);
			break;
		}
		//InsertSystemString(TEXT("�����Ʋ�������Ϸ����!"));
		//int i=0;
		//return;
	}
	//���ñ���
	m_wCurrentUser=INVALID_CHAIR;
	
	m_GameLogic.RemoveCard(m_cbCardIndex[wMeChairId],cbOutCard);

	//���ý���
	m_pIAndroidUserItem->KillGameTimer(IDI_OPERATE_CARD);
	m_cbSendCardData=0;
	//���ñ���
	m_bActionMask = WIK_NULL;
	m_cbFirstActionMask = WIK_NULL;
	m_bHasOutCard = true;
	m_myLastOutCardData = cbOutCard;

	//��������
	CMD_C_OutCard OutCard;
	OutCard.cbCardData=cbOutCard;
	if( !m_pIAndroidUserItem->SendSocketData(SUB_C_OUT_CARD,&OutCard,sizeof(OutCard)) )
	{
		ASSERT( FALSE );
		return ;
	}


	
	return ;
}

//
void CAndroidUserItemSink::OnOperateCard( WORD cbOperateCode,BYTE cbOperateCard )
{
	//ɾ��ʱ��
	m_pIAndroidUserItem->KillGameTimer(IDI_OPERATE_CARD);

	//��������
	tagGangCardResult GangCardResult;
	ZeroMemory(&GangCardResult,sizeof(GangCardResult));

	WORD cbAtionMask=0;
	BYTE cbCardData=0;
	cbAtionMask=cbOperateCode;
	//��ȡ����
	if (m_wCurrentUser==m_pIAndroidUserItem->GetChairID())
	{
		WORD wMeChairID=m_pIAndroidUserItem->GetChairID();
		BYTE cbWeaveCount=m_cbWeaveCount[wMeChairID];
		
		/*if (cbOperateCode&WIK_SHOU_GANG)
		{
			cbAtionMask=m_GameLogic.AnalyseAndroidFirstGangCard(m_cbCardIndex[wMeChairID],m_WeaveItemArray[wMeChairID],cbWeaveCount,GangCardResult);
			cbCardData=GangCardResult.cbCardData[GangCardResult.cbCardCount-1][0];
			m_cbFirstActionMask |= cbAtionMask ;
		}*/
		if (cbOperateCode&WIK_GANG)
		{
			m_GameLogic.AnalyseGangCard(m_cbCardIndex[wMeChairID],m_WeaveItemArray[wMeChairID],cbWeaveCount,GangCardResult,m_cbQueMen[wMeChairID],m_cbSendCardData);
			cbAtionMask=cbOperateCode;
			cbCardData=GangCardResult.cbCardData[0][0];
			if (cbCardData==0)
			{
				return;
			}
		}
		/*if (((cbOperateCode&WIK_SPE_YAOGANG)!=0)||((cbOperateCode&WIK_SPE_JIUGANG)!=0)||((cbOperateCode&WIK_SPE_FENGGANG)!=0)||((cbOperateCode&WIK_SPE_BAIGANG)!=0))
		{
			m_GameLogic.AnalyseAndroidZuHeSpeGangCard(m_cbCardIndex[wMeChairID],m_WeaveItemArray[wMeChairID],cbWeaveCount,GangCardResult);
			cbAtionMask=GangCardResult.cbGangType;
			cbCardData=GangCardResult.cbCardData[0][0];
		}*/
		
	}
	else
	{
		GangCardResult.cbCardCount=1;
		GangCardResult.cbCardData[0][0]=m_cbActionCard;
		cbCardData=GangCardResult.cbCardData[0][0];
		

	}
	//��������
	m_bActionMask = WIK_NULL;
	//m_cbFirstActionMask = WIK_NULL;
	//��������
	CMD_C_OperateCard OperateCard;
	OperateCard.cbOperateCode=cbAtionMask;
	OperateCard.cbOperateCard=cbCardData;
	if( !m_pIAndroidUserItem->SendSocketData(SUB_C_OPERATE_CARD,&OperateCard,sizeof(OperateCard)) )
	{
		ASSERT( FALSE );
		return ;
	}
	return ;
}
//���ܴ���
BYTE CAndroidUserItemSink::GetIsolatedCard()
{	
	//�������
	WORD wMeChairID=m_pIAndroidUserItem->GetChairID();

	BYTE byTmpCard[MAX_INDEX] = {0};
	CopyMemory(byTmpCard, m_cbCardIndex[wMeChairID], sizeof(byTmpCard));
	//////////////////////////////////////////////////////////////////////////	junji 2015-11-2
	BYTE byResult = m_GameLogic.GetIsolatedCard(byTmpCard);
	if ((byResult >= 0x01) && (byResult <= 0x29))return byResult;
	//////////////////////////////////////////////////////////////////////////

	switch(0/*m_cbQueMen[wMeChairID]*/)
	{
	case 0:	
		//��������
		/*for(int i=0; i<9; i++)
		{
			if(m_cbCardIndex[wMeChairID][i]>0)
			{
				return m_GameLogic.SwitchToCardData(i);
			}
		}*/
		//û������ʱ��������19����
		for (int i=0;i<3;i++)
		{			
			if(m_cbCardIndex[wMeChairID][i*9]==1)
			{
				if((m_cbCardIndex[wMeChairID][i*9+1]==0)
					&&(m_cbCardIndex[wMeChairID][i*9+2]==0))
				{
					return m_GameLogic.SwitchToCardData(i*9);
				}
			}
			if(m_cbCardIndex[wMeChairID][i*9+8]==1)
			{
				if((m_cbCardIndex[wMeChairID][i*9+7]==0)
					&&(m_cbCardIndex[wMeChairID][i*9+6]==0))
				{
					return m_GameLogic.SwitchToCardData(i*9+8);
				}
			}
		}
		//û������ʱ����������ͨ����
		for(int i=0; i<27; i++)
		{
			if(m_cbCardIndex[wMeChairID][i]==1)
			{
				BYTE cbTmp = i%9;
				switch(cbTmp)
				{
				case 0:
					if((m_cbCardIndex[wMeChairID][i+1]==0)
						&& (m_cbCardIndex[wMeChairID][i+2]==0))
					{
						return m_GameLogic.SwitchToCardData(i);
					}
					break;
				case 1:
					if((m_cbCardIndex[wMeChairID][i+1]==0)
						&&(m_cbCardIndex[wMeChairID][i+2]==0)
						&&(m_cbCardIndex[wMeChairID][i-1]==0))
					{
						return m_GameLogic.SwitchToCardData(i);
					}
					break;
				case 2:
				case 3:
				case 4:
				case 5:
				case 6:
					if((m_cbCardIndex[wMeChairID][i+1]==0)
						&&(m_cbCardIndex[wMeChairID][i+2]==0)
						&&(m_cbCardIndex[wMeChairID][i-1]==0)
						&& (m_cbCardIndex[wMeChairID][i-2]==0))
					{
						return m_GameLogic.SwitchToCardData(i);
					}
					break;
				case 7:
					if((m_cbCardIndex[wMeChairID][i-1]==0)
						&&(m_cbCardIndex[m_pIAndroidUserItem->GetChairID()][i-2]==0)
						&&(m_cbCardIndex[m_pIAndroidUserItem->GetChairID()][i+1]==0))
					{
						return m_GameLogic.SwitchToCardData(i);
					}
					break;
				case 8:
					if((m_cbCardIndex[wMeChairID][i-1]==0)
						&&(m_cbCardIndex[m_pIAndroidUserItem->GetChairID()][i-2]==0))
					{
						return m_GameLogic.SwitchToCardData(i);
					}
					break;
				}
				if(cbTmp < 3)
				{
					i += 5;
				}
				else
				{
					i = (i/9+1)*9 - 1;
				}
			}	
		}
		//����
		//��19����
		for(int i=0; i<3; i++)
		{
			if(m_cbCardIndex[wMeChairID][i*9] == 1)
			{
				if(m_cbCardIndex[wMeChairID][i*9+1] == 0
					|| m_cbCardIndex[wMeChairID][i*9+2] == 0)
				{
					return m_GameLogic.SwitchToCardData(i*9);
				}
			}
			if(m_cbCardIndex[wMeChairID][i*9+8] == 1)
			{
				if(m_cbCardIndex[wMeChairID][i*9+7] == 0
					|| m_cbCardIndex[wMeChairID][i*9+6] == 0)
				{
					return m_GameLogic.SwitchToCardData(i*9+8);
				}
			}
		}
		//����ͨ����
		for(int i=0; i<27; i++)
		{
			if(m_cbCardIndex[wMeChairID][i] == 1)
			{
				if((i%9) == 0)
				{
					i += 3;
					continue;
				}
				if((i+1)%9 == 0)
				{
					continue;
				}
				if(m_cbCardIndex[wMeChairID][i+1] == 0
					&& m_cbCardIndex[wMeChairID][i-1] == 0)
				{
					return m_GameLogic.SwitchToCardData(i);
				}
				i += 1;
			}	
		}
		break;
	//case 1:
	//	#pragma region
	//	//��������
	//	for(int i=9; i<18; i++)
	//	{
	//		if(m_cbCardIndex[wMeChairID][i]>0)
	//		{
	//			return m_GameLogic.SwitchToCardData(i);
	//		}
	//	}
	//	//û������ʱ��������19����
	//	for (int i=0;i<3;i++)
	//	{			
	//		if(i==1) continue;
	//		if(m_cbCardIndex[wMeChairID][i*9]==1)
	//		{
	//			if((m_cbCardIndex[wMeChairID][i*9+1]==0)
	//				&&(m_cbCardIndex[wMeChairID][i*9+2]==0))
	//			{
	//				return m_GameLogic.SwitchToCardData(i*9);
	//			}
	//		}
	//		if(m_cbCardIndex[wMeChairID][i*9+8]==1)
	//		{
	//			if((m_cbCardIndex[wMeChairID][i*9+7]==0)
	//				&&(m_cbCardIndex[wMeChairID][i*9+6]==0))
	//			{
	//				return m_GameLogic.SwitchToCardData(i*9+8);
	//			}
	//		}
	//	}
	//	//û������ʱ����������ͨ����
	//	for(int i=0; i<27; i++)
	//	{
	//		if (i>8 && i<18) continue;
	//		if(m_cbCardIndex[wMeChairID][i]==1)
	//		{
	//			BYTE cbTmp = i%9;
	//			switch(cbTmp)
	//			{
	//			case 0:
	//				if((m_cbCardIndex[wMeChairID][i+1]==0)
	//					&& (m_cbCardIndex[wMeChairID][i+2]==0))
	//				{
	//					return m_GameLogic.SwitchToCardData(i);
	//				}
	//				break;
	//			case 1:
	//				if((m_cbCardIndex[wMeChairID][i+1]==0)
	//					&&(m_cbCardIndex[wMeChairID][i+2]==0)
	//					&&(m_cbCardIndex[wMeChairID][i-1]==0))
	//				{
	//					return m_GameLogic.SwitchToCardData(i);
	//				}
	//				break;
	//			case 2:
	//			case 3:
	//			case 4:
	//			case 5:
	//			case 6:
	//				if((m_cbCardIndex[wMeChairID][i+1]==0)
	//					&&(m_cbCardIndex[wMeChairID][i+2]==0)
	//					&&(m_cbCardIndex[wMeChairID][i-1]==0)
	//					&& (m_cbCardIndex[wMeChairID][i-2]==0))
	//				{
	//					return m_GameLogic.SwitchToCardData(i);
	//				}
	//				break;
	//			case 7:
	//				if((m_cbCardIndex[wMeChairID][i-1]==0)
	//					&&(m_cbCardIndex[m_pIAndroidUserItem->GetChairID()][i-2]==0)
	//					&&(m_cbCardIndex[m_pIAndroidUserItem->GetChairID()][i+1]==0))
	//				{
	//					return m_GameLogic.SwitchToCardData(i);
	//				}
	//				break;
	//			case 8:
	//				if((m_cbCardIndex[wMeChairID][i-1]==0)
	//					&&(m_cbCardIndex[m_pIAndroidUserItem->GetChairID()][i-2]==0))
	//				{
	//					return m_GameLogic.SwitchToCardData(i);
	//				}
	//				break;
	//			}
	//			if(cbTmp < 3)
	//			{
	//				i += 5;
	//			}
	//			else
	//			{
	//				i = (i/9+1)*9 - 1;
	//			}
	//		}	
	//	}
	//	//����
	//	//��19����
	//	for(int i=0; i<3; i++)
	//	{
	//		if(i==1)	continue;
	//		if(m_cbCardIndex[wMeChairID][i*9] == 1)
	//		{
	//			if(m_cbCardIndex[wMeChairID][i*9+1] == 0
	//				|| m_cbCardIndex[wMeChairID][i*9+2] == 0)
	//			{
	//				return m_GameLogic.SwitchToCardData(i*9);
	//			}
	//		}
	//		if(m_cbCardIndex[wMeChairID][i*9+8] == 1)
	//		{
	//			if(m_cbCardIndex[wMeChairID][i*9+7] == 0
	//				|| m_cbCardIndex[wMeChairID][i*9+6] == 0)
	//			{
	//				return m_GameLogic.SwitchToCardData(i*9+8);
	//			}
	//		}
	//	}
	//	//����ͨ����
	//	for(int i=0; i<27; i++)
	//	{
	//		if (i>8 && i<18) continue;
	//		if(m_cbCardIndex[wMeChairID][i] == 1)
	//		{
	//			if((i%9) == 0)
	//			{
	//				i += 3;
	//				continue;
	//			}
	//			if((i+1)%9 == 0)
	//			{
	//				continue;
	//			}
	//			if(m_cbCardIndex[wMeChairID][i+1] == 0
	//				&& m_cbCardIndex[wMeChairID][i-1] == 0)
	//			{
	//				return m_GameLogic.SwitchToCardData(i);
	//			}
	//			i += 1;
	//		}	
	//	}
	//	#pragma endregion
	//	break;
	//case 2:
	//	#pragma region
	//	//��19����
	//	for(int i=18; i<27; i++)
	//	{
	//		if(m_cbCardIndex[wMeChairID][i]>0)
	//		{
	//			return m_GameLogic.SwitchToCardData(i);
	//		}
	//	}
	//	//û��Ͳ��ʱ��������19����
	//	for (int i=0;i<2;i++)
	//	{
	//		if(m_cbCardIndex[wMeChairID][i*9]==1)
	//		{
	//			if((m_cbCardIndex[wMeChairID][i*9+1]==0)
	//				&&(m_cbCardIndex[wMeChairID][i*9+2]==0))
	//			{
	//				return m_GameLogic.SwitchToCardData(i*9);
	//			}
	//		}
	//		if(m_cbCardIndex[wMeChairID][i*9+8]==1)
	//		{
	//			if((m_cbCardIndex[wMeChairID][i*9+7]==0)
	//				&&(m_cbCardIndex[wMeChairID][i*9+6]==0))
	//			{
	//				return m_GameLogic.SwitchToCardData(i*9+8);
	//			}
	//		}
	//	}
	//	//û��Ͳ��ʱ����������ͨ����
	//	for(int i=0; i<18; i++)
	//	{
	//		if(m_cbCardIndex[wMeChairID][i]==1)
	//		{
	//			BYTE cbTmp = i%9;
	//			switch(cbTmp)
	//			{
	//			case 0:
	//				if((m_cbCardIndex[wMeChairID][i+1]==0)
	//					&& (m_cbCardIndex[wMeChairID][i+2]==0))
	//				{
	//					return m_GameLogic.SwitchToCardData(i);
	//				}
	//				break;
	//			case 1:
	//				if((m_cbCardIndex[wMeChairID][i+1]==0)
	//					&&(m_cbCardIndex[wMeChairID][i+2]==0)
	//					&&(m_cbCardIndex[wMeChairID][i-1]==0))
	//				{
	//					return m_GameLogic.SwitchToCardData(i);
	//				}
	//				break;
	//			case 2:
	//			case 3:
	//			case 4:
	//			case 5:
	//			case 6:
	//				if((m_cbCardIndex[wMeChairID][i+1]==0)
	//					&&(m_cbCardIndex[wMeChairID][i+2]==0)
	//					&&(m_cbCardIndex[wMeChairID][i-1]==0)
	//					&& (m_cbCardIndex[wMeChairID][i-2]==0))
	//				{
	//					return m_GameLogic.SwitchToCardData(i);
	//				}
	//				break;
	//			case 7:
	//				if((m_cbCardIndex[wMeChairID][i-1]==0)
	//					&&(m_cbCardIndex[m_pIAndroidUserItem->GetChairID()][i-2]==0)
	//					&&(m_cbCardIndex[m_pIAndroidUserItem->GetChairID()][i+1]==0))
	//				{
	//					return m_GameLogic.SwitchToCardData(i);
	//				}
	//				break;
	//			case 8:
	//				if((m_cbCardIndex[wMeChairID][i-1]==0)
	//					&&(m_cbCardIndex[m_pIAndroidUserItem->GetChairID()][i-2]==0))
	//				{
	//					return m_GameLogic.SwitchToCardData(i);
	//				}
	//				break;
	//			}
	//			if(cbTmp < 3)
	//			{
	//				i += 5;
	//			}
	//			else
	//			{
	//				i = (i/9+1)*9 - 1;
	//			}
	//		}	
	//	}
	//	//����
	//	//��19����
	//	for(int i=0; i<2; i++)
	//	{
	//		if(m_cbCardIndex[wMeChairID][i*9] == 1)
	//		{
	//			if(m_cbCardIndex[wMeChairID][i*9+1] == 0
	//				|| m_cbCardIndex[wMeChairID][i*9+2] == 0)
	//			{
	//				return m_GameLogic.SwitchToCardData(i*9);
	//			}
	//		}
	//		if(m_cbCardIndex[wMeChairID][i*9+8] == 1)
	//		{
	//			if(m_cbCardIndex[wMeChairID][i*9+7] == 0
	//				|| m_cbCardIndex[wMeChairID][i*9+6] == 0)
	//			{
	//				return m_GameLogic.SwitchToCardData(i*9+8);
	//			}
	//		}
	//	}
	//	//����ͨ����
	//	for(int i=0; i<18; i++)
	//	{
	//		if(m_cbCardIndex[wMeChairID][i] == 1)
	//		{
	//			if((i%9) == 0)
	//			{
	//				i += 3;
	//				continue;
	//			}
	//			if((i+1)%9 == 0)
	//			{
	//				continue;
	//			}
	//			if(m_cbCardIndex[wMeChairID][i+1] == 0
	//				&& m_cbCardIndex[wMeChairID][i-1] == 0)
	//			{
	//				return m_GameLogic.SwitchToCardData(i);
	//			}
	//			i += 1;
	//		}	
	//	}
	//	#pragma endregion
	//	break;
	}
	return  0XFF;
}
//������Ŀ
BYTE CAndroidUserItemSink::GetIsolatedCardCount(BYTE cbCardIndex[MAX_INDEX])
{
	//��ʱ����
	BYTE cbTempCardIndex[MAX_INDEX];
	CopyMemory(cbTempCardIndex,cbCardIndex,sizeof(cbTempCardIndex));

	//�������
	WORD wMeChairID=m_pIAndroidUserItem->GetChairID();
	int i=0;
	int iIsolateCardCount=0;
	//�й��ƴ����
	//��19����
	for(i=0; i<3; i++)
	{
		if(cbTempCardIndex[i*9]==1)
		{
			if((cbTempCardIndex[i*9+1]==0)
				&&(cbTempCardIndex[i*9+2]==0))
			{
				iIsolateCardCount++;
			}
		}
		if(cbTempCardIndex[i*9+8]==1)
		{
			if((cbTempCardIndex[i*9+7]==0)
				&&(cbTempCardIndex[i*9+6]==0))
			{
				iIsolateCardCount++;
			}
		}
	}
	//����ͨ����
	for( i=0; i<27; i++)
	{
		if(cbTempCardIndex[i]==1)
		{
			BYTE cbTmp = i%9;
			switch(cbTmp)
			{
			case 0:
				if((cbTempCardIndex[i+1]==0)
					&& (cbTempCardIndex[i+2]==0))
				{
					iIsolateCardCount++;
				}
				break;
			case 1:
				if((cbTempCardIndex[i+1]==0)
					&&(cbTempCardIndex[i+2]==0)
					&&(cbTempCardIndex[i-1]==0))
				{
					iIsolateCardCount++;
				}
				break;
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
				if((cbTempCardIndex[i+1]==0)
					&&(cbTempCardIndex[i+2]==0)
					&&(cbTempCardIndex[i-1]==0)
					&& (cbTempCardIndex[i-2]==0))
				{
					iIsolateCardCount++;
				}
				break;
			case 7:
				if((cbTempCardIndex[i-1]==0)
					&&(cbTempCardIndex[i-2]==0)
					&&(cbTempCardIndex[i+1]==0))
				{
					iIsolateCardCount++;
				}
				break;
			case 8:
				if((cbTempCardIndex[i-1]==0)
					&&(cbTempCardIndex[i-2]==0))
				{
					iIsolateCardCount++;
				}
				break;
			}
			if(cbTmp < 3)
			{
				i += 5;
			}
			else
			{
				i = (i/9+1)*9 - 1;
			}
		}	
	}

	//����
	//��19����
	for(i=0; i<3; i++)
	{
		if(cbTempCardIndex[i*9] == 1)
		{
			if(cbTempCardIndex[i*9+1] == 0
				|| cbTempCardIndex[i*9+2] == 0)
			{
				iIsolateCardCount++;
				
			}
		}
		if(cbTempCardIndex[i*9+8] == 1)
		{
			if(cbTempCardIndex[i*9+7] == 0
				|| cbTempCardIndex[i*9+6] == 0)
			{
				iIsolateCardCount++;
			}
		}
	}

	//����ͨ����
	for(i=0; i<27; i++)
	{
		if(cbTempCardIndex[i] == 1)
		{
			if((i%9) == 0)
			{
				i += 3;
				continue;
			}
			if((i+1)%9 == 0)
			{
				continue;
			}
			if(cbTempCardIndex[i+1] == 0
				&& cbTempCardIndex[i-1] == 0)
			{
				iIsolateCardCount++;
			}
			i += 1;
		}	
	}

	return  iIsolateCardCount;

}
WORD CAndroidUserItemSink::GetTheBestOperate(WORD cbOperateCode,BYTE cbOperateCard)
{
	//�������
	BYTE cbPreIsolateCardCount=GetIsolatedCardCount(m_cbCardIndex[m_pIAndroidUserItem->GetChairID()]);
	BYTE cbPengIsolateCardCount=0XFF;
	/*BYTE cbLeftIsolateCardCount=0XFF;
	BYTE cbCenterIsolateCradCount=0XFF;
	BYTE cbRightIsolateCardCount=0XFF;*/

	//���Ʋ���
	if(cbOperateCode&WIK_PENG)
	{
		BYTE cbTempCardIndex[MAX_INDEX];
		CopyMemory(cbTempCardIndex,m_cbCardIndex[m_pIAndroidUserItem->GetChairID()],sizeof(cbTempCardIndex));

		//��Ͻ���
		BYTE cbWeaveCard[4]={0,0,0,0},cbWeaveKind=WIK_PENG;
		BYTE cbWeaveCardCount=m_GameLogic.GetWeaveCard(cbWeaveKind,cbOperateCard,cbWeaveCard);
		m_GameLogic.RemoveCard(cbWeaveCard,cbWeaveCardCount,&cbOperateCard,1);
		m_GameLogic.RemoveCard(cbTempCardIndex,cbWeaveCard,cbWeaveCardCount-1);
		cbPengIsolateCardCount=GetIsolatedCardCount(cbTempCardIndex);
	}
	//��������
	if(cbPengIsolateCardCount==0)
		return WIK_PENG;
	
	//����Ȩλ
	BYTE cbMin=0xFF;
	if(cbMin>cbPengIsolateCardCount)
		cbMin=cbPengIsolateCardCount;
	/*if(cbMin>cbLeftIsolateCardCount)
		cbMin=cbLeftIsolateCardCount;
	if(cbMin>cbCenterIsolateCradCount)
		cbMin=cbCenterIsolateCradCount;
	if(cbMin>cbRightIsolateCardCount)
		cbMin=cbRightIsolateCardCount;*/
	ASSERT(cbMin!=0xFF);
	if(cbMin>cbPreIsolateCardCount)
		return WIK_NULL;
	if(cbMin==cbPengIsolateCardCount)
		return WIK_PENG;

	//����Ȩλ
	if((cbOperateCode&WIK_PENG)&&(cbPreIsolateCardCount-1==cbPengIsolateCardCount))
		return WIK_PENG;
	return WIK_NULL;
}
//�����ж�
bool CAndroidUserItemSink::VerdictOutCard(BYTE cbCardData)
{
	//�����ж�
	if ((m_bHearStatus==true))
	{
		//��������
		tagChiHuResult ChiHuResult;
		WORD wMeChairID=m_pIAndroidUserItem->GetChairID();
		BYTE cbWeaveCount=m_cbWeaveCount[wMeChairID];

		//�����˿�
		BYTE cbCardIndexTemp[MAX_INDEX];
		CopyMemory(cbCardIndexTemp,m_cbCardIndex[wMeChairID],sizeof(cbCardIndexTemp));
		//���ƹ���
		if (cbCardIndexTemp[m_GameLogic.SwitchToCardIndex(cbCardData)]==0)
			return false;
		//ɾ���˿�
		m_GameLogic.RemoveCard(cbCardIndexTemp,cbCardData);

		//�����ж�
		BYTE i=0;
		tagChiHuData chiHuTmp;
		for (i=0;i<MAX_INDEX;i++)
		{
			//���Ʒ���
			BYTE wChiHuRight=0;
			BYTE cbCurrentCard=m_GameLogic.SwitchToCardData(i);
			WORD cbHuCardKind=m_GameLogic.AnalyseChiHuCard(cbCardIndexTemp,m_WeaveItemArray[wMeChairID],cbWeaveCount,cbCurrentCard,wChiHuRight,ChiHuResult,m_cbQueMen[wMeChairID],chiHuTmp);

			//����ж�
			if (cbHuCardKind!=CHK_NULL) 
				break;
		}

		//�����ж�
		return (i!=MAX_INDEX);
	}

	return true;
}
//////////////////////////////////////////////////////////////////////////
