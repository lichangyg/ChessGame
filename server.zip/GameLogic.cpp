﻿#include "StdAfx.h"
#include "GameLogic.h"
#include "..\消息定义\MylogFile.h"
//////////////////////////////////////////////////////////////////////////
//静态变量

//扑克数据
const BYTE CGameLogic::m_cbCardDataArray[MAX_REPERTORY]=
{
	0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,						//万子
	0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,						//万子
	0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,						//万子
	0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,						//万子
	0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x19,						//索子
	0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x19,						//索子
	0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x19,						//索子
	0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x19,						//索子
	0x21,0x22,0x23,0x24,0x25,0x26,0x27,0x28,0x29,						//同子
	0x21,0x22,0x23,0x24,0x25,0x26,0x27,0x28,0x29,						//同子
	0x21,0x22,0x23,0x24,0x25,0x26,0x27,0x28,0x29,						//同子
	0x21,0x22,0x23,0x24,0x25,0x26,0x27,0x28,0x29,						//同子

	0x31,0x32,0x33,0x34,0x35,0x36,0x37,									//番子东南西北中发白
	0x31,0x32,0x33,0x34,0x35,0x36,0x37,									//番子
	0x31,0x32,0x33,0x34,0x35,0x36,0x37,									//番子
	0x31,0x32,0x33,0x34,0x35,0x36,0x37,									//番子
};

#define HONGZHONG_LAIZI_VALUE		0x37

//机器人好牌
const BYTE CGameLogic::m_cbCardAndroidDataArray[520]=
{
	0x13,0x15,0x15,0x16,0x17,0x18,0x18,0x18,0x25,0x26,0x27,0x28,0x29,
	0x17,0x17,0x18,0x19,0x21,0x21,0x22,0x22,0x23,0x23,0x25,0x28,0x28,
	0x11,0x13,0x14,0x15,0x15,0x15,0x17,0x18,0x24,0x24,0x26,0x27,0x29,
	0x12,0x13,0x13,0x13,0x14,0x16,0x21,0x21,0x21,0x22,0x23,0x23,0x27,
	0x11,0x11,0x12,0x14,0x15,0x21,0x21,0x21,0x23,0x23,0x24,0x25,0x25,
	0x15,0x15,0x16,0x17,0x17,0x21,0x22,0x23,0x25,0x26,0x27,0x28,0x28,
	0x14,0x16,0x16,0x17,0x17,0x17,0x18,0x18,0x18,0x24,0x25,0x28,0x29,
	0x15,0x15,0x16,0x16,0x21,0x22,0x23,0x24,0x27,0x27,0x27,0x28,0x28,
	0x11,0x11,0x12,0x12,0x13,0x13,0x13,0x14,0x15,0x16,0x24,0x25,0x26,
	0x11,0x13,0x13,0x21,0x21,0x22,0x23,0x26,0x26,0x27,0x27,0x27,0x28,
	0x11,0x11,0x11,0x14,0x15,0x15,0x15,0x21,0x26,0x27,0x27,0x28,0x28,
	0x11,0x11,0x18,0x18,0x18,0x19,0x19,0x23,0x23,0x24,0x28,0x29,0x29,
	0x11,0x11,0x12,0x14,0x17,0x18,0x19,0x19,0x19,0x21,0x21,0x22,0x27,
	0x11,0x12,0x13,0x13,0x13,0x14,0x14,0x19,0x22,0x22,0x22,0x23,0x23,
	0x12,0x14,0x15,0x15,0x16,0x16,0x17,0x22,0x22,0x23,0x25,0x27,0x28,
	0x11,0x11,0x13,0x17,0x18,0x18,0x21,0x22,0x24,0x24,0x26,0x27,0x27,
	0x11,0x12,0x13,0x14,0x14,0x15,0x15,0x18,0x21,0x22,0x22,0x25,0x24,
	0x11,0x11,0x12,0x14,0x16,0x17,0x17,0x17,0x26,0x26,0x26,0x27,0x28,
	0x13,0x14,0x17,0x18,0x18,0x19,0x21,0x22,0x22,0x22,0x23,0x24,0x24,
	0x14,0x15,0x16,0x17,0x17,0x25,0x25,0x26,0x26,0x26,0x27,0x27,0x28,
	0x12,0x12,0x13,0x14,0x14,0x21,0x21,0x21,0x22,0x25,0x25,0x28,0x29,	
	0x15,0x15,0x15,0x16,0x17,0x21,0x25,0x26,0x26,0x27,0x27,0x28,0x29,
	0x11,0x13,0x15,0x15,0x15,0x18,0x21,0x21,0x22,0x22,0x23,0x23,0x26,
	0x19,0x19,0x23,0x23,0x23,0x24,0x24,0x25,0x25,0x27,0x28,0x29,0x28,
	0x11,0x12,0x13,0x15,0x16,0x17,0x17,0x17,0x22,0x22,0x22,0x23,0x25,
	0x15,0x17,0x18,0x18,0x25,0x26,0x27,0x28,0x28,0x29,0x29,0x29,0x29,
	0x11,0x11,0x17,0x18,0x19,0x22,0x22,0x22,0x23,0x23,0x25,0x27,0x27,
	0x11,0x11,0x12,0x12,0x12,0x21,0x21,0x21,0x23,0x24,0x25,0x25,0x26,
	0x12,0x12,0x13,0x14,0x15,0x16,0x18,0x19,0x22,0x22,0x25,0x26,0x26,
	0x14,0x15,0x15,0x15,0x15,0x17,0x17,0x18,0x18,0x21,0x21,0x21,0x26,
	0x12,0x13,0x14,0x16,0x17,0x18,0x19,0x19,0x19,0x27,0x27,0x28,0x29,
	0x13,0x13,0x14,0x14,0x14,0x15,0x19,0x19,0x21,0x24,0x24,0x26,0x26,
	0x11,0x11,0x13,0x14,0x15,0x16,0x16,0x16,0x17,0x17,0x22,0x27,0x28,
	0x11,0x12,0x13,0x15,0x16,0x16,0x17,0x17,0x17,0x18,0x18,0x27,0x27,
	0x11,0x11,0x11,0x12,0x13,0x13,0x14,0x15,0x15,0x17,0x22,0x22,0x25,
	0x17,0x18,0x19,0x24,0x24,0x24,0x12,0x12,0x26,0x27,0x27,0x26,0x23,
	0x11,0x11,0x12,0x12,0x14,0x14,0x14,0x15,0x16,0x16,0x17,0x17,0x18,
	0x11,0x11,0x13,0x16,0x17,0x17,0x18,0x21,0x24,0x25,0x25,0x25,0x28,
	0x11,0x13,0x16,0x17,0x19,0x19,0x19,0x23,0x23,0x23,0x24,0x25,0x25,
	0x12,0x13,0x14,0x15,0x15,0x15,0x21,0x21,0x21,0x22,0x24,0x28,0x28	
};

//////////////////////////////////////////////////////////////////////////

//构造函数
CGameLogic::CGameLogic()
{
	//m_cbCardColorCount = 0;
	m_bHaidiPao = false;
	m_bHaidilao = false;
	m_blongqidui = false;
}

//析构函数
CGameLogic::~CGameLogic()
{
}
//获取扑克
void CGameLogic::GetAndroidCard(BYTE cbIndex,BYTE cbAndroidCard[],BYTE cbCount)
{
	//CopyMemory(cbAndroidCard,m_cbCardAndroidDataArray,sizeof(cbAndroidCard))
	for (int i=0;i<cbCount;i++)
	{
		cbAndroidCard[i]=m_cbCardAndroidDataArray[cbIndex*13+i];//9
	}
}
void CGameLogic::CopyCardDataArray(BYTE cbCards[MAX_REPERTORY], BYTE cbCount)
{
	CopyMemory(cbCards, m_cbCardDataArray, sizeof(cbCards[0]) * cbCount);
}

//	获取扑克组合 组合后的扑克，组合数
BYTE CGameLogic::GetWeaveItem(BYTE cbWeaveCard[12], BYTE nType, BYTE cbCards[MAX_REPERTORY], bool bSwitch)
{
	BYTE cbCount = nType;	 
	ZeroMemory(cbWeaveCard, sizeof(cbWeaveCard[0]) * 12);
	BYTE cbCard[MAX_REPERTORY];
	if ((cbCards != NULL) && (cbCards[0] != 0xFF))
	{
		CopyMemory(cbCard, cbCards, sizeof(cbCard));
	}
	else CopyMemory(cbCard, m_cbCardDataArray, sizeof(cbCard));

	if (nType < 10)	//	普通牌形	rand() % 30
	{
		//if		(nType == 3)	cbCount = 3;		//	取三组
		//else if (nType == 2)	cbCount = 2;		//	取两组
		//else					cbCount = 4;		//	取四组
		for (int i = 0; i < cbCount; i ++)
		{
			bool bOrder = (bool)(rand() % 4);		//	顺子三张
			bool bNbr	= true;//(bool)(rand() % 10);		//	万索同
			if (bOrder)		//	顺子三张
			{
				if (bNbr)	//	万索同
				{
					int nRow = rand() % 7;			//	列
					int nLine = rand() % 8;		//	行
					for (int j = 0; j < 8; j ++)
					{
						BYTE by = (nLine + j) % 8;
						by = by * 9 + nRow;
						if ((cbCard[by] != 0) && (cbCard[by + 1] != 0) && (cbCard[by + 2] != 0))
						{
							cbWeaveCard[i * 3]		= by;
							cbWeaveCard[i * 3 + 1]	= by + 1;
							cbWeaveCard[i * 3 + 2]	= by + 2;
							ASSERT((cbCard[by]&0xF0) == (cbCard[by + 1]&0xF0));
							ASSERT((cbCard[by]&0xF0) == (cbCard[by + 2]&0xF0));
							cbCard[by] = 0; cbCard[by + 1] = 0; cbCard[by + 2] = 0;		//	清除扑克
							break;
						}
					}
				}			
			}
			else				//	取三元
			{
				if (bNbr)	//	万索同
				{
					int nRow = rand() % 9;			//	列
					int nLine = rand() % 2;			//	行 万索同三种
					for (int j = 0; j < 9; j ++)
					{
						BYTE by = (nRow + j) % 9;	//	选列
						by += nLine * 9 * 4;		//	选万索同
						by += (rand() % 2) * 9;  
						if ((cbCard[by] != 0) && (cbCard[by + 9] != 0) && (cbCard[by + 18] != 0))
						{
							cbWeaveCard[i * 3]		= by;
							cbWeaveCard[i * 3 + 1]	= by + 9;
							cbWeaveCard[i * 3 + 2]	= by + 18;
							ASSERT((cbCard[by]&0x0F) == (cbCard[by + 9]&0x0F));
							ASSERT((cbCard[by]&0x0F) == (cbCard[by + 18]&0x0F));
							cbCard[by] = 0; cbCard[by + 9] = 0; cbCard[by + 18] = 0;		//	清除扑克
							break;
						}
					}
				}
			}
			if (cbWeaveCard[i * 3 + 2] == 0) {ASSERT(false); i --;}
			else if (bSwitch)
			{
				cbWeaveCard[i * 3] = m_cbCardDataArray[cbWeaveCard[i * 3]];
				cbWeaveCard[i * 3 + 1] = m_cbCardDataArray[cbWeaveCard[i * 3 + 1]];
				cbWeaveCard[i * 3 + 2] = m_cbCardDataArray[cbWeaveCard[i * 3 + 2]];
			}
		}
		cbCount *= 3;
	}
	else		//	小七对
	{
		//BYTE byTmpInd[MAX_INDEX];	// 用户扑克
		//SwitchToCardIndex(cbCard, USE_REPERTORY, byTmpInd);
		//if		(nRandCnt < 98)	cbCount = 15;		//	5 对
		//else if (nRandCnt < 99)	cbCount = 14;		//	4 对
		//else					cbCount = 16;		//	6 对
		cbCount -= 10;
		int i = cbCount;
		//CMylogFile::Instance().WriteLogFmt("小七对: %d 对", i);
		while (i --)
		{
			//if (rand() % 10)	//	万索同
			{
				int nRow = rand() % 9;			//	列
				int nLine = rand() % 2;			//	行 万索同三种
				for (int j = 0; j < 9; j ++)
				{
					BYTE by = (nRow + j) % 9;	//	选列
					by += nLine * 9 * 4;		//	选万索同
					if ((cbCard[by] != 0) && (cbCard[by + 9] != 0))
					{
						cbWeaveCard[i * 2]		= by;
						cbWeaveCard[i * 2 + 1]	= by + 9;
						ASSERT((cbCard[by]&0x0F) == (cbCard[by + 9]&0x0F));
						cbCard[by] = 0; cbCard[by + 9] = 0;		//	清除扑克
						break;
					}
				}
			}	
			if (cbWeaveCard[i * 2 + 1] == 0) {ASSERT(false); i --;}
			else if (bSwitch)
			{
				cbWeaveCard[i * 2] = m_cbCardDataArray[cbWeaveCard[i * 2]];
				cbWeaveCard[i * 2 + 1] = m_cbCardDataArray[cbWeaveCard[i * 2 + 1]];
			}
		}
		cbCount *= 2;
	}

	if (cbCards != NULL)
	{
		CopyMemory(cbCards, cbCard, sizeof(cbCard));
	}
	return cbCount;
}
//混乱扑克
void CGameLogic::RandCardData(BYTE cbCardData[], BYTE cbMaxCount)
{
	//混乱准备
	BYTE cbCardDataTemp[CountArray(m_cbCardDataArray)];
	CopyMemory(cbCardDataTemp,m_cbCardDataArray,sizeof(m_cbCardDataArray));


	//混乱扑克
	BYTE cbRandCount=0,cbPosition=0;
	do
	{
		cbPosition=rand()%(cbMaxCount-cbRandCount);
		cbCardData[cbRandCount++]=cbCardDataTemp[cbPosition];
		cbCardDataTemp[cbPosition]=cbCardDataTemp[cbMaxCount-cbRandCount];
	} while (cbRandCount<cbMaxCount);

	return;
}

//混乱扑克
void CGameLogic::RandCardData(BYTE cbCardData[], BYTE cbMaxCount,BYTE cbAndroidCard[],BYTE cbAndroidCount)
{
	//混乱准备
	BYTE cbCardDataTemp[CountArray(m_cbCardDataArray)];
	CopyMemory(cbCardDataTemp,m_cbCardDataArray,sizeof(m_cbCardDataArray));
	RemoveAndroidCard(cbCardDataTemp,MAX_REPERTORY,cbAndroidCard,cbAndroidCount);
	BYTE cbCount=cbMaxCount;
	cbCount-=cbAndroidCount;
	//混乱扑克
	BYTE cbRandCount=0,cbPosition=0;
	do
	{
		cbPosition=rand()%(cbCount-cbRandCount);
		cbCardData[cbRandCount++]=cbCardDataTemp[cbPosition];
		cbCardDataTemp[cbPosition]=cbCardDataTemp[cbCount-cbRandCount];
	} while (cbRandCount<cbCount);

	return;
}

//删除扑克
bool CGameLogic::RemoveCard(BYTE cbCardIndex[MAX_INDEX], BYTE cbRemoveCard)
{
	//效验扑克
	ASSERT(IsValidCard(cbRemoveCard));
	ASSERT(cbCardIndex[SwitchToCardIndex(cbRemoveCard)]>0);

	//删除扑克
	BYTE cbRemoveIndex=SwitchToCardIndex(cbRemoveCard);
	if (cbCardIndex[cbRemoveIndex]>0)
	{
		cbCardIndex[cbRemoveIndex]--;
		return true;
	}

	//失败效验
	ASSERT(FALSE);

	return false;
}

//删除扑克
bool CGameLogic::RemoveCard(BYTE cbCardIndex[MAX_INDEX], BYTE cbRemoveCard[], BYTE cbRemoveCount)
{
	//删除扑克
	for (BYTE i=0;i<cbRemoveCount;i++)
	{
		//效验扑克
		ASSERT(IsValidCard(cbRemoveCard[i]));
		ASSERT(cbCardIndex[SwitchToCardIndex(cbRemoveCard[i])]>0);

		//删除扑克
		BYTE cbRemoveIndex=SwitchToCardIndex(cbRemoveCard[i]);
		if (cbCardIndex[cbRemoveIndex]==0)
		{
			//错误断言
			ASSERT(FALSE);

			//还原删除
			for (BYTE j=0;j<i;j++) 
			{
				ASSERT(IsValidCard(cbRemoveCard[j]));
				cbCardIndex[SwitchToCardIndex(cbRemoveCard[j])]++;
			}

			return false;
		}
		else 
		{
			//删除扑克
			--cbCardIndex[cbRemoveIndex];
		}
	}

	return true;
}

//删除扑克
bool CGameLogic::RemoveCard(BYTE cbCardData[], BYTE cbCardCount, BYTE cbRemoveCard[], BYTE cbRemoveCount)
{
	//检验数据
	ASSERT(cbCardCount<=14);
	ASSERT(cbRemoveCount<=cbCardCount);

	//定义变量
	BYTE cbDeleteCount=0,cbTempCardData[14];
	if (cbCardCount>CountArray(cbTempCardData))
		return false;
	CopyMemory(cbTempCardData,cbCardData,cbCardCount*sizeof(cbCardData[0]));

	//置零扑克
	for (BYTE i=0;i<cbRemoveCount;i++)
	{
		for (BYTE j=0;j<cbCardCount;j++)
		{
			if (cbRemoveCard[i]==cbTempCardData[j])
			{
				cbDeleteCount++;
				cbTempCardData[j]=0;
				break;
			}
		}
	}

	//成功判断
	if (cbDeleteCount!=cbRemoveCount) 
	{
		ASSERT(FALSE);
		return false;
	}

	//清理扑克
	BYTE cbCardPos=0;
	for (BYTE i=0;i<cbCardCount;i++)
	{
		if (cbTempCardData[i]!=0) 
			cbCardData[cbCardPos++]=cbTempCardData[i];
	}

	return true;
}

//删除扑克
bool CGameLogic::RemoveAndroidCard(BYTE cbCardData[], BYTE cbCardCount, BYTE cbRemoveCard[], BYTE cbRemoveCount)
{
	//检验数据
	ASSERT(cbCardCount<=MAX_REPERTORY);
	ASSERT(cbRemoveCount<=cbCardCount);

	//定义变量
	BYTE cbDeleteCount=0,cbTempCardData[MAX_REPERTORY];
	if (cbCardCount>MAX_REPERTORY)
		return false;
	CopyMemory(cbTempCardData,cbCardData,cbCardCount*sizeof(cbCardData[0]));

	//置零扑克
	for (BYTE i=0;i<cbRemoveCount;i++)
	{
		for (BYTE j=0;j<cbCardCount;j++)
		{
			if (cbRemoveCard[i]==cbTempCardData[j])
			{
				cbDeleteCount++;
				cbTempCardData[j]=0;
				break;
			}
		}
	}

	//成功判断
	if (cbDeleteCount!=cbRemoveCount) 
	{
		ASSERT(FALSE);
		return false;
	}

	//清理扑克
	BYTE cbCardPos=0;
	for (BYTE i=0;i<cbCardCount;i++)
	{
		if (cbTempCardData[i]!=0) 
			cbCardData[cbCardPos++]=cbTempCardData[i];
	}

	return true;
}

//有效判断
bool CGameLogic::IsValidCard(BYTE cbCardData)
{
	BYTE cbValue=(cbCardData&MASK_VALUE);
	BYTE cbColor=(cbCardData&MASK_COLOR)>>4;
	return (((cbValue>=1)&&(cbValue<=9)&&(cbColor<=2))||((cbValue>=1)&&(cbValue<=7)&&(cbColor == 3 )));
}

//扑克数目
BYTE CGameLogic::GetCardCount(BYTE cbCardIndex[MAX_INDEX])
{
	//数目统计
	BYTE cbCardCount=0;
	for (BYTE i=0;i<MAX_INDEX;i++) 
		cbCardCount+=cbCardIndex[i];

	return cbCardCount;
}
int CGameLogic::GetMinQuemenType(BYTE cbCardIndex[MAX_INDEX])
{
	int type = 0;
	int wanzi=0;
	int tiaozi=0;
	int tongzi=0;
	for (int i=0;i<MAX_INDEX;i++)
	{
		if (cbCardIndex[i]==0)  continue;
		if (cbCardIndex[i]>0)
		{
			if (i<9)
				wanzi+=cbCardIndex[i];
			else if(i>8&&i<18)
				tiaozi+=cbCardIndex[i];
			else if(i>17)
				tongzi+=cbCardIndex[i];
		}
	}
	if (wanzi==tiaozi && tiaozi==tongzi)
		type = rand()%3;
	else if( wanzi<=tiaozi && wanzi<=tongzi) 
		type = 0;
	else if( tiaozi<=wanzi && tiaozi<=tongzi) 
		type = 1;
	else if( tongzi<=wanzi && tongzi<=tiaozi)
		type = 2;
	return  type;
}
//获取组合
BYTE CGameLogic::GetWeaveCard(BYTE cbWeaveKind, BYTE cbCenterCard, BYTE cbCardBuffer[4])
{
	//组合扑克
	switch (cbWeaveKind)
	{
	//case WIK_LEFT:		//上牌操作
	//	{
	//		//设置变量
	//		cbCardBuffer[0]=cbCenterCard;
	//		cbCardBuffer[1]=cbCenterCard+1;
	//		cbCardBuffer[2]=cbCenterCard+2;
	//		return 3;
	//	}
	//case WIK_RIGHT:		//上牌操作
	//	{
	//		//设置变量
	//		cbCardBuffer[0]=cbCenterCard;
	//		cbCardBuffer[1]=cbCenterCard-1;
	//		cbCardBuffer[2]=cbCenterCard-2;

	//		return 3;
	//	}
	//case WIK_CENTER:	//上牌操作
	//	{
	//		//设置变量
	//		//设置变量
	//		cbCardBuffer[0]=cbCenterCard;
	//		cbCardBuffer[1]=cbCenterCard-1;
	//		cbCardBuffer[2]=cbCenterCard+1;

	//		return 3;
	//	}
	case WIK_PENG:		//碰牌操作
		{
			//设置变量
			cbCardBuffer[0]=cbCenterCard;
			cbCardBuffer[1]=cbCenterCard;
			cbCardBuffer[2]=cbCenterCard;

			return 3;
		}
	case WIK_GANG:		//杠牌操作
		{
			//设置变量
			cbCardBuffer[0]=cbCenterCard;
			cbCardBuffer[1]=cbCenterCard;
			cbCardBuffer[2]=cbCenterCard;
			cbCardBuffer[3]=cbCenterCard;

			return 4;
		}
	//case WIK_SPE_YAOGANG:
	//	{
	//		//设置变量
	//		cbCardBuffer[0]=0x01;
	//		cbCardBuffer[1]=0x11;
	//		cbCardBuffer[2]=0x21;
	//		return 3;
	//	}
	//case WIK_SPE_JIUGANG:
	//	{
	//		//设置变量
	//		cbCardBuffer[0]=0x09;
	//		cbCardBuffer[1]=0x19;
	//		cbCardBuffer[2]=0x29;
	//		return 3;
	//	}
	//case WIK_SPE_FENGGANG:
	//	{
	//		//设置变量
	//		cbCardBuffer[0]=0x31;
	//		cbCardBuffer[1]=0x32;
	//		cbCardBuffer[2]=0x33;
	//		cbCardBuffer[3]=0x34;
	//		return 4;
	//	}
	//case WIK_SPE_BAIGANG:
	//	{
	//		//设置变量
	//		cbCardBuffer[0]=0x35;
	//		cbCardBuffer[1]=0x36;
	//		cbCardBuffer[2]=0x37;
	//		return 3;
	//	}
	default:
		{
			ASSERT(FALSE);
		}
	}

	return 0;
}

//动作等级
BYTE CGameLogic::GetUserActionRank(BYTE cbUserAction)
{
	//胡牌等级
	if ((cbUserAction&WIK_CHI_HU)/*||(cbUserAction&WIK_BAO_HU)||(cbUserAction&WIK_DUI_BAO)*/) { return 4; }

	//杠牌等级
	if (cbUserAction&WIK_GANG) { return 3; }

	//碰牌等级
	if (cbUserAction&WIK_PENG) { return 2; }

	////上牌等级
	if (cbUserAction&(WIK_RIGHT|WIK_CENTER|WIK_LEFT)) { return 1; }

	return 0;
}

//胡牌等级
WORD CGameLogic::GetChiHuActionRank(tagChiHuResult & ChiHuResult)
{


	return 0;
}

//吃牌判断
BYTE CGameLogic::EstimateEatCard(BYTE cbCardIndex[MAX_INDEX], BYTE cbCurrentCard)
{
	//参数效验
	ASSERT(IsValidCard(cbCurrentCard));

	//过滤判断
	//东南西北中发白不能吃
	if (cbCurrentCard >= 0x31) 
		return WIK_NULL;

	//变量定义
	BYTE cbExcursion[3]={0,1,2};
	BYTE cbItemKind[3]={WIK_LEFT,WIK_CENTER,WIK_RIGHT};

	//吃牌判断
	BYTE cbEatKind=0,cbFirstIndex=0;
	BYTE cbCurrentIndex=SwitchToCardIndex(cbCurrentCard);
	for (BYTE i=0;i<CountArray(cbItemKind);i++)
	{
		BYTE cbValueIndex=cbCurrentIndex%9;
		if ((cbValueIndex>=cbExcursion[i])&&((cbValueIndex-cbExcursion[i])<=6))
		{
			//吃牌判断
			cbFirstIndex=cbCurrentIndex-cbExcursion[i];
			if ((cbCurrentIndex!=cbFirstIndex)&&(cbCardIndex[cbFirstIndex]==0))
				continue;
			if ((cbCurrentIndex!=(cbFirstIndex+1))&&(cbCardIndex[cbFirstIndex+1]==0))
				continue;
			if ((cbCurrentIndex!=(cbFirstIndex+2))&&(cbCardIndex[cbFirstIndex+2]==0))
				continue;

			//设置类型
			cbEatKind|=cbItemKind[i];
		}
	}

	return cbEatKind;
}

//碰牌判断
BYTE CGameLogic::EstimatePengCard(BYTE cbCardIndex[MAX_INDEX], BYTE cbCurrentCard, BYTE m_cbQuemen, bool ishongzhongLaiZi)
{
	//参数效验
	ASSERT(IsValidCard(cbCurrentCard));
	//碰牌判断
	/*switch(m_cbQuemen)
	{
	case 0:
	if (cbCardIndex[SwitchToCardIndex(cbCurrentCard)]>=2 && cbCurrentCard>0x10)
	return WIK_PENG;
	else
	return WIK_NULL;
	break;		
	case 1:
	if (cbCardIndex[SwitchToCardIndex(cbCurrentCard)]>=2 && (cbCurrentCard<0x10||cbCurrentCard>0x17))
	return WIK_PENG;
	else
	return WIK_NULL;
	break;
	case 2:
	if (cbCardIndex[SwitchToCardIndex(cbCurrentCard)]>=2 && cbCurrentCard<0x20)
	return WIK_PENG;
	else
	return WIK_NULL;
	break;
	}*/	
	int needCardNum = 2;
	// 红中癞子并且有红中
	return (cbCardIndex[SwitchToCardIndex(cbCurrentCard)]>=needCardNum)?WIK_PENG:WIK_NULL;
}

//杠牌判断
BYTE CGameLogic::EstimateGangCard(BYTE cbCardIndex[MAX_INDEX], BYTE cbCurrentCard, BYTE m_cbQuemen, bool ishongzhongLaiZi)
{
	//参数效验
	ASSERT(IsValidCard(cbCurrentCard));
	//杠牌判断
	int needCardNum = 3;
	// 红中癞子并且有红中
	if (ishongzhongLaiZi && cbCurrentCard == HONGZHONG_LAIZI_VALUE)
	{
		//needCardNum  = 2;
	}
	return (cbCardIndex[SwitchToCardIndex(cbCurrentCard)]==needCardNum)?WIK_GANG:WIK_NULL;
	/*switch(m_cbQuemen)
	{
	case 0:
	if (cbCardIndex[SwitchToCardIndex(cbCurrentCard)]==3 && cbCurrentCard>0x10)
	return WIK_GANG;
	else
	return WIK_NULL;
	break;		
	case 1:
	if (cbCardIndex[SwitchToCardIndex(cbCurrentCard)]==3 && (cbCurrentCard<0x10||cbCurrentCard>0x17))
	return WIK_GANG;
	else
	return WIK_NULL;
	break;
	case 2:
	if (cbCardIndex[SwitchToCardIndex(cbCurrentCard)]==3 && cbCurrentCard<0x20)
	return WIK_GANG;
	else
	return WIK_NULL;
	break;
	}*/
}

//将对判断
BYTE CGameLogic::EstimateDuiCard(BYTE cbCardIndex[MAX_INDEX], BYTE cbCurrentCard, BYTE m_cbQuemen)
{
	//参数效验
	ASSERT(IsValidCard(cbCurrentCard));
	BYTE k = SwitchToCardIndex(cbCurrentCard);
	//碰牌判断
	/*switch(m_cbQuemen)
	{
	case 0:
		if (cbCardIndex[k]>=1 && cbCurrentCard>0x10)
			return WIK_PENG;
		else
			return WIK_NULL;
		break;		
	case 1:
		if ((cbCardIndex[k-1]>=1 && cbCardIndex[k]==0   && cbCardIndex[k+1]>=1 && (k%9)>=1 && (k%9)<=7)|| 
			 (cbCardIndex[k]==0   && cbCardIndex[k+1]>=1 && cbCardIndex[k+2]>=1 && (k%9)>=0 && (k%9)<=6)||
			 (cbCardIndex[k-2]>=1 && cbCardIndex[k-1]>=1 && cbCardIndex[k]==0   && (k%9)>=2 && (k%9)<=8)||
			 cbCardIndex[k]>=1)
			return WIK_PENG;
		else
			return WIK_NULL;
		break;
	case 2:
		if (cbCardIndex[SwitchToCardIndex(cbCurrentCard)]>=1 && cbCurrentCard<0x20)
			return WIK_PENG;
		else
			return WIK_NULL;
		break;
	}*/	
	//碰牌判断
	return (cbCardIndex[SwitchToCardIndex(cbCurrentCard)]>=1)?WIK_PENG:WIK_NULL;
}
//听牌分析
WORD CGameLogic::AnalyseTingCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount, DWORD dwChiHuRight,BYTE m_cbQueMen,tagChiHuData &chiHuTmp)
{
	//变量定义
	tagChiHuResult ChiHuResult;
	ZeroMemory(&ChiHuResult,sizeof(ChiHuResult));
	//构造扑克
	BYTE cbCardIndexTemp[MAX_INDEX];
	CopyMemory(cbCardIndexTemp,cbCardIndex,sizeof(cbCardIndexTemp));
	//听牌分析
	for (BYTE i=0;i<MAX_INDEX;i++)
	{
		//空牌过滤
		if (cbCardIndexTemp[i]==0) continue;
		////听牌处理
		//cbCardIndexTemp[i]--;
		//听牌判断
		for (BYTE j=0;j<MAX_INDEX;j++)
		{
			//胡牌分析
			BYTE cbCurrentCard=SwitchToCardData(j);
			WORD cbHuCardKind=AnalyseChiHuCard(cbCardIndexTemp,WeaveItem,cbItemCount,cbCurrentCard,dwChiHuRight,ChiHuResult, m_cbQueMen,chiHuTmp,true,false);
			if (cbHuCardKind!=CHK_NULL)
			   return WIK_LISTEN;			
		}
		////还原处理
		//cbCardIndexTemp[i]++;
	}
	return WIK_NULL;
}

//获取听牌可能的最大番
WORD CGameLogic::GetAnalyseTingCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount, DWORD dwChiHuRight,BYTE m_cbQueMen, tagChiHuData &chiHuTmp)
{
	//变量定义
	tagChiHuResult ChiHuResult;
	ZeroMemory(&ChiHuResult,sizeof(ChiHuResult));
	//构造扑克
	BYTE cbCardIndexTemp[MAX_INDEX];
	DWORD dwWinMax=0;
	CopyMemory(cbCardIndexTemp,cbCardIndex,sizeof(cbCardIndexTemp));
	bool IsListen=false;
	//听牌分析
	for (BYTE i=0;i<MAX_INDEX;i++)
	{
		//空牌过滤
		if (cbCardIndexTemp[i]==0) continue;
		//听牌判断
		for (BYTE j=0;j<MAX_INDEX;j++)
		{
			//胡牌分析
			BYTE cbCurrentCard=SwitchToCardData(j);
			WORD cbHuCardKind=AnalyseChiHuCard(cbCardIndexTemp,WeaveItem,cbItemCount,cbCurrentCard,dwChiHuRight,ChiHuResult, m_cbQueMen,chiHuTmp);
			if (cbHuCardKind!=CHK_NULL)
			{
				if (ChiHuResult.dwWinTimes>dwWinMax)
					dwWinMax = ChiHuResult.dwWinTimes;					
			}			
		}
	}
	return dwWinMax;
}


int CGameLogic::ChiHuCardCount(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount,BYTE m_cbQueMen,tagChiHuData &chiHuTmp)
{
	int countRes = 0;
	tagChiHuResult ChiHuResult;
	ZeroMemory(&ChiHuResult,sizeof(ChiHuResult));
	for (BYTE j=0;j<MAX_INDEX;j++)
	{
		//胡牌分析

		BYTE cbCurrentCard=SwitchToCardData(j);
		WORD cbHuCardKind=AnalyseChiHuCard(cbCardIndex,WeaveItem,cbItemCount,cbCurrentCard,0,ChiHuResult, m_cbQueMen,chiHuTmp);

		//结果判断
		if (cbHuCardKind!=CHK_NULL) 
		{
			countRes++;
		}
	}
	return countRes;
}
//杠牌分析
WORD CGameLogic::AnalyseGangCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, tagGangCardResult & GangCardResult,BYTE m_cbQueMen,BYTE cbCenterCard)
{
	//设置变量
	WORD cbActionMask=WIK_NULL;
	ZeroMemory(&GangCardResult,sizeof(GangCardResult));

	//手上杠牌
	for (BYTE i=0;i<MAX_INDEX;i++)
	{
		/*switch(m_cbQueMen)
		{
		case 0:	
			if (cbCardIndex[i]==4 && i>8)
			{
				cbActionMask|=WIK_GANG;
				GangCardResult.cbGangType|=WIK_GANG;
				GangCardResult.cbCardData[GangCardResult.cbCardCount++][0]=SwitchToCardData(i);
			}
			break;
		case 1:
			if (cbCardIndex[i]==4 && (i<9||i>17))
			{
				cbActionMask|=WIK_GANG;
				GangCardResult.cbGangType|=WIK_GANG;
				GangCardResult.cbCardData[GangCardResult.cbCardCount++][0]=SwitchToCardData(i);
			}
			break;
		case 2:
			if (cbCardIndex[i]==4 && (i<18))
			{
				cbActionMask|=WIK_GANG;
				GangCardResult.cbGangType|=WIK_GANG;
				GangCardResult.cbCardData[GangCardResult.cbCardCount++][0]=SwitchToCardData(i);
			}
			break;
		}*/
		if (cbCardIndex[i]==4)
		{
			cbActionMask|=WIK_GANG;
			GangCardResult.cbGangType|=WIK_GANG;
			GangCardResult.cbCardData[GangCardResult.cbCardCount++][0]=SwitchToCardData(i);
		}
	}	
	//组合杠牌
	for (BYTE i=0;i<cbWeaveCount;i++)
	{
		if (WeaveItem[i].cbWeaveKind==WIK_PENG && WeaveItem[i].cbCenterCard==cbCenterCard)
		{
			if (cbCardIndex[SwitchToCardIndex(WeaveItem[i].cbCenterCard)]==1)
			{
				cbActionMask|=WIK_GANG;
				GangCardResult.cbGangType|=WIK_GANG;
				GangCardResult.cbCardData[GangCardResult.cbCardCount++][0]=WeaveItem[i].cbCenterCard;
			}
		}
	}
	return cbActionMask;
}

//首出杠牌分析
WORD CGameLogic::AnalyseFirstGangCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, tagGangCardResult & GangCardResult,BYTE m_cbQueMen)
{
	//设置变量
	WORD cbActionMask=WIK_NULL;
	ZeroMemory(&GangCardResult,sizeof(GangCardResult));
	//手上杠牌
	for (BYTE i=0;i<MAX_INDEX;i++)
	{
		/*switch(m_cbQueMen)
		{
		case 0:	
			if (cbCardIndex[i]==4 && i>8)
			{
				cbActionMask|=WIK_GANG;
				GangCardResult.cbGangType|=WIK_GANG;
				GangCardResult.cbCardData[GangCardResult.cbCardCount++][0]=SwitchToCardData(i);
			}
			break;
		case 1:
			if (cbCardIndex[i]==4 && (i<9||i>17))
			{
				cbActionMask|=WIK_GANG;
				GangCardResult.cbGangType|=WIK_GANG;
				GangCardResult.cbCardData[GangCardResult.cbCardCount++][0]=SwitchToCardData(i);
			}
			break;
		case 2:
			if (cbCardIndex[i]==4 && (i<18))
			{
				cbActionMask|=WIK_GANG;
				GangCardResult.cbGangType|=WIK_GANG;
				GangCardResult.cbCardData[GangCardResult.cbCardCount++][0]=SwitchToCardData(i);
			}
			break;
		}*/		
		if (cbCardIndex[i]==4)
		{
			cbActionMask|=WIK_GANG;
			GangCardResult.cbGangType|=WIK_GANG;
			GangCardResult.cbCardData[GangCardResult.cbCardCount++][0]=SwitchToCardData(i);
		}
	}

	//寻找补杠
	//cbActionMask|=AnalyseZuHeSpeGangCard(cbCardIndex,WeaveItem,cbWeaveCount,GangCardResult);
	//特殊杠牌分析
	//cbActionMask|=AnalyseSpeGangCard(cbCardIndex, WeaveItem, cbWeaveCount, GangCardResult);
	return cbActionMask;
}
//机器人首出杠牌分析
WORD CGameLogic::AnalyseAndroidFirstGangCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, tagGangCardResult & GangCardResult)
{
	//设置变量
	WORD cbActionMask=WIK_NULL;

	//手上杠牌
	for (BYTE i=0;i<MAX_INDEX;i++)
	{
		if (cbCardIndex[i]==4)
		{
			cbActionMask=WIK_GANG;
			GangCardResult.cbGangType|=WIK_GANG;
			GangCardResult.cbCardData[GangCardResult.cbCardCount][0]=SwitchToCardData(i);
			GangCardResult.cbCardCount++;
		}
	}

	////组合杠牌
	//cbActionMask=AnalyseZuHeSpeGangCard(cbCardIndex,WeaveItem,cbWeaveCount,GangCardResult);
	//特殊杠牌分析
	//cbActionMask=AnalyseAndroidSpeGangCard(cbCardIndex,GangCardResult);
	return cbActionMask;
}
//特殊杠牌分析
WORD CGameLogic::AnalyseSpeGangCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount,tagGangCardResult & GangCardResult)
{
	////设置变量
	//bool bHasYaoGang = false;
	//bool bHasJiuGang = false;
	//bool bHasFengGang = false;
	//bool bHasBaiGang = false;
	//for (int i = 0; i < cbWeaveCount; i++)
	//{
	//	if (WeaveItem[i].cbWeaveKind == WIK_SPE_YAOGANG)	bHasYaoGang = true;
	//	if (WeaveItem[i].cbWeaveKind == WIK_SPE_JIUGANG)	bHasJiuGang = true;
	//	if (WeaveItem[i].cbWeaveKind == WIK_SPE_FENGGANG)	bHasFengGang = true;
	//	if (WeaveItem[i].cbWeaveKind == WIK_SPE_BAIGANG)	bHasBaiGang = true;
	//}
	WORD cbActionMask=WIK_NULL;
	/*for (int i=1;i<=4;i++)
	{
	switch(i)
	{
	case 1:
	{
	if (bHasYaoGang == false)
	{
	if ((cbCardIndex[0]>0)&&(cbCardIndex[9]>0)&&(cbCardIndex[18]>0))
	{
	cbActionMask|=WIK_SHOU_GANG;
	GangCardResult.cbCardData[GangCardResult.cbCardCount][0]++;
	GangCardResult.cbCardData[GangCardResult.cbCardCount][1]++;
	GangCardResult.cbCardData[GangCardResult.cbCardCount][2]++;
	GangCardResult.cbGangType|=WIK_SPE_YAOGANG;
	GangCardResult.cbCardCount++;
	}
	}
	}
	break;
	case 2:
	{
	if (bHasJiuGang == false)
	{
	if ((cbCardIndex[8]>0)&&(cbCardIndex[17]>0)&&(cbCardIndex[26]>0))
	{
	cbActionMask|=WIK_SHOU_GANG;
	GangCardResult.cbCardData[GangCardResult.cbCardCount][0]++;
	GangCardResult.cbCardData[GangCardResult.cbCardCount][1]++;
	GangCardResult.cbCardData[GangCardResult.cbCardCount][2]++;
	GangCardResult.cbGangType|=WIK_SPE_JIUGANG;
	GangCardResult.cbCardCount++;
	}
	}

	}
	break;
	case 3:
	{
	if (bHasFengGang == false)
	{
	if ((cbCardIndex[27]>0)&&(cbCardIndex[28]>0)&&(cbCardIndex[29]>0)&&(cbCardIndex[30]>0))
	{
	cbActionMask|=WIK_SHOU_GANG;
	GangCardResult.cbCardData[GangCardResult.cbCardCount][0]++;
	GangCardResult.cbCardData[GangCardResult.cbCardCount][1]++;
	GangCardResult.cbCardData[GangCardResult.cbCardCount][2]++;
	GangCardResult.cbCardData[GangCardResult.cbCardCount][3]++;
	GangCardResult.cbGangType|=WIK_SPE_FENGGANG;
	GangCardResult.cbCardCount++;
	}
	}

	}
	break;
	case 4:
	{
	if (bHasBaiGang == false)
	{
	if ((cbCardIndex[31]>0)&&(cbCardIndex[32]>0)&&(cbCardIndex[33]>0))
	{
	cbActionMask|=WIK_SHOU_GANG;
	GangCardResult.cbCardData[GangCardResult.cbCardCount][0]++;
	GangCardResult.cbCardData[GangCardResult.cbCardCount][1]++;
	GangCardResult.cbCardData[GangCardResult.cbCardCount][2]++;
	GangCardResult.cbGangType|=WIK_SPE_BAIGANG;
	GangCardResult.cbCardCount++;
	}
	}

	}
	break;
	}
	}*/
	return cbActionMask;
}
//特殊杠牌分析
WORD CGameLogic::AnalyseAndroidSpeGangCard(BYTE cbCardIndex[MAX_INDEX],tagGangCardResult & GangCardResult)
{
	//设置变量
	WORD cbActionMask=WIK_NULL;
	//for (int i=1;i<=4;i++)
	//{
	//	switch(i)
	//	{
	//	case 1:
	//		{
	//			if ((cbCardIndex[0]>0)&&(cbCardIndex[9]>0)&&(cbCardIndex[18]>0))
	//			{
	//				cbActionMask=WIK_SPE_YAOGANG;
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][0]++;
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][1]++;
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][2]++;
	//				GangCardResult.cbGangType|=WIK_SPE_YAOGANG;
	//				GangCardResult.cbCardCount++;
	//			}
	//		}
	//		break;
	//	case 2:
	//		{
	//			if ((cbCardIndex[8]>0)&&(cbCardIndex[17]>0)&&(cbCardIndex[26]>0))
	//			{
	//				cbActionMask=WIK_SPE_JIUGANG;
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][0]++;
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][1]++;
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][2]++;
	//				GangCardResult.cbGangType|=WIK_SPE_JIUGANG;
	//				GangCardResult.cbCardCount++;
	//			}
	//		}
	//		break;
	//	case 3:
	//		{
	//			if ((cbCardIndex[27]>0)&&(cbCardIndex[28]>0)&&(cbCardIndex[29]>0)&&(cbCardIndex[30]>0))
	//			{
	//				cbActionMask=WIK_SPE_FENGGANG;
	//				/*GangCardResult.cbCardData[GangCardResult.cbCardCount][0]++;
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][1]++;
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][2]++;
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][3]++;*/
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][0]=0x31;
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][1]=0x32;
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][2]=0x33;
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][3]=0x34;
	//				GangCardResult.cbGangType|=WIK_SPE_FENGGANG;
	//				GangCardResult.cbCardCount++;
	//			}
	//		}
	//		break;
	//	case 4:
	//		{
	//			if ((cbCardIndex[31]>0)&&(cbCardIndex[32]>0)&&(cbCardIndex[33]>0))
	//			{
	//				cbActionMask=WIK_SPE_BAIGANG;
	//				/*GangCardResult.cbCardData[GangCardResult.cbCardCount][0]++;
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][1]++;
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][2]++;*/
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][0]=0x35;
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][1]=0x36;
	//				GangCardResult.cbCardData[GangCardResult.cbCardCount][2]=0x37;
	//				GangCardResult.cbGangType|=WIK_SPE_BAIGANG;
	//				GangCardResult.cbCardCount++;
	//			}
	//		}
	//		break;
	//	}
	//}
	return cbActionMask;
}
//组合特殊杠牌分析(补杠分析)
WORD CGameLogic::AnalyseZuHeSpeGangCard(BYTE cbCardIndex[MAX_INDEX],tagWeaveItem WeaveItem[], BYTE cbItemCount, tagGangCardResult & GangCardResult)
{
	WORD cbWeaveKindType=WIK_NULL;
	//寻找组合，补杠
	//for (BYTE i=0;i<cbItemCount;i++)
	//{
	//	WORD cbWeaveKind=WeaveItem[i].cbWeaveKind;
	//	//BYTE cbCenterCard=m_WeaveItemArray[wChairID][i].cbCenterCard;
	//	if (cbWeaveKind==WIK_SPE_YAOGANG)
	//	{
	//		if ((cbCardIndex[0]>0)||(cbCardIndex[9]>0)||(cbCardIndex[18]>0))
	//		{
	//			cbWeaveKindType|=WIK_SPE_YAOGANG;
	//			GangCardResult.cbCardCount++;
	//			//break;
	//		}
	//	}
	//	if (cbWeaveKind==WIK_SPE_JIUGANG)
	//	{
	//		if ((cbCardIndex[8]>0)||(cbCardIndex[17]>0)||(cbCardIndex[26]>0))
	//		{
	//			cbWeaveKindType|=WIK_SPE_JIUGANG;
	//			GangCardResult.cbCardCount++;
	//			//break;
	//		}
	//	}
	//	if (cbWeaveKind==WIK_SPE_FENGGANG)
	//	{
	//		if ((cbCardIndex[27]>0)||(cbCardIndex[28]>0)||(cbCardIndex[29]>0)||(cbCardIndex[30]>0))
	//		{
	//			cbWeaveKindType|=WIK_SPE_FENGGANG;
	//			GangCardResult.cbCardCount++;
	//			//break;
	//		}
	//	}
	//	if (cbWeaveKind==WIK_SPE_BAIGANG)
	//	{
	//		if ((cbCardIndex[31]>0)||(cbCardIndex[32]>0)||(cbCardIndex[33]>0))
	//		{
	//			cbWeaveKindType|=WIK_SPE_BAIGANG;
	//			GangCardResult.cbCardCount++;
	//			//break;
	//		}
	//	}
	//}
	return cbWeaveKindType;
}
//机器人组合特殊杠牌分析
WORD CGameLogic::AnalyseAndroidZuHeSpeGangCard(BYTE cbCardIndex[MAX_INDEX],tagWeaveItem WeaveItem[], BYTE cbItemCount, tagGangCardResult & GangCardResult)
{
	WORD cbWeaveKindType=WIK_NULL;
	//寻找组合，补杠
	//for (BYTE i=0;i<cbItemCount;i++)
	//{
	//	WORD cbWeaveKind=WeaveItem[i].cbWeaveKind;
	//	//BYTE cbCenterCard=m_WeaveItemArray[wChairID][i].cbCenterCard;
	//	if (cbWeaveKind==WIK_SPE_YAOGANG)
	//	{
	//		if ((cbCardIndex[0]<=0)&&(cbCardIndex[9]<=0)&&(cbCardIndex[18]<=0))
	//		{
	//			continue;
	//		}
	//		cbWeaveKindType|=WIK_GANG;
	//		if (cbCardIndex[0]>0)
	//		{
	//			GangCardResult.cbGangType=WIK_SPE_YAOGANG;

	//			GangCardResult.cbCardData[GangCardResult.cbCardCount][0]=0x01;
	//			GangCardResult.cbCardCount++;
	//			break;
	//		}
	//		if (cbCardIndex[9]>0)
	//		{
	//			GangCardResult.cbGangType=WIK_SPE_YAOGANG;
	//			GangCardResult.cbCardData[GangCardResult.cbCardCount][0]=0x11;
	//			GangCardResult.cbCardCount++;
	//			break;
	//		}
	//		if (cbCardIndex[18]>0)
	//		{
	//			GangCardResult.cbGangType=WIK_SPE_YAOGANG;
	//			GangCardResult.cbCardData[GangCardResult.cbCardCount][0]=0x21;
	//			GangCardResult.cbCardCount++;
	//			break;
	//		}
	//	}
	//	if (cbWeaveKind==WIK_SPE_JIUGANG)
	//	{
	//		if ((cbCardIndex[8]<=0)&&(cbCardIndex[17]<=0)&&(cbCardIndex[26]<=0))
	//		{
	//			continue;
	//		}
	//		cbWeaveKindType|=WIK_GANG;
	//		if (cbCardIndex[8]>0)
	//		{
	//			GangCardResult.cbGangType=WIK_SPE_JIUGANG;

	//			GangCardResult.cbCardData[GangCardResult.cbCardCount][0]=0x09;
	//			GangCardResult.cbCardCount++;
	//			break;
	//		}
	//		if (cbCardIndex[17]>0)
	//		{
	//			GangCardResult.cbGangType=WIK_SPE_JIUGANG;
	//			GangCardResult.cbCardData[GangCardResult.cbCardCount][0]=0x19;
	//			GangCardResult.cbCardCount++;
	//			break;
	//		}
	//		if (cbCardIndex[26]>0)
	//		{
	//			GangCardResult.cbGangType=WIK_SPE_JIUGANG;
	//			GangCardResult.cbCardData[GangCardResult.cbCardCount][0]=0x29;
	//			GangCardResult.cbCardCount++;
	//			break;
	//		}
	//	}
	//	if (cbWeaveKind==WIK_SPE_FENGGANG)
	//	{
	//		if ((cbCardIndex[27]<=0)&&(cbCardIndex[28]<=0)&&(cbCardIndex[29]<=0)&&(cbCardIndex[30]<=0))
	//		{
	//			continue;
	//		}
	//		cbWeaveKindType|=WIK_GANG;
	//		if (cbCardIndex[27]>0)
	//		{
	//			GangCardResult.cbGangType=WIK_SPE_FENGGANG;

	//			GangCardResult.cbCardData[GangCardResult.cbCardCount][0]=0x31;
	//			GangCardResult.cbCardCount++;
	//			break;
	//		}
	//		if (cbCardIndex[28]>0)
	//		{
	//			GangCardResult.cbGangType=WIK_SPE_FENGGANG;
	//			GangCardResult.cbCardData[GangCardResult.cbCardCount][0]=0x32;
	//			GangCardResult.cbCardCount++;
	//			break;
	//		}
	//		if (cbCardIndex[29]>0)
	//		{
	//			GangCardResult.cbGangType=WIK_SPE_FENGGANG;
	//			GangCardResult.cbCardData[GangCardResult.cbCardCount][0]=0x33;
	//			GangCardResult.cbCardCount++;
	//			break;
	//		}
	//		if (cbCardIndex[30]>0)
	//		{
	//			GangCardResult.cbGangType=WIK_SPE_FENGGANG;
	//			GangCardResult.cbCardData[GangCardResult.cbCardCount][0]=0x34;
	//			GangCardResult.cbCardCount++;
	//			break;
	//		}
	//	}
	//	if (cbWeaveKind==WIK_SPE_BAIGANG)
	//	{
	//		if ((cbCardIndex[31]<=0)&&(cbCardIndex[32]<=0)&&(cbCardIndex[33]<=0))
	//		{
	//			continue;
	//		}
	//		cbWeaveKindType|=WIK_GANG;
	//		if (cbCardIndex[31]>0)
	//		{
	//			GangCardResult.cbGangType=WIK_SPE_BAIGANG;

	//			GangCardResult.cbCardData[GangCardResult.cbCardCount][0]=0x35;
	//			GangCardResult.cbCardCount++;
	//			break;
	//		}
	//		if (cbCardIndex[32]>0)
	//		{
	//			GangCardResult.cbGangType=WIK_SPE_BAIGANG;
	//			GangCardResult.cbCardData[GangCardResult.cbCardCount][0]=0x36;
	//			GangCardResult.cbCardCount++;
	//			break;
	//		}
	//		if (cbCardIndex[33]>0)
	//		{
	//			GangCardResult.cbGangType=WIK_SPE_BAIGANG;
	//			GangCardResult.cbCardData[GangCardResult.cbCardCount][0]=0x37;
	//			GangCardResult.cbCardCount++;
	//			break;
	//		}
	//	}
	//}
	return cbWeaveKindType;
}

//获取变牌后的数据
WORD CGameLogic::AnalyseChiHuCardAfterChangeCard(BYTE cbCardIndex[MAX_INDEX], BYTE cbCardIndexOut[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount, DWORD dwChiHuRight, tagChiHuData &chiHuDataTmp,bool iscalcLaizi/* = true*/)
{
		//变量定义
	DWORD dwChiHuKind=CHK_NULL;
	DWORD dwNewChiHuRight=CHK_NULL;
	CAnalyseItemArray AnalyseItemArray;
	//设置变量
	AnalyseItemArray.RemoveAll();

	//构造扑克
	BYTE cbCardIndexTemp[MAX_INDEX];
	CopyMemory(cbCardIndexTemp,cbCardIndex,sizeof(cbCardIndexTemp));
	CopyMemory(cbCardIndexOut,cbCardIndex,sizeof(cbCardIndexTemp));
	
	//分析扑克
	bool IsChiHu = AnalyseCard(cbCardIndexTemp,WeaveItem,cbItemCount,AnalyseItemArray,cbCardIndexTemp);
	// 优先进行七小对等的判断，此时cbCardIndexTemp会变
		if (chiHuDataTmp.m_bIsLaiZi)
	{
		BYTE zhongPaiIndex = getZhongPaiIndex(SwitchToCardIndex(chiHuDataTmp.m_tZhonePaiData.m_cbCurrentZhongPaiCardData),chiHuDataTmp.m_bIsLaiZi);
		BYTE HongZhongCount = 0;
		if (zhongPaiIndex != INVALID_BYTE)
		{
			HongZhongCount = cbCardIndexTemp[zhongPaiIndex];
		}
		if (HongZhongCount>0)
		{
			switch(HongZhongCount)
			{
			case 1:
				{
					dwChiHuRight |= analyseChangeOneCardSpecial(cbCardIndexTemp,WeaveItem,cbItemCount,AnalyseItemArray,false,zhongPaiIndex);
				}
				break;
			case 2:
				{
					dwChiHuRight |= analyseChangeTwoCardSpecial(cbCardIndexTemp,WeaveItem,cbItemCount,AnalyseItemArray,false,zhongPaiIndex);
				}
				break;
			case 3:
				{
					dwChiHuRight |= analyseChangeThreeCardSpecial(cbCardIndexTemp,WeaveItem,cbItemCount,AnalyseItemArray,false,zhongPaiIndex);
				}
				break;
			case 4:
				{
					dwChiHuRight |= analyseChangeFourCardSpecial(cbCardIndexTemp,WeaveItem,cbItemCount,AnalyseItemArray,false,zhongPaiIndex);
				}
				break;
			}
		}
	}
	CopyMemory(cbCardIndexOut,cbCardIndexTemp,sizeof(cbCardIndexTemp));
	
	return dwChiHuKind;
}

//吃胡分析
WORD CGameLogic::AnalyseChiHuCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, BYTE cbCurrentCard, DWORD dwChiHuRight, tagChiHuResult & ChiHuResult,BYTE m_cbQueMen, tagChiHuData &chiHuDataTmp,bool iscalcLaizi,bool isChaTing)
{
	//变量定义
	DWORD dwChiHuKind=CHK_NULL;
	DWORD dwNewChiHuRight=0;
	dwNewChiHuRight|=dwChiHuRight;
	m_blongqidui = false;
	CAnalyseItemArray AnalyseItemArray;

	//设置变量
	AnalyseItemArray.RemoveAll();
	ZeroMemory(&ChiHuResult,sizeof(ChiHuResult));

	//构造扑克
	BYTE cbCardIndexTemp[MAX_INDEX];
	CopyMemory(cbCardIndexTemp,cbCardIndex,sizeof(cbCardIndexTemp));

	BYTE cbCardIndexTemp2[MAX_INDEX];
	CopyMemory(cbCardIndexTemp2,cbCardIndex,sizeof(cbCardIndexTemp2));
	bool Isqingyise = false;
	bool Isqixiaodui = false;
	const BYTE kfansMaxCount = 17;
	int FansuDengji[kfansMaxCount];
	int FansuMaxDengji = 1;
	ZeroMemory(FansuDengji,sizeof(FansuDengji));
	m_cbCurrentCard = cbCurrentCard;
	BYTE zhonePaiIndex = getZhongPaiIndex(chiHuDataTmp.m_tZhonePaiData.m_cbCurrentZhongPaiCardData,chiHuDataTmp.m_bIsLaiZi);
	//插入扑克
	bool curDataIsHongZhong = false;
	if (cbCurrentCard!=0)
	{
		cbCardIndexTemp[SwitchToCardIndex(cbCurrentCard)]++;
		curDataIsHongZhong = SwitchToCardIndex(cbCurrentCard) == zhonePaiIndex && chiHuDataTmp.m_bIsTianHu == false && iscalcLaizi == false;
	}

	//分析扑克
	bool IsChiHu = AnalyseCard(cbCardIndexTemp,WeaveItem,cbWeaveCount,AnalyseItemArray,cbCardIndexTemp);
	// 优先进行七小对等的判断，此时cbCardIndexTemp会变
	if (chiHuDataTmp.m_bIsLaiZi && curDataIsHongZhong == false)
	{
		BYTE HongZhongCount = cbCardIndexTemp[zhonePaiIndex];
		if (HongZhongCount>0)
		{
			switch(HongZhongCount)
			{
			case 1:
				{
					dwChiHuRight |= analyseChangeOneCardSpecial(cbCardIndexTemp,WeaveItem,cbWeaveCount,AnalyseItemArray,isChaTing,zhonePaiIndex);
				}
				break;
			case 2:
				{
					dwChiHuRight |= analyseChangeTwoCardSpecial(cbCardIndexTemp,WeaveItem,cbWeaveCount,AnalyseItemArray,isChaTing,zhonePaiIndex);
				}
				break;
			case 3:
				{
					dwChiHuRight |= analyseChangeThreeCardSpecial(cbCardIndexTemp,WeaveItem,cbWeaveCount,AnalyseItemArray,isChaTing,zhonePaiIndex);
				}
				break;
			case 4:
				{
					dwChiHuRight |= analyseChangeFourCardSpecial(cbCardIndexTemp,WeaveItem,cbWeaveCount,AnalyseItemArray,isChaTing,zhonePaiIndex);
				}
				break;
			}
		}
	}
	if (dwChiHuRight != CHK_NULL)
	{
		IsChiHu = true;
	}
	//胡牌分析
	bool bChiJiaHu=false;
	bool IsPinghu = true;
	if (IsChiHu)
	{
		// 清一色
		if (IsQingYiSe(cbCardIndexTemp,WeaveItem,cbWeaveCount)|| ((dwChiHuRight & CHK_QINGYISE) != 0))
		{
			FansuDengji[0] = 2;
			dwChiHuKind |= CHK_QINGYISE;
		}
		//// 混一色牌
		//if (IsHunYiSe(cbCardIndexTemp,WeaveItem,cbWeaveCount)|| ((dwChiHuRight & CHK_HUNYISE) != 0))
		//{
		//	FansuDengji[1] = 2;
		//	dwChiHuKind |= CHK_HUNYISE;
		//}
		//// 字一色牌
		//if (IsZiYiSe(cbCardIndexTemp,WeaveItem,cbWeaveCount)|| ((dwChiHuRight & CHK_ZIYISE) != 0))
		//{
		//	FansuDengji[2] = 13;
		//	dwChiHuKind |= CHK_ZIYISE;
		//}
		//// 纯幺九
		//if (IsChunSanJiu(cbCardIndexTemp,WeaveItem,cbWeaveCount)|| ((dwChiHuRight & CHK_QINGYAOJIU_HU) != 0))
		//{
		//	FansuDengji[10] = 13;
		//	dwChiHuKind |= CHK_QINGYAOJIU_HU;
		//}
		//// 混幺九
		//if (IsHunSanJiu(cbCardIndexTemp,WeaveItem,cbWeaveCount) || ((dwChiHuRight & CHK_HUNYAOJIAO) != 0))
		//{
		//	FansuDengji[11] = 9;
		//	dwChiHuKind |= CHK_HUNYAOJIAO;
		//}
		// 碰碰胡
		if (IsPenPenHu(cbCardIndexTemp,WeaveItem,cbWeaveCount,cbCardIndexTemp2)|| ((dwChiHuRight & CHK_PENPEN_HU) != 0))
		{
			FansuDengji[3] = 2;
			dwChiHuKind |= CHK_PENPEN_HU;
		}
		if (chiHuDataTmp.m_bIsLaiZi && IsLuoDiHu(cbCardIndexTemp,WeaveItem,cbWeaveCount,cbCardIndexTemp2)|| ((dwChiHuRight & CHK_TWELVE_LUO_DI) != 0))
		{
			FansuDengji[4] = 4;
			dwChiHuKind |= CHK_TWELVE_LUO_DI;
		}
		//// 坎坎胡
		//if (IsKanKanHu(cbCardIndexTemp,WeaveItem,cbWeaveCount)|| ((dwChiHuRight & CHK_KANKANHU) != 0))
		//{
		//	FansuDengji[4] = 10;
		//	dwChiHuKind |= CHK_KANKANHU;
		//}
		// 七小对
		if (IsQiXiaoDui(cbCardIndexTemp,WeaveItem,cbWeaveCount,cbCardIndexTemp2) || ((dwChiHuRight & CHK_QIDUI) != 0))
		{
			FansuDengji[5] = 2;
			dwChiHuKind |= CHK_QIDUI;
		}
		// 豪华七小对
		if (IsHaoHuaQiXiaoDui(cbCardIndexTemp,WeaveItem,cbWeaveCount,cbCardIndexTemp2) || ((dwChiHuRight & CHK_HAOHUA_QIDUI) != 0))
		{
			FansuDengji[6] = 4;
			dwChiHuKind |= CHK_HAOHUA_QIDUI;
		}
		//// 双豪华七小对
		//if (IsDHaoHuaQiXiaoDui(cbCardIndexTemp,WeaveItem,cbWeaveCount,cbCardIndexTemp2) || ((dwChiHuRight & CHK_DHAOHUA_QIDUI) != 0))
		//{
		//	FansuDengji[7] = 16;
		//	dwChiHuKind |= CHK_DHAOHUA_QIDUI;
		//}
		//// 三豪华七小对
		//if (IsTHaoHuaQiXiaoDui(cbCardIndexTemp,WeaveItem,cbWeaveCount,cbCardIndexTemp2) || ((dwChiHuRight & CHK_THAOHUA_QIDUI) != 0))
		//{
		//	FansuDengji[8] = 24;
		//	dwChiHuKind |= CHK_THAOHUA_QIDUI;
		//}
		// 十三幺
		if (IsShiSanYao(cbCardIndexTemp,WeaveItem,cbWeaveCount) || ((dwChiHuRight & CHK_TENTHREEYAO) != 0))
		{
			FansuDengji[9] = 4;
			dwChiHuKind |= CHK_TENTHREEYAO;
		}

		//// 十八罗汉
		//if (IsTenEightLuoHan(cbCardIndexTemp,WeaveItem,cbWeaveCount)|| ((dwChiHuRight & CHK_LUOHAN) != 0))
		//{
		//	FansuDengji[12] = 18;
		//	dwChiHuKind |= CHK_LUOHAN;
		//}

		//// 如果是大胡玩法，鸡胡不能自摸就返回
		//if (dwChiHuKind == CHK_NULL && !chiHuDataTmp.m_bIsJiChuWanFa && !chiHuDataTmp.m_bJiHuZiMo)
		//{
		//	return WIK_NULL;
		//}

		// 天地胡
		if (chiHuDataTmp.m_bIsTianHu)
		{
			FansuDengji[13] = 4;
			dwChiHuKind |= CHK_TIAN_HU;
		}
		else if (chiHuDataTmp.m_bIsDiHu)
		{
			
			if (chiHuDataTmp.m_nDiHuTwo > 0)
			{
				FansuDengji[12] = 2;
			}
			else
			{
				FansuDengji[12] = 1;
			}
			dwChiHuKind |= CHK_DI_HU;
		}
		// 海底炮
		if(chiHuDataTmp.m_bHaidilao)
		{
			if (chiHuDataTmp.m_nHaiDiLaoYueTwo > 0)
			{
				FansuDengji[14] = 2;
			}
			else
			{
				FansuDengji[14] = 1;
			}
			dwChiHuKind |= CHK_HAIDI_PAO;
		}
		// 杠上开花
		if (chiHuDataTmp.m_bIsGangKai)
		{
			FansuDengji[15] = 2;
			dwChiHuKind |= CHK_GANG_KAI;
		}

		// 只有海底炮加1，只有杠上开花加1，只有海底胡和杠上开花加1
		if (dwChiHuKind == CHK_NULL || (dwChiHuKind == CHK_HAIDI_PAO) || (dwChiHuKind == CHK_GANG_KAI) || (dwChiHuKind != CHK_NULL && ((dwChiHuKind & ~CHK_HAIDI_PAO) & ~CHK_GANG_KAI ) == CHK_NULL))
		{
			FansuDengji[16] = 1;
		}
		dwChiHuKind |=CHK_PING_HU;	//平湖
		
	}
	//结果判断
	if (dwChiHuKind!=CHK_NULL)
	{
		//设置番数
		ChiHuResult.dwWinTimes=0;
		for (int i=0;i<kfansMaxCount;i++)
		{
			if(FansuDengji[i] > 0)
			{
				FansuMaxDengji *= FansuDengji[i];
			}
		}		

		DWORD dwHuPaiKind=dwChiHuKind;
		//设置牌型		
		ChiHuResult.dwChiHuKind=dwHuPaiKind;
		ChiHuResult.dwWinTimes = FansuMaxDengji;
		dwHuPaiKind|=dwChiHuRight;
		ChiHuResult.dwChiHuRight=dwHuPaiKind;

		return WIK_CHI_HU;
	}
	return WIK_NULL;
}

//吃胡分析并得到最终的胡牌数据
bool CGameLogic::AnalyseChiHuCardAndChangeData(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, BYTE cbCurrentCard,tagChiHuData &chiHuDataTmp)
{
		//变量定义
	DWORD dwChiHuKind=CHK_NULL;
	m_blongqidui = false;
	CAnalyseItemArray AnalyseItemArray;

	//设置变量
	AnalyseItemArray.RemoveAll();

	//构造扑克
	BYTE cbCardIndexTemp[MAX_INDEX];
	CopyMemory(cbCardIndexTemp,cbCardIndex,sizeof(cbCardIndexTemp));
	bool Isqingyise = false;
	bool Isqixiaodui = false;
	const BYTE kfansMaxCount = 17;
	int FansuDengji[kfansMaxCount];
	int FansuMaxDengji = 0;
	ZeroMemory(FansuDengji,sizeof(FansuDengji));
	m_cbCurrentCard = cbCurrentCard;
	//插入扑克
	if (cbCurrentCard!=0)
		cbCardIndexTemp[SwitchToCardIndex(cbCurrentCard)]++;

	//分析扑克
	bool IsChiHu = AnalyseCard(cbCardIndexTemp,WeaveItem,cbWeaveCount,AnalyseItemArray,cbCardIndexTemp);
	if (!IsChiHu && chiHuDataTmp.m_bIsLaiZi)
	{
		BYTE HongZhongCount = 0;
		BYTE zhongPaiIndex = getZhongPaiIndex(chiHuDataTmp.m_tZhonePaiData.m_cbCurrentZhongPaiCardData,chiHuDataTmp.m_bIsLaiZi);
		if (zhongPaiIndex != INVALID_BYTE)
		{
			HongZhongCount = cbCardIndex[zhongPaiIndex];
		}
		if (HongZhongCount>0)
		{
			switch(HongZhongCount)
			{
			case 1:
				{
					IsChiHu = AnalyseChangOneCardAndChange(cbCardIndexTemp,WeaveItem,cbWeaveCount,AnalyseItemArray,zhongPaiIndex);
				}
				break;
			case 2:
				{
					IsChiHu = AnalyseChangTwoCardAndChange(cbCardIndexTemp,WeaveItem,cbWeaveCount,AnalyseItemArray,zhongPaiIndex);
				}
				break;
			case 3:
				{
					IsChiHu = AnalyseChangThreeCardAndChange(cbCardIndexTemp,WeaveItem,cbWeaveCount,AnalyseItemArray,zhongPaiIndex);
				}
				break;
			case 4:
				{
					IsChiHu = AnalyseChangFourCardAndChange(cbCardIndexTemp,WeaveItem,cbWeaveCount,AnalyseItemArray,zhongPaiIndex);
				}
				break;
			}
		}
	}
	return IsChiHu;
}

//十三夭牌
bool CGameLogic::IsShiSanYao(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount)
{
	//组合判断
	if (cbWeaveCount!=0) return false;

	//扑克判断
	bool bCardEye=false;

	//一九判断
	for (BYTE i=0;i<MAX_INDEX;i+=9)
	{
		//无效判断
		if (cbCardIndex[i]==0) return false;
		if (cbCardIndex[i+8]==0) return false;

		//牌眼判断
		if ((bCardEye==false)&&(cbCardIndex[i]==2)) bCardEye=true;
		if ((bCardEye==false)&&(cbCardIndex[i+8]==2)) bCardEye=true;
	}

	//番子判断
	for (BYTE i= 27;i<MAX_INDEX;i++)
	{
		if (cbCardIndex[i]==0) return false;
		if ((bCardEye==false)&&(cbCardIndex[i]==2)) bCardEye=true;
	}

	//牌眼判断
	if (bCardEye==false) return false;

	return true;
}

//纯幺九
bool CGameLogic::IsChunSanJiu(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount)
{
	for (BYTE i= 0;i<MAX_INDEX;i++)
	{
		if (cbCardIndex[i] != 0)
		{
			BYTE cbCardColor=(SwitchToCardData(i)&MASK_COLOR) >> 4;
			// 如果是字的话
			if (cbCardColor == 3)
			{
				return false;
			}
			BYTE cbCardValue=(SwitchToCardData(i)&MASK_VALUE);
			if (!(cbCardValue == 0x01 || cbCardValue == 0x09))
			{
				return false;
			}
		}
	}

	//组合判断
	for (BYTE i=0;i<cbWeaveCount;i++)
	{
		BYTE cbCenterCard=WeaveItem[i].cbCenterCard;
		BYTE cbCardValue=(cbCenterCard&MASK_VALUE);
		if (!(cbCardValue == 0x01 || cbCardValue == 0x09))
		{
			return false;
		}
	}

	return true;
}

//混幺九
bool CGameLogic::IsHunSanJiu(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount)
{
	if(IsShiSanYao(cbCardIndex,WeaveItem,cbWeaveCount))
	{
		return false;
	}
	BYTE ziCount = 0;
	BYTE count = 0;
	for (BYTE i= 0;i<MAX_INDEX;i++)
	{
		if (cbCardIndex[i] != 0)
		{
			BYTE cbCardColor=(SwitchToCardData(i)&MASK_COLOR) >> 4;
			// 如果是字的话
			if (cbCardColor == 3)
			{
				++ziCount;
				continue;
			}
			BYTE cbCardValue=(SwitchToCardData(i)&MASK_VALUE);
			if (!(cbCardValue == 0x01 || cbCardValue == 0x09))
			{
				return false;
			}
			count++;
		}
	}

		//组合判断
	for (BYTE i=0;i<cbWeaveCount;i++)
	{
		BYTE cbCenterCard=WeaveItem[i].cbCenterCard;
		BYTE cbCardColor=(cbCenterCard&MASK_COLOR) >> 4;
		BYTE cbCardValue=(cbCenterCard&MASK_VALUE);
		// 如果是字的话
		if (cbCardColor == 3)
		{
			++ziCount;
			continue;
		}
		if (!(cbCardValue == 0x01 || cbCardValue == 0x09))
		{
			return false;
		}
		count++;
	}

	if (ziCount <= 0 || count <= 0)
	{
		return false;
	}

	return true;
}

// 十八罗汉
bool CGameLogic::IsTenEightLuoHan(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount)
{
	if (cbWeaveCount != 4)
	{
		return false;
	}

	for (int i = 0; i < cbWeaveCount; i++)
	{
		if (WeaveItem[i].cbWeaveKind != WIK_GANG)
		{
			return false;
		}
	}

	for (int i = 0; i < MAX_INDEX; i++)
	{
		if (cbCardIndex[i] == 1 || cbCardIndex[i] == 3 || cbCardIndex[i] == 4)
		{
			return false;
		}
	}

	return true;
}

// 天地胡
bool CGameLogic::IsTianDiHu(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount)
{
	return m_bTianHu || m_bDiHu;
}

// 获取牌里面的对子数
BYTE CGameLogic::getDuiCount(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount)
{
	BYTE count = 0;
	for (int i = 0; i < MAX_INDEX; i++)
	{
		if (cbCardIndex[i] == 2)
		{
			++count;
		}
	}
	return count;
}

// 获取三个相同牌的数量
BYTE CGameLogic::getKeZiCount(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount)
{
	BYTE count = 0;
	for (int i = 0; i < MAX_INDEX; i++)
	{
		if (cbCardIndex[i] == 3)
		{
			++count;
		}
	}
	return count;
}

// 获取四个相同牌的数量
BYTE CGameLogic::getFourKeZiCount(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount)
{
	BYTE count = 0;
	for (int i = 0; i < MAX_INDEX; i++)
	{
		if (cbCardIndex[i] == 4)
		{
			++count;
		}
	}
	return count;
}

//胡牌番数
bool CGameLogic::PanShu(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount)
{
	return false;
}
//开门判断（吃、叉或明杠牌），暗杠不算开门。返回false:闭门;true:开门
bool CGameLogic::IsWeaveItemPublic(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount)
{
	bool bWeaveItemPublic=false;
	for (int i=0; i<cbItemCount; i++)
	{
		if (WeaveItem[i].cbPublicCard==true)
		{
			bWeaveItemPublic=true;
			break;
		}
	}
	return bWeaveItemPublic;
}
//不能缺1，9，当手牌中有风、字牌的时候可免1、9。
bool CGameLogic::IsYaoJiu(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount)
{
	//m_cbAIQueYaojiu = false;
	//组合牌判断
	//for (BYTE i=0;i<cbItemCount;i++)
	//{
	//	if ((WeaveItem[i].cbWeaveKind==WIK_SPE_YAOGANG)||(WeaveItem[i].cbWeaveKind==WIK_SPE_JIUGANG)||(WeaveItem[i].cbWeaveKind==WIK_SPE_FENGGANG)||(WeaveItem[i].cbWeaveKind==WIK_SPE_BAIGANG))
	//	{
	//		return true;
	//	}
	//	if ((WeaveItem[i].cbWeaveKind==WIK_PENG)||(WeaveItem[i].cbWeaveKind==WIK_GANG))
	//	{
	//		if ((WeaveItem[i].cbCenterCard==0x31)||(WeaveItem[i].cbCenterCard==0x32)||(WeaveItem[i].cbCenterCard==0x33)||(WeaveItem[i].cbCenterCard==0x34)||(WeaveItem[i].cbCenterCard==0x35)||(WeaveItem[i].cbCenterCard==0x36)||(WeaveItem[i].cbCenterCard==0x37))
	//		{
	//			return true;
	//		}
	//		if ((WeaveItem[i].cbCenterCard==0x01)||(WeaveItem[i].cbCenterCard==0x09)||(WeaveItem[i].cbCenterCard==0x11)||(WeaveItem[i].cbCenterCard==0x19)||(WeaveItem[i].cbCenterCard==0x21)||(WeaveItem[i].cbCenterCard==0x29))
	//		{
	//			return true;
	//		}
	//	}
	//	if ((WeaveItem[i].cbWeaveKind==WIK_LEFT))
	//	{
	//		if ((WeaveItem[i].cbCenterCard==0x01)||(WeaveItem[i].cbCenterCard==(0x09-2))||(WeaveItem[i].cbCenterCard==0x11)||(WeaveItem[i].cbCenterCard==(0x19-2))||(WeaveItem[i].cbCenterCard==0x21)||(WeaveItem[i].cbCenterCard==(0x29-2)))
	//		{
	//			return true;
	//		}
	//	}
	//	if ((WeaveItem[i].cbWeaveKind==WIK_CENTER))
	//	{
	//		if ((WeaveItem[i].cbCenterCard==(0x01+1))||(WeaveItem[i].cbCenterCard==(0x09-1))||(WeaveItem[i].cbCenterCard==(0x11+1))||(WeaveItem[i].cbCenterCard==(0x19-1))||(WeaveItem[i].cbCenterCard==(0x21+1))||(WeaveItem[i].cbCenterCard==(0x29-1)))
	//		{
	//			return true;
	//		}
	//	}
	//	if ((WeaveItem[i].cbWeaveKind==WIK_RIGHT))
	//	{
	//		if ((WeaveItem[i].cbCenterCard==(0x01+2))||(WeaveItem[i].cbCenterCard==0x09)||(WeaveItem[i].cbCenterCard==(0x11+2))||(WeaveItem[i].cbCenterCard==0x19)||(WeaveItem[i].cbCenterCard==(0x21+2))||(WeaveItem[i].cbCenterCard==0x29))
	//		{
	//			return true;
	//		}
	//	}

	//}
	////手上牌判断
	//if ((cbCardIndex[27]>1)||(cbCardIndex[28]>1)||(cbCardIndex[29]>1)||(cbCardIndex[30]>1)||(cbCardIndex[31]>1)||(cbCardIndex[32]>1)||(cbCardIndex[33]>1))
	//{
	//	return true;
	//}
	//if ((cbCardIndex[0]>0)||(cbCardIndex[8]>0)||(cbCardIndex[9]>0)||(cbCardIndex[17]>0)||(cbCardIndex[18]>0)||(cbCardIndex[26]>0))
	//{
	//	return true;
	//}
	//m_cbAIQueYaojiu = true;
	return true;
}
//必须少缺门才能胡，即没有该花色才能胡牌。
bool CGameLogic::IsShaoHuaSe(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount,BYTE cbQueHuaSe)
{
	bool m_QueWangZi = true;
	bool m_QueTiaoZi = true;
	bool m_QueTongZi = true;
	for (BYTE i=0;i<MAX_INDEX;i++)
	{
		if (cbCardIndex[i]!=0)
		{
			//设置花色
			if (i>=18&&i<27)
			{
				m_QueTongZi = false;
			}
			if (i>=9&&i<18)
			{
				m_QueTiaoZi = false;
			}
			if (i>=0&&i<9)
			{
				m_QueWangZi = false;
			}
		}
	}
	for (BYTE i=0;i<cbItemCount;i++)
	{
		if (WeaveItem[i].cbCenterCard<0x30)
		{
			int nIndex=SwitchToCardIndex(WeaveItem[i].cbCenterCard);
			if (nIndex>=18&&nIndex<27)
			{
				m_QueTongZi = false;
			}
			if (nIndex>=9&&nIndex<18)
			{
				m_QueTiaoZi = false;
			}
			if (nIndex>=0&&nIndex<9)
			{
				m_QueWangZi = false;
			}

		}
	}
	switch(cbQueHuaSe)
	{
	case 0:
		if (m_QueWangZi)
		{
			return true;
		}
		break;
	case 1:
		if (m_QueTiaoZi)
		{
			return true;
		}
		break;
	case 2:
		if (m_QueTongZi)
		{
			return true;
		}
		break;
	default:
		return false;
		break;
	}
	return false;
}
//清一色牌
bool CGameLogic::IsQingYiSe(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount)
{
	//胡牌判断
	BYTE cbCardColor=0xFF;
	for (BYTE i=0;i<MAX_INDEX;i++)
	{
		if (cbCardIndex[i]!=0)
		{
			//花色判断
			if (cbCardColor!=0xFF)
				return false;
			//设置花色
			cbCardColor=(SwitchToCardData(i)&MASK_COLOR) >> 4;
			if (cbCardColor == 3)
			{
				return false;
			}
			//设置索引
			i=(i/9+1)*9-1;
		}
	}

	//组合判断
	for (BYTE i=0;i<cbItemCount;i++)
	{
		BYTE cbCenterCard=WeaveItem[i].cbCenterCard;
		BYTE cbCenterColor = (cbCenterCard&MASK_COLOR)>>4;
		if (cbCenterColor !=cbCardColor)
			return false;
	}

	return true;
}

//混一色牌
bool CGameLogic::IsHunYiSe(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount)
{
	//最后一种花色的类型胡牌判断
	BYTE cbCardColor=0xFF;
	// 花色数量
	BYTE cbCardCount = 0;
	BYTE cbCardColors[4] = {0};
	const BYTE colorKind = 4;
	for (BYTE i=0;i<MAX_INDEX;i++)
	{
		if (cbCardIndex[i]!=0)
		{
			//设置花色
			cbCardColor=(SwitchToCardData(i)&MASK_COLOR) >> 4;
			if (cbCardColors[cbCardColor%colorKind] == 0)
			{
				++cbCardCount;
			}
			cbCardColors[cbCardColor%colorKind]= 1;
			//设置索引
			i=(i/9+1)*9-1;
		}
	}

	//组合判断
	for (BYTE i=0;i<cbItemCount;i++)
	{
		BYTE cbCenterCard=WeaveItem[i].cbCenterCard;
		BYTE cbCenterColor = (cbCenterCard&MASK_COLOR)>>4 ;
		if (cbCardColors[cbCenterColor%colorKind] == 0)
		{
			++cbCardCount;
		}
		cbCardColors[cbCenterColor%colorKind] = 1;
	}

		// 花色不只两种,或者最后一种花色不是字牌类型
	if (cbCardCount != 2 || cbCardColors[3] != 1)
	{
		return false;
	}

	return true;
}

//字一色牌
bool CGameLogic::IsZiYiSe(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount)
{
		//胡牌判断
	BYTE cbCardColor=0xFF;
	for (BYTE i=0;i<MAX_INDEX;i++)
	{
		if (cbCardIndex[i]!=0)
		{
			//设置花色
			cbCardColor=((SwitchToCardData(i)&MASK_COLOR))>>4;
			if (cbCardColor != 3)
			{
				return false;
			}
			//设置索引
			i=(i/9+1)*9-1;
		}
	}

	//组合判断
	for (BYTE i=0;i<cbItemCount;i++)
	{
		BYTE cbCenterCard=WeaveItem[i].cbCenterCard;
		BYTE cbCenterColor = (cbCenterCard&MASK_COLOR) >> 4;
		if ( cbCenterColor !=cbCardColor)
			return false;
	}

	return true;
}

//碰碰胡
bool CGameLogic::IsPenPenHu(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount,BYTE cbCardIndexTemp[MAX_INDEX])
{
	BYTE duiCount = 0;
	for (int i = 0; i < MAX_INDEX; i++)
	{
		if (cbCardIndex[i] == 1)
		{
			return false;
		}

		if (cbCardIndex[i]  == 2)
		{
			if (duiCount > 0)
			{
				return false;
			}
			// 十二张落地
			if (cbItemCount == 4 && cbCardIndexTemp[i] == 2)
			{
				return false;
			}
			++duiCount;
		}
	}

	for (int i = 0; i < cbItemCount; i++)
	{
		if (WeaveItem[i].cbWeaveKind != WIK_PENG && WeaveItem[i].cbWeaveKind != WIK_GANG)
		{
			return false;
		}
	}

	return true;
}

//第二张落地
bool CGameLogic::IsLuoDiHu(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount,BYTE cbCardIndexTemp[MAX_INDEX])
{
	if (cbItemCount != 4)
	{
		return false;
	}

	BYTE duiCount = 0;
	for (int i = 0; i < MAX_INDEX; i++)
	{
		if (cbCardIndex[i] == 1 || cbCardIndex[i] == 4 || cbCardIndex[i] == 3)
		{
			return false;
		}

		if (cbCardIndex[i]  == 2 && cbCardIndexTemp[i] != 2)
		{
			return false;
		}
	}

	return true;
}

//坎坎胡	
bool CGameLogic::IsKanKanHu(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount)
{
	if (cbItemCount != 0)
		return false;
	//扑克判断
	BYTE duiCount = 0;
	for (BYTE i=0;i<MAX_INDEX;i++)
	{
		if (cbCardIndex[i] == 2)
		{
			if (duiCount)
			{
				return false;
			}
			++duiCount;
		}
		else if (cbCardIndex[i] == 4 || cbCardIndex[i] == 1)
		{
			return false;
		}
	}

	return true;
}

//七小对牌
bool CGameLogic::IsQiXiaoDui(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount,BYTE cbCardIndexTemp[MAX_INDEX])
{
	//组合判断
	if (cbWeaveCount!=0) 
		return false;
	//扑克判断
	int count = 0;
	for (BYTE i=0;i<MAX_INDEX;i++)
	{

		BYTE cbCardCount=cbCardIndex[i];
		if (cbCardCount > 0)
		{
			if ((cbCardCount==3 || cbCardCount==1)) 
			{
				return false;
			}
			// 如果种牌变牌后成4就是七小对
			if (cbCardCount == 4 && cbCardIndexTemp[i] == 4)
			{
				// 龙七对
				return false;
			}

			if (cbCardCount == 4)
			{
				if (count > 0)
				{
					return false;
				}
				++count;
			}
		}
		
	}
	return true;
}

//豪华七小对
bool CGameLogic::IsHaoHuaQiXiaoDui(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount,BYTE cbCardIndexTemp[MAX_INDEX])
{
	//组合判断
	if (cbItemCount!=0) 
		return false;
	BYTE fourCount = 0;
	//扑克判断
	for (BYTE i=0;i<MAX_INDEX;i++)
	{
		BYTE cbCardCount=cbCardIndex[i];
		if (cbCardCount > 0 )
		{
			if ((cbCardCount==3 || cbCardCount==1))  
				return false;
			if (cbCardCount == 4 && cbCardIndexTemp[i] == 4)
			{
				++fourCount;
			}
		}
		
	}
	if (fourCount != 1)
	{
		return false;
	}
	return true;
}

//双豪华七小对
bool CGameLogic::IsDHaoHuaQiXiaoDui(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount,BYTE cbCardIndexTemp[MAX_INDEX])
{
	//组合判断
	if (cbItemCount!=0) 
		return false;
	BYTE fourCount = 0;
	//扑克判断
	for (BYTE i=0;i<MAX_INDEX;i++)
	{
		BYTE cbCardCount=cbCardIndex[i];
		if (cbCardCount > 0 )
		{
			if ((cbCardCount==3 || cbCardCount==1))  
				return false;
			if (cbCardCount == 4 && cbCardIndexTemp[i] == 4)
			{
				++fourCount;
			}
		}
	}
	if (fourCount != 2)
	{
		return false;
	}
	return true;
}

//三豪华七小对
bool CGameLogic::IsTHaoHuaQiXiaoDui(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount,BYTE cbCardIndexTemp[MAX_INDEX])
{
	//组合判断
	if (cbItemCount!=0) 
		return false;
	BYTE fourCount = 0;
	//扑克判断
	for (BYTE i=0;i<MAX_INDEX;i++)
	{
		BYTE cbCardCount=cbCardIndex[i];
		if ((cbCardCount!=0)&&(cbCardCount!=2)&&(cbCardCount!=4)) 
			return false;
		if (cbCardCount == 4 && cbCardIndexTemp[i] == 4)
		{
			++fourCount;
		}
	}
	if (fourCount != 3)
	{
		return false;
	}
	return true;
}
//获取四归一的数目
BYTE CGameLogic::GetFourtoOneCount(BYTE cbCardIndex[MAX_INDEX],tagWeaveItem WeaveItem[], BYTE cbWeaveCount)
{
	BYTE GenCount=0;
	BYTE tmpCardIndex[MAX_INDEX];
	CopyMemory(tmpCardIndex,cbCardIndex,sizeof(tmpCardIndex));
	for (BYTE i=0;i<cbWeaveCount;i++)
	{
		BYTE cbCenterCard=WeaveItem[i].cbCenterCard;
		WORD cbWeaveKind = WeaveItem[i].cbWeaveKind;
		BYTE cbIndex=SwitchToCardIndex(cbCenterCard);
		/*if ((cbWeaveKind&WIK_GANG)!=0)
		{
			tmpCardIndex[cbIndex]+=4;
		} 
		else*/ 
		if ((cbWeaveKind&WIK_PENG)!=0)
		{
			tmpCardIndex[cbIndex]+=3;
		}
		else if ((cbWeaveKind&WIK_LEFT)!=0)
		{
			tmpCardIndex[cbIndex]+=1;
			tmpCardIndex[cbIndex+1]+=1;
			tmpCardIndex[cbIndex+2]+=1;
		} 
		else if ((cbWeaveKind&WIK_CENTER)!=0)
		{
			tmpCardIndex[cbIndex]+=1;
			tmpCardIndex[cbIndex-1]+=1;
			tmpCardIndex[cbIndex+1]+=1;
		}
		else if ((cbWeaveKind&WIK_RIGHT)!=0)
		{
			tmpCardIndex[cbIndex]+=1;
			tmpCardIndex[cbIndex-1]+=1;
			tmpCardIndex[cbIndex-2]+=1;
		}
	}
	for (BYTE i=0;i<MAX_INDEX;i++)
	{
		BYTE cbCardCount=tmpCardIndex[i];	
		if ((cbCardCount==4)) 
		{
			GenCount++;
		}
	}
	return GenCount;
}
//特殊胡牌
WORD CGameLogic::EstimateChiHu(BYTE cbCardIndex[MAX_INDEX],BYTE cbZhongPaiIndex)
{
	if (cbZhongPaiIndex != INVALID_BYTE &&  cbCardIndex[cbZhongPaiIndex]==4)
	{
		return WIK_CHI_HU;
	} 
	else
	{
		return WIK_NULL;
	}
}
//扑克转换
BYTE CGameLogic::SwitchToCardData(BYTE cbCardIndex)
{
	ASSERT(cbCardIndex<MAX_INDEX);
	return ((cbCardIndex/9)<<4)|(cbCardIndex%9+1);
}

//扑克转换
BYTE CGameLogic::SwitchToCardIndex(BYTE cbCardData)
{
	ASSERT(IsValidCard(cbCardData));
	return ((cbCardData&MASK_COLOR)>>4)*9+(cbCardData&MASK_VALUE)-1;
}

//扑克转换
BYTE CGameLogic::SwitchToCardData(BYTE cbCardIndex[MAX_INDEX], BYTE cbCardData[MAX_COUNT])
{
	//转换扑克
	BYTE cbPosition=0;
	for (BYTE i=0;i<MAX_INDEX;i++)
	{
		if (cbCardIndex[i]!=0)
		{
			for (BYTE j=0;j<cbCardIndex[i];j++)
			{
				ASSERT(cbPosition<MAX_COUNT);
				cbCardData[cbPosition++]=SwitchToCardData(i);
			}
		}
	}

	return cbPosition;
}

//扑克转换  将cbCardData 复制到 cbCardIndex
BYTE CGameLogic::SwitchToCardIndex(BYTE cbCardData[], BYTE cbCardCount, BYTE cbCardIndex[MAX_INDEX])
{
	//设置变量
	ZeroMemory(cbCardIndex,sizeof(BYTE)*MAX_INDEX);

	//转换扑克
	for (BYTE i=0;i<cbCardCount;i++)
	{
		ASSERT(IsValidCard(cbCardData[i]));
		cbCardIndex[SwitchToCardIndex(cbCardData[i])]++;
	}

	return cbCardCount;
}
int CGameLogic::MinQuemenType(BYTE cbCardIndex[MAX_INDEX])
{
	int type = 0;
	int wanzi=0;
	int tiaozi=0;
	int tongzi=0;
	for (int i=0;i<MAX_INDEX;i++)
	{
		if (cbCardIndex[i]==0)  continue;
		if (cbCardIndex[i]>0)
		{
			if (i<9)
				wanzi+=cbCardIndex[i];
			else if(i>8&&i<18)
				tiaozi+=cbCardIndex[i];
			else if(i>17)
				tongzi+=cbCardIndex[i];
		}
	}
	if (wanzi==tiaozi && tiaozi==tongzi)
		type = rand()%3;
	else if( wanzi<=tiaozi && wanzi<=tongzi) 
		type = 0;
	else if( tiaozi<=wanzi && tiaozi<=tongzi) 
		type = 1;
	else if( tongzi<=wanzi && tongzi<=tiaozi)
		type = 2;
	return  type;
}
//判断玩家是否需要发牌
bool CGameLogic::IsNeedCard(BYTE cbCardIndex[MAX_INDEX])
{
	//计算数目
	BYTE cbCardCount=0;
	bool Ismorecard = true;
	for (BYTE i=0;i<MAX_INDEX;i++) 
		cbCardCount+=cbCardIndex[i];
	if ((cbCardCount<=MAX_COUNT)&&((cbCardCount-2)%3==0))
	{
		Ismorecard = false;
	}
	return Ismorecard;
}
//分析扑克
bool CGameLogic::AnalyseCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbCardIndexTemp[MAX_INDEX])
{
	//计算数目
	BYTE cbCardCount=0;
	for (BYTE i=0;i<MAX_INDEX;i++) 
		cbCardCount+=cbCardIndex[i];

	//效验数目
	ASSERT((cbCardCount>=2)&&(cbCardCount<=MAX_COUNT)&&((cbCardCount-2)%3==0));
	if ((cbCardCount<2)||(cbCardCount>MAX_COUNT)||((cbCardCount-2)%3!=0))
		return false;

	//变量定义
	BYTE cbKindItemCount=0;
	tagKindItem KindItem[MAX_COUNT-2];
	ZeroMemory(KindItem,sizeof(KindItem));

	//需求判断
	BYTE cbLessKindItem=(cbCardCount-2)/3;
	ASSERT((cbLessKindItem+cbWeaveCount)==4);

	//单吊判断
	if (cbLessKindItem==0)
	{
		//效验参数
		ASSERT((cbCardCount==2)&&(cbWeaveCount==4));

		//牌眼判断
		for (BYTE i=0;i<MAX_INDEX;i++)
		{
			if (cbCardIndex[i]==2)
			{
				//变量定义
				tagAnalyseItem AnalyseItem;
				ZeroMemory(&AnalyseItem,sizeof(AnalyseItem));

				//设置结果
				for (BYTE j=0;j<cbWeaveCount;j++)
				{
					AnalyseItem.cbWeaveKind[j]=WeaveItem[j].cbWeaveKind;
					AnalyseItem.cbCenterCard[j]=WeaveItem[j].cbCenterCard;
					AnalyseItem.bWeave[j]=true;
				}
				AnalyseItem.cbCardEye=SwitchToCardData(i);

				//插入结果
				AnalyseItemArray.Add(AnalyseItem);

				return true;
			}
		}

		return false;
	}

	//拆分分析
	if (cbCardCount>=3)
	{
		//鸡胡玩法不算这些,特殊处理七小对，十三幺，豪华七小对,双豪华七小对
		if (IsQiXiaoDui(cbCardIndex,WeaveItem,cbWeaveCount,cbCardIndexTemp) || IsHaoHuaQiXiaoDui(cbCardIndex,WeaveItem,cbWeaveCount,cbCardIndexTemp)
			|| IsShiSanYao(cbCardIndex,WeaveItem,cbWeaveCount))
		{
			return true;
		}
		for (BYTE i=0;i<MAX_INDEX;i++)
		{
			//同牌判断
			if (cbCardIndex[i]>=3)
			{
				KindItem[cbKindItemCount].cbCardIndex[0]=i;
				KindItem[cbKindItemCount].cbCardIndex[1]=i;
				KindItem[cbKindItemCount].cbCardIndex[2]=i;
				KindItem[cbKindItemCount].cbWeaveKind=WIK_PENG;
				KindItem[cbKindItemCount++].cbCenterCard=SwitchToCardData(i);
			}

			//连牌判断
			if ((i<(MAX_INDEX-2))&&(cbCardIndex[i]>0)&&((i%9)<7) && i < 27)
			{
				for (BYTE j=1;j<=cbCardIndex[i];j++)
				{
					if ((cbCardIndex[i+1]>=j)&&(cbCardIndex[i+2]>=j))
					{
						KindItem[cbKindItemCount].cbCardIndex[0]=i;
						KindItem[cbKindItemCount].cbCardIndex[1]=i+1;
						KindItem[cbKindItemCount].cbCardIndex[2]=i+2;
						KindItem[cbKindItemCount].cbWeaveKind=WIK_LEFT;
						KindItem[cbKindItemCount++].cbCenterCard=SwitchToCardData(i);
					}
				}
			}
		}
	}

	//组合分析
	if (cbKindItemCount>=cbLessKindItem)
	{
		//变量定义
		BYTE cbCardIndexTemp[MAX_INDEX];
		ZeroMemory(cbCardIndexTemp,sizeof(cbCardIndexTemp));

		//变量定义
		BYTE cbIndex[4]={0,1,2,3};
		tagKindItem * pKindItem[4];
		ZeroMemory(&pKindItem,sizeof(pKindItem));

		//开始组合
		do
		{
			//设置变量
			CopyMemory(cbCardIndexTemp,cbCardIndex,sizeof(cbCardIndexTemp));
			for (BYTE i=0;i<cbLessKindItem;i++)
				pKindItem[i]=&KindItem[cbIndex[i]];

			//数量判断
			bool bEnoughCard=true;
			for (BYTE i=0;i<cbLessKindItem*3;i++)
			{
				//存在判断
				BYTE cbCardIndex=pKindItem[i/3]->cbCardIndex[i%3]; 
				if (cbCardIndexTemp[cbCardIndex]==0)
				{
					bEnoughCard=false;
					break;
				}
				else 
					cbCardIndexTemp[cbCardIndex]--;
			}

			//胡牌判断
			if (bEnoughCard==true)
			{
				//牌眼判断
				BYTE cbCardEye=0;
				for (BYTE i=0;i<MAX_INDEX;i++)
				{
					if (cbCardIndexTemp[i]==2)
					{
						cbCardEye=SwitchToCardData(i);
						break;
					}
				}

				//组合类型
				if (cbCardEye!=0)
				{
					//变量定义
					tagAnalyseItem AnalyseItem;
					ZeroMemory(&AnalyseItem,sizeof(AnalyseItem));

					//设置组合
					for (BYTE i=0;i<cbWeaveCount;i++)
					{
						AnalyseItem.cbWeaveKind[i]=WeaveItem[i].cbWeaveKind;
						AnalyseItem.cbCenterCard[i]=WeaveItem[i].cbCenterCard;
						AnalyseItem.bWeave[i]=true;
					}

					//设置牌型
					for (BYTE i=0;i<cbLessKindItem;i++) 
					{
						AnalyseItem.cbWeaveKind[i+cbWeaveCount]=pKindItem[i]->cbWeaveKind;
						AnalyseItem.cbCenterCard[i+cbWeaveCount]=pKindItem[i]->cbCenterCard;
					}

					//设置牌眼
					AnalyseItem.cbCardEye=cbCardEye;

					//插入结果
					AnalyseItemArray.Add(AnalyseItem);
				}
			}

			//设置索引
			if (cbIndex[cbLessKindItem-1]==(cbKindItemCount-1))
			{
				BYTE i=cbLessKindItem-1;
				for (i=cbLessKindItem-1;i>0;i--)
				{
					if ((cbIndex[i-1]+1)!=cbIndex[i])
					{
						BYTE cbNewIndex=cbIndex[i-1];
						for (BYTE j=(i-1);j<cbLessKindItem;j++) 
							cbIndex[j]=cbNewIndex+j-i+2;
						break;
					}
				}
				if (i==0)
					break;
			}
			else
				cbIndex[cbLessKindItem-1]++;

		} while (true);

	}

	return (AnalyseItemArray.GetCount()>0);
}

//变牌后分析扑克
bool CGameLogic::AnalyseChangOneCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbCardIndexTemp[MAX_INDEX],BYTE cbZhongPaiIndex)
{
	bool bchihu=false;
	cbCardIndex[cbZhongPaiIndex]--;
	for (int i=0;i<MAX_INDEX-1;i++)
	{
		if (i==0)
		{
			if(cbCardIndex[i]==0 && cbCardIndex[i+1]==0) continue;
		} 
		else if ((i%9)>=1 && (i%9)<8 )
		{
			if(cbCardIndex[i-1]==0 && cbCardIndex[i]==0 && cbCardIndex[i+1]==0) 
				continue;
		} 
		else
		{
			if(cbCardIndex[i]==0 && cbCardIndex[i-1]==0) continue;
		}
		cbCardIndex[i]++;
		if (cbCardIndex[i]>4)
		{
			cbCardIndex[i]--;
			continue;
		}
		AnalyseItemArray.RemoveAll();
		bool IsChiHu = AnalyseCard(cbCardIndex,WeaveItem,cbWeaveCount,AnalyseItemArray,cbCardIndexTemp);
		cbCardIndex[i]--;
		if (IsChiHu)
		{
			bchihu = true;
			break;
		}
	}
	cbCardIndex[cbZhongPaiIndex]++;
	return bchihu;
}
//变牌后分析扑克
bool CGameLogic::AnalyseChangTwoCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbCardIndexTemp[MAX_INDEX],BYTE cbZhongPaiIndex)
{
	bool bchihu=false;
	cbCardIndex[cbZhongPaiIndex]-=2;
	for (int i=0;i<MAX_INDEX-1;i++)
	{
		cbCardIndex[i]++;
		if (cbCardIndex[i]>4)
		{
			cbCardIndex[i]--;
			continue;
		}
		for (int j=0;j<MAX_INDEX-1;j++)
		{
			if (j==0)
			{
				if(cbCardIndex[j]==0 && cbCardIndex[j+1]==0) continue;
			} 
			else if ((j%9)>=1 && (j%9)<8 )
			{
				if(cbCardIndex[j-1]==0 && cbCardIndex[j]==0 && cbCardIndex[j+1]==0) 
					continue;
			} 
			else
			{
				if(cbCardIndex[j]==0 && cbCardIndex[j-1]==0) continue;
			}
			cbCardIndex[j]++;
			if (cbCardIndex[j]>4)
			{
				cbCardIndex[j]--;
				continue;
			}
			bool IsChiHu =  AnalyseCard(cbCardIndex,WeaveItem,cbWeaveCount,AnalyseItemArray,cbCardIndexTemp);
			cbCardIndex[j]--;
			if (IsChiHu) bchihu = true;
			if(bchihu) break;
		}
		cbCardIndex[i]--;
		if(bchihu) break;
	}
	cbCardIndex[cbZhongPaiIndex]+=2;
	return bchihu;
}
//变牌后分析扑克
bool CGameLogic::AnalyseChangThreeCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbCardIndexTemp[MAX_INDEX],BYTE cbZhongPaiIndex)
{
	bool bchihu = false;
	bchihu = AnalyseChangOneCard(cbCardIndex,WeaveItem,cbWeaveCount,AnalyseItemArray,cbCardIndexTemp,cbZhongPaiIndex);
	if (!bchihu)
	{
		cbCardIndex[cbZhongPaiIndex]-=3;
		for (int i=0;i<MAX_INDEX-1;i++)
		{
			cbCardIndex[i]++;
			if (cbCardIndex[i]>4)
			{
				cbCardIndex[i]--;
				continue;
			}
			for (int j=0;j<MAX_INDEX-1;j++)
			{
				cbCardIndex[j]++;
				if (cbCardIndex[j]>4)
				{
					cbCardIndex[j]--;
					continue;
				}
				for (int k=0;k<MAX_INDEX-1;k++)
				{
					if (k==0)
					{
						if(cbCardIndex[k]==0 && cbCardIndex[k+1]==0) continue;
					} 
					else if ((k%9)>=1 && (k%9)<8 )
					{
						if(cbCardIndex[k-1]==0 && cbCardIndex[k]==0 && cbCardIndex[k+1]==0) 
							continue;
					} 
					else
					{
						if(cbCardIndex[k]==0 && cbCardIndex[k-1]==0) continue;
					}
					cbCardIndex[k]++;
					if (cbCardIndex[k]>4)
					{
						cbCardIndex[k]--;
						continue;
					}
					bool IsChiHu = AnalyseCard(cbCardIndex,WeaveItem,cbWeaveCount,AnalyseItemArray,cbCardIndexTemp);
					cbCardIndex[k]--;
					if (IsChiHu) bchihu = true;
					if(bchihu) break;
				}	
				cbCardIndex[j]--;
				if(bchihu) break;
			}
			cbCardIndex[i]--;
			if(bchihu) break;
		}
		cbCardIndex[cbZhongPaiIndex]+=3;
	}
	return bchihu;
}
//变牌后分析扑克
bool CGameLogic::AnalyseChangFourCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbCardIndexTemp[MAX_INDEX],BYTE cbZhongPaiIndex)
{
	bool bchihu = false;
	bchihu = AnalyseChangTwoCard(cbCardIndex,WeaveItem,cbWeaveCount,AnalyseItemArray,cbCardIndexTemp,cbZhongPaiIndex);
	if (!bchihu)
	{
		bchihu = AnalyseChangThreeCard(cbCardIndex,WeaveItem,cbWeaveCount,AnalyseItemArray,cbCardIndexTemp,cbZhongPaiIndex);
	}
	return bchihu;
}
//变牌后分析扑克
bool CGameLogic::AnalyseChangOneCardAndChange(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbZhongPaiIndex)
{
	bool bchihu=false;
	//DWORD dwChiHuKind = analyseChangeOneCardSpecial(cbCardIndex,WeaveItem,cbWeaveCount,AnalyseItemArray);
	//if (dwChiHuKind != 0)
	//{
	//	return bchihu;
	//}
	BYTE cbCardIndexTemp[MAX_INDEX];
	CopyMemory(cbCardIndexTemp,cbCardIndex,sizeof(cbCardIndexTemp));
	cbCardIndex[cbZhongPaiIndex]--;
	for (int i=0;i<MAX_INDEX-1;i++)
	{
		if (i==0)
		{
			if(cbCardIndex[i]==0 && cbCardIndex[i+1]==0) continue;
		} 
		else if ((i%9)>=1 && (i%9)<8 )
		{
			if(cbCardIndex[i-1]==0 && cbCardIndex[i]==0 && cbCardIndex[i+1]==0) 
				continue;
		} 
		else
		{
			if(cbCardIndex[i]==0 && cbCardIndex[i-1]==0) continue;
		}
		cbCardIndex[i]++;
		if (cbCardIndex[i]>4)
		{
			cbCardIndex[i]--;
			continue;
		}
		AnalyseItemArray.RemoveAll();
		bool IsChiHu = AnalyseCard(cbCardIndex,WeaveItem,cbWeaveCount,AnalyseItemArray,cbCardIndexTemp);
		
		if (IsChiHu)
		{
			bchihu = true;
			break;
		}
		else
		{
			cbCardIndex[i]--;
		}
	}
	if (!bchihu)
	{
		cbCardIndex[cbZhongPaiIndex]++;
	}
	
	return bchihu;
}

// 处理变牌
DWORD CGameLogic::analyseChangeSpecial(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount,BYTE cbCardIndexTemp[MAX_INDEX],int fans[13])
{
	DWORD dwChiHuKind=CHK_NULL;
	CAnalyseItemArray AnalyseItemArray;
	//设置变量
	AnalyseItemArray.RemoveAll();
	bool IsChiHu = AnalyseCard(cbCardIndex,WeaveItem,cbWeaveCount,AnalyseItemArray,cbCardIndexTemp);
	if (!IsChiHu)
	{
		return dwChiHuKind;
	}
	
	// 七小对
	if (IsQiXiaoDui(cbCardIndex,WeaveItem,cbWeaveCount,cbCardIndexTemp))
	{
		fans[0]= 2;
		dwChiHuKind |= CHK_QIDUI;
	}
	// 豪华七小对
	if (IsHaoHuaQiXiaoDui(cbCardIndex,WeaveItem,cbWeaveCount,cbCardIndexTemp) || IsDHaoHuaQiXiaoDui(cbCardIndex,WeaveItem,cbWeaveCount,cbCardIndexTemp) || IsTHaoHuaQiXiaoDui(cbCardIndex,WeaveItem,cbWeaveCount,cbCardIndexTemp))
	{
		fans[1]= 4;
		dwChiHuKind |= CHK_HAOHUA_QIDUI;
	}
	// 十三幺
	if (IsShiSanYao(cbCardIndex,WeaveItem,cbWeaveCount))
	{
		fans[4]= 4;
		dwChiHuKind |= CHK_TENTHREEYAO;
	}

	if (IsQingYiSe(cbCardIndex,WeaveItem,cbWeaveCount))
	{
		fans[5]= 2;
		dwChiHuKind |= CHK_QINGYISE;
	}

	if (IsLuoDiHu(cbCardIndex,WeaveItem,cbWeaveCount,cbCardIndexTemp))
	{
		fans[6]= 4;
		dwChiHuKind |= CHK_TWELVE_LUO_DI;
	}
	//// 混一色牌
	//if (IsHunYiSe(cbCardIndex,WeaveItem,cbWeaveCount,cbCardIndexTemp))
	//{
	//	fans[6]= 2;
	//	dwChiHuKind |= CHK_HUNYISE;
	//}
	//// 字一色牌
	//if (IsZiYiSe(cbCardIndex,WeaveItem,cbWeaveCount))
	//{
	//	fans[7]= 13;
	//	dwChiHuKind |= CHK_ZIYISE;
	//}
	// 碰碰胡
	if (IsPenPenHu(cbCardIndex,WeaveItem,cbWeaveCount,cbCardIndexTemp))
	{
		fans[8]= 2;
		dwChiHuKind |= CHK_PENPEN_HU;
	}
	//// 坎坎胡
	//if (IsKanKanHu(cbCardIndex,WeaveItem,cbWeaveCount))
	//{
	//	fans[9]= 10;
	//	dwChiHuKind |= CHK_KANKANHU;
	//}

	//// 纯幺九
	//if (IsChunSanJiu(cbCardIndex,WeaveItem,cbWeaveCount))
	//{
	//	fans[10]= 13;
	//	dwChiHuKind |= CHK_QINGYAOJIU_HU;
	//}
	//// 混幺九
	//if (IsHunSanJiu(cbCardIndex,WeaveItem,cbWeaveCount))
	//{
	//	fans[11]= 9;
	//	dwChiHuKind |= CHK_HUNYAOJIAO;
	//}
	//// 十八罗汉
	//if (IsTenEightLuoHan(cbCardIndex,WeaveItem,cbWeaveCount))
	//{
	//	fans[12]= 18;
	//	dwChiHuKind |= CHK_LUOHAN;
	//}

	if (dwChiHuKind == CHK_NULL)
	{
		dwChiHuKind |= CHK_PING_HU;
	}

	return dwChiHuKind;
}

// 处理获取最大的类型
DWORD CGameLogic::getMaxValueChiHuType(int fans[13])
{
	// 获取最大的数据下标
	int maxIndex = -1;
	int tempMaxValue = 0;
	DWORD dwChiHuKind = CHK_NULL;
	for (int i = 0; i < 13; i++)
	{
		if (fans[i] > 0 && fans[i] >= tempMaxValue)
		{
			tempMaxValue = fans[i];
			maxIndex = i;
		}
	}
	switch (maxIndex)
	{
		case 0:
		dwChiHuKind = CHK_QIDUI;
		break;
		case 1:
		dwChiHuKind = CHK_HAOHUA_QIDUI;
		break;
		case 2:
		dwChiHuKind = CHK_DHAOHUA_QIDUI;
		break;
		case 3:
		dwChiHuKind = CHK_THAOHUA_QIDUI;
		break;
		case 4:
		dwChiHuKind = CHK_TENTHREEYAO;
		break;
		case 5:
		dwChiHuKind = CHK_QINGYISE;
		break;
		case 6:
		dwChiHuKind = CHK_HUNYISE;
		break;
		case 7:
		dwChiHuKind = CHK_ZIYISE;
		break;
		case 8:
		dwChiHuKind = CHK_PENPEN_HU;
		break;
		case 9:
		dwChiHuKind = CHK_KANKANHU;
		break;
		case 10:
		dwChiHuKind = CHK_QINGYAOJIU_HU;
		break;
		case 11:
		dwChiHuKind = CHK_HUNYAOJIAO;
		break;
		case 12:
		//dwChiHuKind = CHK_LUOHAN;
		break;
	default:
		break;
	}

	if (dwChiHuKind == CHK_NULL && maxIndex == -1)
	{
		dwChiHuKind = CHK_PING_HU;
	}

	return dwChiHuKind;
}

int CGameLogic::getAllFansValue(int *fans)
{
	int ret = 0;
	for (int i = 0;i < 13;++i)
	{
		ret += fans[i];
	}

	return ret;
}

// 变牌后分析扑克七小对，十三幺
DWORD CGameLogic::analyseChangeOneCardSpecial(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,bool isChaTing,BYTE cbZhongPaiIndex)
{
	DWORD dwChiHuKind=CHK_NULL;
	BYTE cbCardIndexTemp[MAX_INDEX];
	CopyMemory(cbCardIndexTemp,cbCardIndex,sizeof(cbCardIndexTemp));
	
	cbCardIndex[cbZhongPaiIndex]--;
	int fans[13]={0};
	int maxFans = 0;
	for (int i=0;i<MAX_INDEX;i++)
	{
		cbCardIndex[i]++;
		ZeroMemory(fans,sizeof(fans));
		DWORD tempChiHuKind = analyseChangeSpecial(cbCardIndex,WeaveItem,cbWeaveCount,cbCardIndexTemp,fans);
		int tempFans = getAllFansValue(fans);
		if (tempChiHuKind != CHK_NULL && tempFans >= maxFans)
		{
			maxFans = tempFans;
			dwChiHuKind = tempChiHuKind;
		}
		
		cbCardIndex[i]--;
	}

	if (isChaTing)
	{
		cbCardIndex[cbZhongPaiIndex]+=1;
		return dwChiHuKind;
	}
	if (dwChiHuKind == CHK_NULL)
	{
		cbCardIndex[cbZhongPaiIndex]+=1;
		return CHK_NULL;
	}
	// 获取最大的那个类型
	//dwChiHuKind = getMaxValueChiHuType(fans);

	for (int i=0;i<MAX_INDEX;i++)
	{
		cbCardIndex[i]++;
		DWORD tempKind = analyseChangeSpecial(cbCardIndex,WeaveItem,cbWeaveCount,cbCardIndexTemp,fans);
		if (tempKind == dwChiHuKind)
		{
			return dwChiHuKind;
		}
		cbCardIndex[i]--;
	}
	cbCardIndex[cbZhongPaiIndex]++;
	return dwChiHuKind;
}

//变牌后分析扑克
bool CGameLogic::AnalyseChangTwoCardAndChange(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbZhongPaiIndex)
{
	return false;
}

// 变牌后分析扑克七小对，十三幺
DWORD CGameLogic::analyseChangeTwoCardSpecial(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,bool isChaTing,BYTE cbZhongPaiIndex)
{
	DWORD dwChiHuKind=0;
	BYTE cbCardIndexTemp[MAX_INDEX];
	CopyMemory(cbCardIndexTemp,cbCardIndex,sizeof(cbCardIndexTemp));
	cbCardIndex[cbZhongPaiIndex]-=2;
	int fans[13]={0};
	int maxFans = 0;
	for (int i=0;i<MAX_INDEX;i++)
	{
		cbCardIndex[i]++;
		if (cbCardIndex[i]>4)
		{
			cbCardIndex[i]--;
			continue;
		}
		for (int j=0;j<MAX_INDEX;j++)
		{
			cbCardIndex[j]++;
			if (cbCardIndex[j]>4)
			{
				cbCardIndex[j]--;
				continue;
			}
			ZeroMemory(fans,sizeof(fans));
			DWORD tempChiHuKind = analyseChangeSpecial(cbCardIndex,WeaveItem,cbWeaveCount,cbCardIndexTemp,fans);
			int tempFans = getAllFansValue(fans);
			if (tempChiHuKind != CHK_NULL && tempFans >= maxFans)
			{
				dwChiHuKind = tempChiHuKind;
				maxFans = tempFans;
			}
	
			cbCardIndex[j]--;
		}
		cbCardIndex[i]--;
	}
	if (isChaTing)
	{
		cbCardIndex[cbZhongPaiIndex]+=2;
		return dwChiHuKind;
	}
	if (dwChiHuKind == CHK_NULL)
	{
		cbCardIndex[cbZhongPaiIndex]+=2;
		return CHK_NULL;
	}
	// 获取最大的那个类型
	//dwChiHuKind = getMaxValueChiHuType(fans);
	for (int i=0;i<MAX_INDEX;i++)
	{
		cbCardIndex[i]++;
		if (cbCardIndex[i]>4)
		{
			cbCardIndex[i]--;
			continue;
		}
		for (int j=0;j<MAX_INDEX;j++)
		{
			cbCardIndex[j]++;
			if (cbCardIndex[j]>4)
			{
				cbCardIndex[j]--;
				continue;
			}
			
			DWORD tempKind = analyseChangeSpecial(cbCardIndex,WeaveItem,cbWeaveCount,cbCardIndexTemp,fans);
			if (tempKind  == dwChiHuKind)
			{
				return dwChiHuKind;
			}
			cbCardIndex[j]--;
		}
		cbCardIndex[i]--;
	}


	cbCardIndex[cbZhongPaiIndex]+=2;
	
	return dwChiHuKind;
}

//变牌后分析扑克
bool CGameLogic::AnalyseChangThreeCardAndChange(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbZhongPaiIndex)
{
	bool bchihu = false;
	BYTE cbCardIndexTemp[MAX_INDEX];
	CopyMemory(cbCardIndexTemp,cbCardIndex,sizeof(cbCardIndexTemp));
	bchihu = AnalyseChangOneCard(cbCardIndex,WeaveItem,cbWeaveCount,AnalyseItemArray,cbCardIndexTemp,cbZhongPaiIndex);
	if (!bchihu)
	{
		cbCardIndex[cbZhongPaiIndex]-=3;
		for (int i=0;i<MAX_INDEX-1;i++)
		{
			cbCardIndex[i]++;
			if (cbCardIndex[i]>4)
			{
				cbCardIndex[i]--;
				continue;
			}
			for (int j=0;j<MAX_INDEX-1;j++)
			{
				cbCardIndex[j]++;
				if (cbCardIndex[j]>4)
				{
					cbCardIndex[j]--;
					continue;
				}
				for (int k=0;k<MAX_INDEX-1;k++)
				{
					if (k==0)
					{
						if(cbCardIndex[k]==0 && cbCardIndex[k+1]==0) continue;
					} 
					else if ((k%9)>=1 && (k%9)<8 )
					{
						if(cbCardIndex[k-1]==0 && cbCardIndex[k]==0 && cbCardIndex[k+1]==0) 
							continue;
					} 
					else
					{
						if(cbCardIndex[k]==0 && cbCardIndex[k-1]==0) continue;
					}
					cbCardIndex[k]++;
					if (cbCardIndex[k]>4)
					{
						cbCardIndex[k]--;
						continue;
					}
					bool IsChiHu = AnalyseCard(cbCardIndex,WeaveItem,cbWeaveCount,AnalyseItemArray,cbCardIndexTemp);
					
					if (IsChiHu) 
						bchihu = true;
					else
						cbCardIndex[k]--;
					if(bchihu) break;
				}	
				
				if(bchihu) 
					break;
				else
					cbCardIndex[j]--;
			}
			
			if(bchihu) 
				break;
			else
				cbCardIndex[i]--;
		}
		if (!bchihu)
		{
			cbCardIndex[cbZhongPaiIndex]+=3;
		}
		
	}
	return bchihu;
}

// 变牌后分析扑克七小对，十三幺
DWORD CGameLogic::analyseChangeThreeCardSpecial(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,bool isChaTing,BYTE cbZhongPaiIndex)
{
	DWORD dwChiHuKind=0;
	BYTE cbCardIndexTemp[MAX_INDEX];
	CopyMemory(cbCardIndexTemp,cbCardIndex,sizeof(cbCardIndexTemp));
	cbCardIndex[cbZhongPaiIndex]-=3;
	int fans[13]={0};
	int maxFans = 0;
	for (int i=0;i<MAX_INDEX;i++)
	{
		cbCardIndex[i]++;
		if (cbCardIndex[i]>4)
		{
			cbCardIndex[i]--;
			continue;
		}
		for (int j=0;j<MAX_INDEX;j++)
		{
			cbCardIndex[j]++;
			for (int  k= 0; k < MAX_INDEX; ++k)
			{
				cbCardIndex[k]++;
				if (cbCardIndex[k]>4)
				{
					cbCardIndex[k]--;
					continue;
				}
				ZeroMemory(fans,sizeof(fans));
				DWORD tempChiHuKind = analyseChangeSpecial(cbCardIndex,WeaveItem,cbWeaveCount,cbCardIndexTemp,fans);
				int tempFans = getAllFansValue(fans);
				if (tempChiHuKind != CHK_NULL  && tempFans >= maxFans)
				{
					dwChiHuKind = tempChiHuKind;
					maxFans = tempFans;
				}
				cbCardIndex[k]--;
			}
	
			cbCardIndex[j]--;
		}
		cbCardIndex[i]--;
	}

	if (isChaTing)
	{
		cbCardIndex[cbZhongPaiIndex]+=3;
		return dwChiHuKind;
	}
	if (dwChiHuKind == CHK_NULL)
	{
		cbCardIndex[cbZhongPaiIndex]+=3;
		return CHK_NULL;
	}
		// 获取最大的那个类型
	//dwChiHuKind = getMaxValueChiHuType(fans);
	for (int i=0;i<MAX_INDEX;i++)
	{
		cbCardIndex[i]++;
		if (cbCardIndex[i]>4)
		{
			cbCardIndex[i]--;
			continue;
		}
		for (int j=0;j<MAX_INDEX;j++)
		{
			cbCardIndex[j]++;
			for (int  k= 0; k < MAX_INDEX; ++k)
			{
				cbCardIndex[k]++;
				if (cbCardIndex[k]>4)
				{
					cbCardIndex[k]--;
					continue;
				}
				DWORD tempKind = analyseChangeSpecial(cbCardIndex,WeaveItem,cbWeaveCount,cbCardIndexTemp,fans);
				if (tempKind == dwChiHuKind)
				{
					return dwChiHuKind;
				}
				cbCardIndex[k]--;
			}
	
			cbCardIndex[j]--;
		}
		cbCardIndex[i]--;
	}

	cbCardIndex[cbZhongPaiIndex]+=3;
	
	return dwChiHuKind;
}

//变牌后分析扑克
bool CGameLogic::AnalyseChangFourCardAndChange(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbZhongPaiIndex)
{
	bool bchihu = false;
	bchihu = AnalyseChangTwoCardAndChange(cbCardIndex,WeaveItem,cbWeaveCount,AnalyseItemArray,cbZhongPaiIndex);
	if (!bchihu)
	{
		bchihu = AnalyseChangThreeCardAndChange(cbCardIndex,WeaveItem,cbWeaveCount,AnalyseItemArray,cbZhongPaiIndex);
	}
	return bchihu;
}

// 变牌后分析扑克七小对，十三幺
DWORD CGameLogic::analyseChangeFourCardSpecial(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,bool isChaTing,BYTE cbZhongPaiIndex)
{
	bool bchihu = false;
	bchihu = analyseChangeTwoCardSpecial(cbCardIndex,WeaveItem,cbWeaveCount,AnalyseItemArray,isChaTing,cbZhongPaiIndex);
	if (!bchihu)
	{
		bchihu = analyseChangeThreeCardSpecial(cbCardIndex,WeaveItem,cbWeaveCount,AnalyseItemArray,isChaTing,cbZhongPaiIndex);
	}
	return bchihu;
}

//获取能听牌的牌数及对应的番数 
bool CGameLogic::AnalyseChaTingCard(BYTE cbCardIndex[MAX_INDEX],tagChaTingItem &cbChaTingCardArray,tagWeaveItem WeaveItem[], BYTE cbItemCount, DWORD dwChiHuRight,BYTE m_cbQueMen,bool IsSendCard,tagChiHuData &chiHuTmp)
{
	//变量定义
	tagChiHuResult ChiHuResult;
	ZeroMemory(&ChiHuResult,sizeof(ChiHuResult));
	bool m_cbChaTing = false;
	//构造扑克
	BYTE cbCardIndexTemp[MAX_INDEX];
	DWORD dwWinMax=0;
	CopyMemory(cbCardIndexTemp,cbCardIndex,sizeof(cbCardIndexTemp));

	//听牌分析
	if (IsSendCard)//发牌时
	{
		for (BYTE i=0;i<MAX_INDEX;i++)
		{		
			//空牌过滤
			if (cbCardIndexTemp[i]==0) continue;
			bool IsCanHupai=false;
			//听牌处理
			cbCardIndexTemp[i]--;
			//听牌判断
			for (BYTE j=0;j<MAX_INDEX;j++)
			{
				//胡牌分析
				BYTE cbCurrentCard=SwitchToCardData(j);
				WORD cbHuCardKind=AnalyseChiHuCard(cbCardIndexTemp,WeaveItem,cbItemCount,cbCurrentCard,dwChiHuRight,ChiHuResult, m_cbQueMen,chiHuTmp,true,true);
				if (cbHuCardKind!=CHK_NULL)
				{
					IsCanHupai = true;
					m_cbChaTing = true;
					cbChaTingCardArray.cbDisCardData[cbChaTingCardArray.cbDisCount] = SwitchToCardData(i);
					cbChaTingCardArray.cbCardData[cbChaTingCardArray.cbDisCount][cbChaTingCardArray.cbHuCount[cbChaTingCardArray.cbDisCount]]=cbCurrentCard;				
					cbChaTingCardArray.cbHupaiFansu[cbChaTingCardArray.cbDisCount][cbChaTingCardArray.cbHuCount[cbChaTingCardArray.cbDisCount]] = ChiHuResult.dwWinTimes;
					cbChaTingCardArray.cbHupaiLessCount[cbChaTingCardArray.cbDisCount][cbChaTingCardArray.cbHuCount[cbChaTingCardArray.cbDisCount]]=4;
					cbChaTingCardArray.cbHuCount[cbChaTingCardArray.cbDisCount]++;	
				}			
			}
			if (IsCanHupai)
			{
				cbChaTingCardArray.cbDisCount++;
			}		
			if (IsSendCard)//发牌时
			{
				cbCardIndexTemp[i]++;
			}
		}
	}
	else
	{
		bool IsCanHupai=false;
		//听牌判断
		for (BYTE j=0;j<MAX_INDEX;j++)
		{
			//胡牌分析
			BYTE cbCurrentCard=SwitchToCardData(j);
			WORD cbHuCardKind=AnalyseChiHuCard(cbCardIndexTemp,WeaveItem,cbItemCount,cbCurrentCard,dwChiHuRight,ChiHuResult, m_cbQueMen,chiHuTmp,true,true);
			if (cbHuCardKind!=CHK_NULL)
			{
				IsCanHupai = true;
				m_cbChaTing = true;
				//cbChaTingCardArray.cbDisCardData[cbChaTingCardArray.cbDisCount] = 0;
				cbChaTingCardArray.cbCardData[cbChaTingCardArray.cbDisCount][cbChaTingCardArray.cbHuCount[cbChaTingCardArray.cbDisCount]]=cbCurrentCard;				
				cbChaTingCardArray.cbHupaiFansu[cbChaTingCardArray.cbDisCount][cbChaTingCardArray.cbHuCount[cbChaTingCardArray.cbDisCount]] = ChiHuResult.dwWinTimes;
				cbChaTingCardArray.cbHupaiLessCount[cbChaTingCardArray.cbDisCount][cbChaTingCardArray.cbHuCount[cbChaTingCardArray.cbDisCount]]=4;
				cbChaTingCardArray.cbHuCount[cbChaTingCardArray.cbDisCount]++;	
			}			
		}
		if (IsCanHupai)
		{
			cbChaTingCardArray.cbDisCount++;
		}
	}
	return m_cbChaTing;
}

//获取任务牌型
WORD CGameLogic::GetTaskType(BYTE cbCardType,BYTE cbCardData)
{
	return 0;
}

CString CGameLogic::GetCardName(BYTE nCard)
{
	CString str;

	switch (nCard)
	{
	case 0x01: str = "一万"; break;
	case 0x02: str = "二万"; break;
	case 0x03: str = "三万"; break;
	case 0x04: str = "四万"; break;
	case 0x05: str = "五万"; break;
	case 0x06: str = "六万"; break;
	case 0x07: str = "七万"; break;
	case 0x08: str = "八万"; break;
	case 0x09: str = "九万"; break;
	case 0x11: str = "一索"; break;
	case 0x12: str = "二索"; break;
	case 0x13: str = "三索"; break;
	case 0x14: str = "四索"; break;
	case 0x15: str = "五索"; break;
	case 0x16: str = "六索"; break;
	case 0x17: str = "七索"; break;
	case 0x18: str = "八索"; break;
	case 0x19: str = "九索"; break;
	case 0x21: str = "一同"; break;
	case 0x22: str = "二同"; break;
	case 0x23: str = "三同"; break;
	case 0x24: str = "四同"; break;
	case 0x25: str = "五同"; break;
	case 0x26: str = "六同"; break;
	case 0x27: str = "七同"; break;
	case 0x28: str = "八同"; break;
	case 0x29: str = "九同"; break;
	case 0x31: str = "东风"; break;
	case 0x32: str = "南风"; break;
	case 0x33: str = "西风"; break;
	case 0x34: str = "北风"; break;
	case 0x35: str = "红中"; break;
	case 0x36: str = "发财"; break;
	case 0x37: str = "白板"; break;
	}

	return str;
}

CString CGameLogic::GetActionName(WORD cbActionMask)
{
	CString str;
	if (cbActionMask == WIK_NULL)
	{
		str = "无操作";
	}
	else
	{
		if (cbActionMask & WIK_CHI_HU)
		{
			str += "|胡牌|";
		}
		if (cbActionMask & WIK_LEFT)
		{
			str += "|左吃|";
		}
		if (cbActionMask & WIK_CENTER)
		{
			str += "|中吃|";
		}
		if (cbActionMask & WIK_RIGHT)
		{
			str += "|右吃|";
		}
		if (cbActionMask & WIK_PENG)
		{
			str += "|碰|";
		}
		if (cbActionMask & WIK_GANG)
		{
			str += "|杠|";
		}
		/*if (cbActionMask & WIK_SPE_YAOGANG)
		{
			str += "|幺杠|";
		}
		if (cbActionMask & WIK_SPE_JIUGANG)
		{
			str += "|九杠|";
		}*/
		if (cbActionMask & WIK_LISTEN)
		{
			str += "|听牌|";
		}
		/*if (cbActionMask & WIK_SHOU_GANG)
		{
			str += "|首杠|";
		}
		if (cbActionMask & WIK_BAO_HU)
		{
			str += "|宝胡|";
		}
		if (cbActionMask & WIK_DUI_BAO)
		{
			str += "|对宝|";
		}*/
		if (cbActionMask & WIK_QIANG_GANG)
		{
			str += "|抢杠|";
		}
		//if (cbActionMask & WIK_SPE_YAOGANG)			//	0x0080								//特殊杠类型
		//{
		//	str += "|幺杠|";
		//}
		//if (cbActionMask & WIK_SPE_JIUGANG)			//					0x0100								//特殊杠类型
		//{
		//	str += "|九杠|";
		//}
		//if (cbActionMask & WIK_SPE_FENGGANG)			//				0x0200								//特殊杠类型
		//{
		//	str += "|风杠|";
		//}
		//if (cbActionMask & WIK_SPE_BAIGANG)			//					0x0400								//特殊杠类型
		//{
		//	str += "|喜杠|";
		//}
	}

	return str;
}

CString CGameLogic::GetHuPaiRightName(DWORD dwChiHuRight)
{
	CString str;
	if (dwChiHuRight == CHK_NULL)
	{
		return "";
	}

	/*if (dwChiHuRight & CHK_BIAN_HU)
	{
		str += "|边胡|";
	}
	if (dwChiHuRight & CHK_LI_HU)
	{
		str += "|立胡|";
	}*/
	if (dwChiHuRight & CHK_ZI_MO)
	{
		str += "|自摸|";
	}
	/*if (dwChiHuRight & CHK_JIA_HU)
	{
		str += "|夹胡|";
	}
	if (dwChiHuRight & CHK_PIAO_HU)
	{
		str += "|票胡|";
	}
	if (dwChiHuRight & CHK_ZHUANG_HU)
	{
		str += "|庄胡|";
	}*/
	if (dwChiHuRight & CHK_FANG_PAO)
	{
		str += "|放炮|";
	}
	/*if (dwChiHuRight & CHK_BAO_HU)
	{
		str += "|宝胡|";
	}
	if (dwChiHuRight & CHK_DUI_BAO)
	{
		str += "|对宝|";
	}*/
	if (dwChiHuRight & CHK_GANG_KAI)
	{
		str += "|杠开|";
	}
	/*if (dwChiHuRight & CHK_BAO_TING)
	{
		str += "|报听|";
	}
	if (dwChiHuRight & CHK_SAN_SE)
	{
		str += "|三色全|";
	}
	if (dwChiHuRight & CHK_DAN_DIAO)
	{
		str += "|单吊|";
	}
	if (dwChiHuRight & CHK_QIN_YI_SE)
	{
		str += "|清一色|";
	}
	if (dwChiHuRight & CHK_XIAO_QI)
	{
		str += "|小七对|";
	}
	if (dwChiHuRight & CHK_DA_SAN_YUAN)
	{
		str += "|大三元|";
	}
	if (dwChiHuRight & CHK_XIAO_SAN_YUAN)
	{
		str += "|小三元|";
	}
	if (dwChiHuRight & CHK_HUN_YI_SE)
	{
		str += "|混一色|";
	}*/

	return str;
}
//////////////////////////////////////////////////////////////////////////
BYTE CGameLogic::GetIsolatedCard(BYTE cbCardIndex[MAX_INDEX], BYTE byOutCard[5])
{
	BYTE byResult = 0xFF;
	BYTE byTmpCard[MAX_INDEX] = {0};
	BYTE byTmpOutCard[5] = { 0, 0, 0, 0, 0 };
	CopyMemory(byTmpCard, cbCardIndex, sizeof(byTmpCard));
	int nCardCnt = GetCardCount(byTmpCard);	//	牌数
	int i = 0;

	//////////////////////////////////////////////////////////////////////////	直接找孤牌
	/*for (i = 31; i < 34; i ++)
	{
		if (byTmpCard[i] != 1) continue;
		if (i == 31) if ((byTmpCard[32] > 0) || (byTmpCard[33] > 0)) continue;
		if (i == 32) if ((byTmpCard[31] > 0) || (byTmpCard[33] > 0)) continue;
		if (i == 33) if ((byTmpCard[31] > 0) || (byTmpCard[32] > 0)) continue;
		byResult = SwitchToCardData(i); break;
	}*/
	if (byResult == 0xFF)
	{
		for (i = 0; i < 27; i ++)
		{
			if (byTmpCard[i] != 1) continue;
			BYTE byRow = i % 9;
			if (i < 27)
			{
				if (byRow < 7) if (byTmpCard[i+2] > 0) continue;
				if (byRow < 8) if (byTmpCard[i+1] > 0) continue;
				if (byRow > 0) if (byTmpCard[i-1] > 0) continue;
				if (byRow > 1) if (byTmpCard[i-2] > 0) continue;
				byResult = SwitchToCardData(i); break;
			}
		}
	}
	//if (byResult != 0xFF) return byResult;

	int nCnt = 0;
	int nDuiShu = 0;
	if (nCardCnt > 11)		//	是否制造小七对
	{
		for (i = 0; i < MAX_INDEX; i ++)
		{
			if (byTmpCard[i] > 1) nDuiShu ++;
		}
		if (nDuiShu > 4) 
		{
			nCnt = 0;
			for (i = 0; i < MAX_INDEX; i ++)
			{
				if ((byTmpCard[i] == 1) || (byTmpCard[i] == 3))	byTmpOutCard[nCnt ++] = SwitchToCardData(i);
				if (nCnt == 5) break;
			}
		}
	}

	if (nDuiShu < 5)	//	不够五对 
	{	//	找出已有组合
		for (i = 0; i < MAX_INDEX; i ++)	//	三元
		{
			if (byTmpCard[i] == 3)
			{
				nCardCnt -= byTmpCard[i];	//	牌数
				byTmpCard[i] = 0;
			}
		}
		for (i = 0; i < 3; i ++)	//	万索同 顺子
		{
			for (int j = 0; j < 7; j ++)
			{
				BYTE by = i * 9 + j;
				if ((byTmpCard[by] > 0) && (byTmpCard[by+1] > 0) && (byTmpCard[by+2] > 0))
				{ 
					if ((j < 6) && (byTmpCard[by+3] > 0))
					{
						if (byTmpCard[by] > 1)
							by ++;
					}

					byTmpCard[by] --; byTmpCard[by+1] --; byTmpCard[by+2] --; 
					nCardCnt -= 3; 
					j -- ;
				}
			}
		}
		if (nCardCnt > 2)
		{
			for (i = 0; i < MAX_INDEX; i ++)	//	三元
			{
				if (byTmpCard[i] == 2)
				{
					byTmpCard[i] = 0;
					nCardCnt -= 2;	//	牌数
				}
			}
			for (i = 0; i < 3; i ++)	//	万索同
			{
				for (int j = 0; j < 8; j ++)
				{
					BYTE by = i * 9 + j;
					if ((byTmpCard[by] > 0) && (byTmpCard[by+1] > 0))
					{ 
						byTmpCard[by] --; byTmpCard[by+1] --;
						nCardCnt -= 2; 
					}
					if (j != 7)
					{
						if ((byTmpCard[by] > 0) && (byTmpCard[by+2] > 0))
						{ 
							byTmpCard[by] --; byTmpCard[by+2] --;
							nCardCnt -= 2; 
						}
					}
				}
			}
		}
		if (nCardCnt)
		{
			nCnt = 0;
			for (i = 0; i < MAX_INDEX; i ++)	//	
			{
				if (byTmpCard[i] > 0) byTmpOutCard[nCnt ++] = SwitchToCardData(i);
				if (nCnt == 5) break;
			}
		}
	}
	if (byOutCard != NULL)
	{
		CopyMemory(byOutCard, byTmpOutCard, sizeof(byTmpOutCard));
	}

	if (byResult != 0xFF) return byResult;

	if (nCnt) byResult = (nCnt > 1) ?  byTmpOutCard[rand() % nCnt] : byTmpOutCard[0];
	for (i = 0; i < nCnt; i ++)
	{
		BYTE byIndex = SwitchToCardIndex(byTmpOutCard[i]);
		//	是否孤牌
		if (cbCardIndex[byIndex] > 1) continue;
		//if (byTmpOutCard[i] > 0x30)		//	番子
		//{
		//	byResult = byTmpOutCard[i];
		//	break;
		//}
		BYTE byRow = byIndex % 9;
		if (byRow < 8) if (cbCardIndex[byIndex+1] > 0) continue;
		if (byRow < 7) if (cbCardIndex[byIndex+2] > 0) continue;
		if (byRow > 0) if (cbCardIndex[byIndex-1] > 0) continue;
		if (byRow > 1) if (cbCardIndex[byIndex-2] > 0) continue;
		byResult = byTmpOutCard[i];
		break;
	}
	return byResult;
}

BYTE CGameLogic::getZhongPaiIndex(BYTE currentZhongPaiCardData,bool isZhongPai)
{
	if (isZhongPai)
	{
		return SwitchToCardIndex(currentZhongPaiCardData);
	}
	return INVALID_BYTE;
}