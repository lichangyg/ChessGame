﻿#ifndef GAME_LOGIC_HEAD_FILE
#define GAME_LOGIC_HEAD_FILE

#pragma once

#include "Stdafx.h"

//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
//逻辑掩码

#define	MASK_COLOR					0xF0								//花色掩码
#define	MASK_VALUE					0x0F								//数值掩码

//////////////////////////////////////////////////////////////////////////
//动作定义

//动作标志
#define WIK_NULL					0x0000								//没有类型
#define WIK_LEFT					0x0001								//左吃类型
#define WIK_CENTER					0x0002								//中吃类型
#define WIK_RIGHT					0x0004								//右吃类型
#define WIK_PENG					0x0008								//碰牌类型
#define WIK_GANG					0x0010								//杠牌类型
#define WIK_LISTEN					0x0020								//听牌类型
#define WIK_CHI_HU					0x0040								//吃胡类型
//#define WIK_SPE_YAOGANG				0x0080								//特殊杠类型
//#define WIK_SPE_JIUGANG				0x0100								//特殊杠类型
//#define WIK_SPE_FENGGANG			0x0200								//特殊杠类型
//#define WIK_SPE_BAIGANG				0x0400								//特殊杠类型
//#define WIK_DUIBAO_HU				0x0800								//对宝类型
//#define WIK_SHOU_GANG				0x1000								//首杠类型
//#define WIK_BAO_HU					0x2000								//宝牌
//#define WIK_DUI_BAO					0x4000								//对宝
#define WIK_QIANG_GANG					0x8000								//抢杠
//////////////////////////////////////////////////////////////////////////
//胡牌定义

//牌型掩码
#define CHK_MASK_SMALL				0x0000FFFF							//小胡掩码
#define CHK_MASK_GREAT				0xFFFF0000							//大胡掩码

//小胡牌型
#define CHK_NULL					0x00000000							//非胡类型
#define CHK_JI_HU					0x00000001							//鸡胡类型
#define CHK_PING_HU					0x00000002							//平胡类型
//大胡权位
#define CHK_QIDUI					0x00000004							//七对类型
#define CHK_HAOHUA_QIDUI			0x00000008							//豪华七小对
#define CHK_DHAOHUA_QIDUI			0x00000010							//双豪华七小对
#define CHK_THAOHUA_QIDUI			0x00000020							//三豪华七小对

#define CHK_WEI_HU					0x00000040							//未胡
#define CHK_HU_PAI					0x00000080							//胡牌
#define CHK_ZI_MO					0x00000100							//自摸
#define CHK_WEI_TING				0x00000200							//未听

#define CHK_PENPEN_HU				0x00000400							//碰碰胡
#define CHK_QINGYISE				0x00000800							//清一色
#define CHK_FANG_PAO				0x00001000							//放炮
#define CHK_HUNYISE					0x00002000							//混一色
#define CHK_ZIYISE					0x00004000							//字一色
#define CHK_KANKANHU				0x00008000							//坎坎胡
#define CHK_GANG_KAI				0x00010000							//杠开(杠上花)

#define CHK_QINGYAOJIU_HU			0x00020000							//纯幺九
#define CHK_TIAN_HU					0x00040000							//天胡
#define CHK_DI_HU					0x00080000							//地胡

#define CHK_TENTHREEYAO				0x00100000							//十三幺
#define CHK_HUNYAOJIAO				0x00200000							//混幺九

#define CHK_GANG_PAO				0x00400000							//杠上炮
#define CHK_GANG_HU					0x00800000							//枪杠胡

#define CHK_HUNYAOJIU_HU			0x01000000							//混幺九
#define CHK_HAIDI_LAO				0x02000000							//海底捞
#define CHK_HAIDI_PAO				0x04000000							//海底炮
#define CHK_FOLLOW					0x08000000							//被跟庄
#define CHK_TWELVE_LUO_DI				0x10000000							//龙七对

//test
//#define DEF_TEST					true
#ifdef _DEBUG
#define DEF_TEST					true
#else
#define DEF_TEST					false
#endif


#define CHK_WANG_FA_JI_HU			1		// 鸡胡玩法定义
#define CHK_JI_HU_ZI_MO				3		// 鸡胡能自摸定义

#define GANG_MING					1		// 明杠的定义
#define GANG_AN 					0		// 暗杠的定义
//end
//////////////////////////////////////////////////////////////////////////

//类型子项
struct tagKindItem
{
	WORD							cbWeaveKind;						//组合类型
	BYTE							cbCenterCard;						//中心扑克
	BYTE							cbCardIndex[3];						//扑克索引
};

//组合子项
struct tagWeaveItem
{
	WORD							cbWeaveKind;						//组合类型
	BYTE							cbCenterCard;						//中心扑克
	bool							cbPublicCard;						//公开标志
	WORD							wProvideUser;						//供应用户
	BYTE							cbCardIndex[4];						//扑克索引
	WORD							cbGangType;							//杠牌类型(0:暗杠,1:公杠,2:吃杠)
};
//前三个玩家出的牌
struct tagOutCardItem
{	
	WORD							wProvideUser[3];					//供应用户
	BYTE							cbCardIndex[3];						//扑克索引
	bool							cbIsCanChihu[4][4];					//扑克索引
	BYTE							cbIsCanChihuFansu[4][4];			//扑克索引
};
//胡牌结果
struct tagChiHuResult
{
	DWORD							dwChiHuKind;						//吃胡类型
	DWORD							dwChiHuRight;						//胡牌权位
	DWORD							dwWinTimes;							//番数数目
	bool							bChiJiaCard;						//是不是吃夹牌 （中间的牌）
};

//杠牌结果
struct tagGangCardResult
{
	BYTE							cbCardCount;						//扑克数目
	BYTE							cbCardData[4][4];					//扑克数据
	WORD                            cbGangType;							//杠牌类型
	//WORD							cbFirstActionMask;					
};

//分析子项
struct tagAnalyseItem
{
	BYTE							cbCardEye;							//牌眼扑克
	WORD							cbWeaveKind[4];						//组合类型
	BYTE							cbCenterCard[4];					//中心扑克
	bool							bWeave[4];						//是否 固定的组合
};
//查听结构
struct tagChaTingItem
{
	BYTE							cbDisCount;							//弃牌牌数目
	BYTE							cbHuCount[13];						//听牌数目	
	BYTE							cbDisCardData[13];					//打出不要的牌
	BYTE							cbCardData[13][10];					//打出的牌和能胡的牌数据
	BYTE							cbHupaiFansu[13][10];					//打出的牌和胡牌番数
	BYTE							cbHupaiLessCount[13][10];				//对应胡牌剩余的数目
};

// 种牌数据
struct tagZhonePaiData
{
	BYTE	m_preZhongPaiCardData;					// 上一局的种牌类型
	BYTE	m_cbCurrentZhongPaiCardData;			// 当前局的种牌类型
	BYTE	m_cbZhonePaiCount;						// 连续种牌的局数
};

// 吃胡分析传递结构
struct tagChiHuData
{
	bool m_bIsLaiZi;			// 是否癞子
	bool m_bIsTianHu;			// 是否天胡
	bool m_bIsDiHu;				// 是否地胡
	bool m_bHaidilao;			// 是否海底捞
	bool m_bIsGangKai;		// 是否为杠上开花
	bool m_bIsJiChuWanFa;		// 是否是鸡胡玩法
	tagZhonePaiData m_tZhonePaiData;	// 种牌的数据
	int	m_nHaiDiLaoYueTwo;					// 是否海底捞月2番
	int	m_nDiHuTwo;							// 是否地2番
};


//////////////////////////////////////////////////////////////////////////

//数组说明
typedef CArrayTemplate<tagAnalyseItem,tagAnalyseItem &> CAnalyseItemArray;

//游戏逻辑类
class CGameLogic
{
	//变量定义
protected:
	static const BYTE				m_cbCardDataArray[MAX_REPERTORY];			//扑克数据
	static const BYTE				m_cbCardAndroidDataArray[520];	//扑克数据
public:
	/*int								m_cbCardColorCount;
	bool							m_cbAIQueYaojiu;
	bool							m_cbJiePeng;*/
	BYTE							m_cbCurrentCard;
	bool							m_bHaidiPao;						//海底炮
	bool							m_bHaidilao;						//海底捞
	bool							m_blongqidui;						//是否龙七对
	bool							m_bTianHu;							// 天地胡
	bool							m_bDiHu;							// 地胡
	

	//函数定义
public:
	//构造函数
	CGameLogic();
	//析构函数
	virtual ~CGameLogic();

	//控制函数
public:
	void CopyCardDataArray(BYTE cbWeaveCard[MAX_REPERTORY], BYTE cbCount = MAX_REPERTORY);
	//	获取扑克组合 组合后的扑克，组合数
	BYTE GetWeaveItem(BYTE cbWeaveCard[12], BYTE nType, BYTE cbCards[MAX_REPERTORY] = NULL, bool bSwitch = false);
	//机器人扑克
	void GetAndroidCard(BYTE cbIndex,BYTE cbAndroidCard[],BYTE cbCount);
	//混乱扑克
	void RandCardData(BYTE cbCardData[], BYTE cbMaxCount);
	//混乱扑克
	void RandChangCardData(BYTE cbCardData[], BYTE cbMaxCount);
	//混乱扑克
	void RandCardData(BYTE cbCardData[], BYTE cbMaxCount,BYTE cbAndroidCard[],BYTE cbAndroidCount);
	//删除扑克
	bool RemoveCard(BYTE cbCardIndex[MAX_INDEX], BYTE cbRemoveCard);
	//删除扑克
	bool RemoveCard(BYTE cbCardIndex[MAX_INDEX], BYTE cbRemoveCard[], BYTE cbRemoveCount);
	//删除扑克
	bool RemoveCard(BYTE cbCardData[], BYTE cbCardCount, BYTE cbRemoveCard[], BYTE cbRemoveCount);
	//删除扑克
	bool RemoveAndroidCard(BYTE cbCardData[], BYTE cbCardCount, BYTE cbRemoveCard[], BYTE cbRemoveCount);
	//最少的花色
	int GetMinQuemenType(BYTE cbCardIndex[MAX_INDEX]);
	//辅助函数
public:
	//有效判断
	bool IsValidCard(BYTE cbCardData);
	//扑克数目
	BYTE GetCardCount(BYTE cbCardIndex[MAX_INDEX]);
	//组合扑克
	BYTE GetWeaveCard(BYTE cbWeaveKind, BYTE cbCenterCard, BYTE cbCardBuffer[4]);

	//等级函数
public:
	//动作等级
	BYTE GetUserActionRank(BYTE cbUserAction);
	//胡牌等级
	WORD GetChiHuActionRank(tagChiHuResult & ChiHuResult);

	//动作判断
public:
	//吃牌判断
	BYTE EstimateEatCard(BYTE cbCardIndex[MAX_INDEX], BYTE cbCurrentCard);
	//碰牌判断
	BYTE EstimatePengCard(BYTE cbCardIndex[MAX_INDEX], BYTE cbCurrentCard, BYTE m_cbQuemen, bool ishongzhongLaiZi = false);
	//杠牌判断
	BYTE EstimateGangCard(BYTE cbCardIndex[MAX_INDEX], BYTE cbCurrentCard, BYTE m_cbQuemen, bool ishongzhongLaiZi = false);
	//将对判断
	BYTE EstimateDuiCard(BYTE cbCardIndex[MAX_INDEX], BYTE cbCurrentCard, BYTE m_cbQuemen);
	//动作判断
public:
	//获取听牌可能的最大番
	WORD GetAnalyseTingCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount, DWORD dwChiHuRight,BYTE m_cbQueMen, tagChiHuData &chiHuTmp);
	//听牌分析
	WORD AnalyseTingCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount, DWORD dwChiHuRight,BYTE m_cbQueMen,tagChiHuData &chiHuTmp);
	//杠牌分析
	WORD AnalyseGangCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount, tagGangCardResult & GangCardResult,BYTE m_cbQueMen,BYTE cbCenterCard);
	//没出牌前杠
	WORD AnalyseFirstGangCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, tagGangCardResult & GangCardResult,BYTE m_cbQueMen);
	//机器人首出杠牌分析
	WORD AnalyseAndroidFirstGangCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, tagGangCardResult & GangCardResult);
	//特殊杠牌分析
	WORD AnalyseSpeGangCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, tagGangCardResult & GangCardResult);
	//特殊杠牌分析
	WORD AnalyseAndroidSpeGangCard(BYTE cbCardIndex[MAX_INDEX],tagGangCardResult & GangCardResult);
	//组合特殊杠牌分析
	WORD AnalyseZuHeSpeGangCard(BYTE cbCardIndex[MAX_INDEX],tagWeaveItem WeaveItem[], BYTE cbItemCount, tagGangCardResult & GangCardResult);
	//机器人组合特殊杠牌分析
	WORD AnalyseAndroidZuHeSpeGangCard(BYTE cbCardIndex[MAX_INDEX],tagWeaveItem WeaveItem[], BYTE cbItemCount, tagGangCardResult & GangCardResult);
	//吃胡分析
	WORD AnalyseChiHuCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount, BYTE cbCurrentCard, DWORD dwChiHuRight, tagChiHuResult & ChiHuResult,BYTE m_cbQueMen, tagChiHuData &chiHuDataTmp,bool iscalcLaizi = true,bool isChaTing = false);
	//吃胡分析并得到最终的胡牌数据
	bool AnalyseChiHuCardAndChangeData(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, BYTE cbCurrentCard,tagChiHuData &chiHuDataTmp);
	//吃胡牌的数量
	int ChiHuCardCount(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount,BYTE m_cbQueMen,tagChiHuData &chiHuTmp);
	//获取四归一的数量
	BYTE GetFourtoOneCount(BYTE cbCardIndex[MAX_INDEX],tagWeaveItem WeaveItem[], BYTE cbWeaveCount);

	//获取变牌后的数据
	WORD AnalyseChiHuCardAfterChangeCard(BYTE cbCardIndex[MAX_INDEX], BYTE cbCardIndexOut[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount, DWORD dwChiHuRight, tagChiHuData &chiHuDataTmp,bool iscalcLaizi = true);
public:
	//开门判断（吃、叉或明杠牌），暗杠不算开门。
	bool IsWeaveItemPublic(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount);
	//不能缺1，9，当手牌中有风、字牌的时候可免1、9。
	bool IsYaoJiu(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount);
	//必须少缺门才能胡，即没有该花色才能胡牌。
	bool IsShaoHuaSe(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount,BYTE cbQueHuaSe);
	//清一色牌
	bool IsQingYiSe(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount);
	//混一色牌
	bool IsHunYiSe(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount);
	//字一色牌
	bool IsZiYiSe(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount);
	//碰碰胡
	bool IsPenPenHu(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount,BYTE cbCardIndexTemp[MAX_INDEX]);
	//第二张落地
	bool IsLuoDiHu(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount,BYTE cbCardIndexTemp[MAX_INDEX] );
	//坎坎胡
	bool IsKanKanHu(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount);
	//七小对牌
	bool IsQiXiaoDui(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount,BYTE cbCardIndexTemp[MAX_INDEX]);
	//豪华七小对
	bool IsHaoHuaQiXiaoDui(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount,BYTE cbCardIndexTemp[MAX_INDEX]);
	//双豪华七小对
	bool IsDHaoHuaQiXiaoDui(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount,BYTE cbCardIndexTemp[MAX_INDEX]);
	//三豪华七小对
	bool IsTHaoHuaQiXiaoDui(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount,BYTE cbCardIndexTemp[MAX_INDEX]);
	//十三夭牌
	bool IsShiSanYao(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount);
	//纯幺九
	bool IsChunSanJiu(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount);
	//混幺九
	bool IsHunSanJiu(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount);
	// 十八罗汉
	bool IsTenEightLuoHan(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount);
	// 天地胡
	bool IsTianDiHu(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount);
	// 获取牌里面的对子数
	BYTE getDuiCount(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount);
	// 获取三个相同牌的数量
	BYTE getKeZiCount(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount);
	// 获取四个相同牌的数量
	BYTE getFourKeZiCount(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount);
	//胡牌番数
	bool PanShu(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount);
	//获取任务牌型
	WORD GetTaskType(BYTE cbCardType,BYTE cbCardData);

	//转换函数
public:
	//扑克转换
	BYTE SwitchToCardData(BYTE cbCardIndex);
	//扑克转换
	BYTE SwitchToCardIndex(BYTE cbCardData);
	//扑克转换
	BYTE SwitchToCardData(BYTE cbCardIndex[MAX_INDEX], BYTE cbCardData[MAX_COUNT]);
	//扑克转换
	BYTE SwitchToCardIndex(BYTE cbCardData[], BYTE cbCardCount, BYTE cbCardIndex[MAX_INDEX]);
	//找出最少的类型
	int MinQuemenType(BYTE cbCardIndex[MAX_INDEX]);
	//判断玩家是否需要发牌
	bool IsNeedCard(BYTE cbCardIndex[MAX_INDEX]);

	CString GetCardName(BYTE nCard);
	CString GetActionName(WORD cbActionMask);
	CString GetHuPaiRightName(DWORD dwChiHuRight);

	BYTE GetIsolatedCard(BYTE cbCardIndex[MAX_INDEX], BYTE byOutCard[5] = NULL);

	//特殊胡牌
	WORD EstimateChiHu(BYTE cbCardIndex[MAX_INDEX],BYTE cbZhongPaiIndex);
	//获取能听牌的牌数及对应的番数 
	bool AnalyseChaTingCard(BYTE cbCardIndex[MAX_INDEX],tagChaTingItem &cbChaTingCardArray,tagWeaveItem WeaveItem[], BYTE cbItemCount, DWORD dwChiHuRight,BYTE m_cbQueMen,bool IsSendCard,tagChiHuData &chiHuTmp);

	//内部函数
	BYTE getZhongPaiIndex(BYTE currentZhongPaiCardData,bool isZhongPai);
private:	
	//分析扑克
	bool AnalyseCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbItemCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbCardIndexTemp[MAX_INDEX]);
	//变牌后分析扑克
	bool AnalyseChangOneCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbCardIndexTemp[MAX_INDEX],BYTE cbZhongPaiIndex);
	//变牌后分析扑克
	bool AnalyseChangTwoCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbCardIndexTemp[MAX_INDEX],BYTE cbZhongPaiIndex);
	//变牌后分析扑克
	bool AnalyseChangThreeCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbCardIndexTemp[MAX_INDEX],BYTE cbZhongPaiIndex);
	//变牌后分析扑克
	bool AnalyseChangFourCard(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbCardIndexTemp[MAX_INDEX],BYTE cbZhongPaiIndex);

	//变牌后分析扑克
	bool AnalyseChangOneCardAndChange(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbZhongPaiIndex);
	// 变牌后分析扑克七小对，十三幺
	DWORD analyseChangeOneCardSpecial(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,bool isChaTing,BYTE cbZhongPaiIndex);
	//变牌后分析扑克
	bool AnalyseChangTwoCardAndChange(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbZhongPaiIndex);
		// 变牌后分析扑克七小对，十三幺
	DWORD analyseChangeTwoCardSpecial(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,bool isChaTing,BYTE cbZhongPaiIndex);
	//变牌后分析扑克
	bool AnalyseChangThreeCardAndChange(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbZhongPaiIndex);
		// 变牌后分析扑克七小对，十三幺
	DWORD analyseChangeThreeCardSpecial(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,bool isChaTing,BYTE cbZhongPaiIndex);
	//变牌后分析扑克
	bool AnalyseChangFourCardAndChange(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,BYTE cbZhongPaiIndex);
		// 变牌后分析扑克七小对，十三幺
	DWORD analyseChangeFourCardSpecial(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount, CAnalyseItemArray & AnalyseItemArray,bool isChaTing,BYTE cbZhongPaiIndex);
	// 处理变牌
	DWORD analyseChangeSpecial(BYTE cbCardIndex[MAX_INDEX], tagWeaveItem WeaveItem[], BYTE cbWeaveCount,BYTE cbCardIndexTemp[MAX_INDEX],int fans[13]);

	// 处理获取最大的类型
	DWORD getMaxValueChiHuType(int fans[13]);

	int getAllFansValue(int *fans);

	
};
extern void WriteLog(CString strFileName, CString strText);
//////////////////////////////////////////////////////////////////////////

#endif