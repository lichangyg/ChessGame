﻿#include "StdAfx.h"
#include "TableFrameSink.h"
#include <math.h>
#include "..\消息定义\MylogFile.h"
 
#include <sstream>
#include <io.h>
#include <fcntl.h>
//////////////////////////////////////////////////////////////////////////

#define IDI_TIMER_AUTO_OPERATE			1										//吃，碰，胡等操作
#define IDI_TIMER_AUTO_OUTCARD			2										//吃，碰，胡等操作


#define PLAYER_TIMER_OPT_NULL			-1										//玩家时间没有
#define IDI_TIMER_MAIN				10										//服务器定时，用于玩家超时
#define IDI_TIMER_OPERATENOTIFY		11										//服务器定时，用于延迟发操作通知
#define IDI_TIMER_SENDCARD			12										//服务器定时，用于延迟发牌

#define IDI_TIMER_XUAN_PIAOQI		13										//服务器定时，选择彯起缺门
#define IDI_TIMER_DIAO_YU			14										//服务器定时，钓鱼时间
#define IDI_TIMER_START_ANI_FINISH	15										//服务器定时，客户端开始动画

#define TIME_HEAR_STATUS			20									//出牌定时器

#define TIME_OPERATE_CARD			16									//操作定时器
#define TIME_OPERATE_CARD_FIRST		20									//操作定时器(第一次)
#define TIME_OPERATE_CARD_ZIJIAN	32									//操作定时器(自建房定时)

#define IDI_TIMER_QUEMENSEL			17									//服务器定时，选择缺门时间
#define IDI_TIMER_CHANG_CARD		18										//服务器定时，选择换牌
#define IDI_TIMER_CHANGCARD_END		19										//服务器定时，换牌时间结束

#define IDI_TIMER_BAOTING			20										//服务器定时，报听时间

#define IDI_TIME_JIESAN				21									//解散计时器
#define TIME_JIESAN_LEN				120									//解散时长

#define TIME_BAO_PAI_DELAY_TIME		4200									//宝牌延时时间
//静态变量
const WORD			CTableFrameSink::m_wPlayerCount=GAME_PLAYER;			//游戏人数
const enStartMode	CTableFrameSink::m_GameStartMode=enStartMode_FullReady;	//开始模式

LONG		CTableFrameSink::m_LRoomAllUserNKuCun = 0;			//	玩家实际总输赢积分
LONG		CTableFrameSink::m_LRoomInitNKuCun = 0;		//	玩家实际总输赢库存设定积分
TCHAR       CTableFrameSink::m_szIniFileName[MAX_PATH] = {};
//////////////////////////////////////////////////////////////////////////
void InitConsole()
{
	int nRet = 0;
	FILE* fp;
	AllocConsole();
	nRet = _open_osfhandle((long)GetStdHandle(STD_OUTPUT_HANDLE),_O_TEXT);
	fp = _fdopen(nRet,"w");
	*stdout = *fp;
	setvbuf(stdout,NULL,_IONBF,0);
}
//构造函数
CTableFrameSink::CTableFrameSink()
{
	//游戏变量
	//InitConsole();
	m_wSiceCount=MAKEWORD(1,1);
	m_wBankerUser=INVALID_CHAIR;
	m_wNextBankerUser = INVALID_CHAIR;
	m_wlastUser = INVALID_CHAIR;
	ZeroMemory(m_cbCardIndex,sizeof(m_cbCardIndex));
	ZeroMemory(m_bTrustee,sizeof(m_bTrustee));
	//ZeroMemory(m_bTianDiHupai,sizeof(m_bTianDiHupai));
	m_MahJongMultipleFan = 0;
	m_cbGameIsEnd = false;	
	m_bGoodCard = false;
	m_bChangCardCountAll = 0;
	m_bFirstHuUser = false;
	//出牌信息
	m_cbOutCardData=0;
	m_cbOutCardCount=0;
	m_wOutCardUser=INVALID_CHAIR;
	ZeroMemory(m_cbDiscardCard,sizeof(m_cbDiscardCard));
	ZeroMemory(m_cbDiscardCount,sizeof(m_cbDiscardCount));
	ZeroMemory(m_bPiaoQi,sizeof(m_bPiaoQi));
	ZeroMemory(m_bPiaoQiHupai,sizeof(m_bPiaoQiHupai));
	ZeroMemory(m_AllFollowCount,sizeof(m_AllFollowCount));
	//发牌信息
	m_cbSendCardData=0;
	m_cbSendCardCount=0;
	m_cbLeftCardCount=0;
	ZeroMemory(m_cbRepertoryCard,sizeof(m_cbRepertoryCard));

	//运行变量
	m_cbProvideCard=0;
	m_cPlayHuCount = 0;
	m_wResumeUser=INVALID_CHAIR;
	m_wCurrentUser=INVALID_CHAIR;
	m_wProvideUser=INVALID_CHAIR;
	m_cbfirstIndex = INVALID_CHAIR;
	m_cbscendIndex = INVALID_CHAIR;
	m_wLastOutcardUser = INVALID_CHAIR;
	m_wFollowBankCount = 0;
	//状态变量
	m_bSendStatus=false;
	m_bGangStatus=false;
	m_bIsGangKai = false;
	ZeroMemory(m_bEnjoinChiHu,sizeof(m_bEnjoinChiHu));
	ZeroMemory(m_bEnjoinChiPeng,sizeof(m_bEnjoinChiPeng));
	ZeroMemory(m_bEnjoinChiHuIndex,sizeof(m_bEnjoinChiHuIndex));
	ZeroMemory(m_bEnjoinPeng,sizeof(m_bEnjoinPeng));
	ZeroMemory(m_bCanBuGang,sizeof(m_bCanBuGang));
	ZeroMemory(m_bFirstChangeBao,sizeof(m_bFirstChangeBao));
	ZeroMemory(m_bFirstLookBao,sizeof(m_bFirstLookBao));
	ZeroMemory(m_bCanLookBao,sizeof(m_bCanLookBao));
	ZeroMemory(m_bKaimen,sizeof(m_bKaimen));
	ZeroMemory(m_bPlayerStatus,sizeof(m_bPlayerStatus));
	ZeroMemory(m_cPlaySequenceHu,sizeof(m_cPlaySequenceHu));
	m_islookBaopai = false;
	m_bIsNoHaveQuemen = false;
	m_RoomBasicScore = 0;
	//用户状态
	ZeroMemory(m_bResponse,sizeof(m_bResponse));
	ZeroMemory(m_cbUserAction,sizeof(m_cbUserAction));
	ZeroMemory(m_cbOperateCard,sizeof(m_cbOperateCard));
	ZeroMemory(m_cbPerformAction,sizeof(m_cbPerformAction));
	ZeroMemory(m_bBeginOutCard,sizeof(m_bBeginOutCard));
	ZeroMemory(m_cbQueMen,sizeof(m_cbQueMen));
	//查花猪差大叫
	ZeroMemory(m_bChaHuazhu,sizeof(m_bChaHuazhu));
	ZeroMemory(m_bChaDajiao,sizeof(m_bChaDajiao));
	ZeroMemory(m_cbWinMax,sizeof(m_cbWinMax));
	//组合扑克
	ZeroMemory(m_WeaveItemArray,sizeof(m_WeaveItemArray));
	ZeroMemory(m_cbWeaveItemCount,sizeof(m_cbWeaveItemCount));

	ZeroMemory(&m_OutCardItemArray,sizeof(m_OutCardItemArray));

	//结束信息
	m_cbChiHuCard=0;
	ZeroMemory(&m_ChiHuResult,sizeof(m_ChiHuResult));

	//组件变量
	m_pITableFrame=NULL;
	m_pGameServiceOption=NULL;
	//m_bDoubleGang=true;
	m_bGangCount=0;
	ZeroMemory(m_bUserGangCount,sizeof(m_bUserGangCount));
	ZeroMemory(m_GangCount,sizeof(m_GangCount));
	ZeroMemory(m_bUserGenCount,sizeof(m_bUserGenCount));
	ZeroMemory(m_GangCountscore,sizeof(m_GangCountscore));
	ZeroMemory(m_GangWinscore,sizeof(m_GangWinscore));
	ZeroMemory(m_lGameScore,sizeof(m_lGameScore));

	ZeroMemory(m_cbHupaiIndex,sizeof(m_cbHupaiIndex));
	m_bHasSendLastCard = false;
	m_bHasChangCardend = false;
	m_bHasDingQue = false;
	m_bHasSendHuCard = false;
	m_cbHupaiCount = 0;
	m_cbGameHuCount = 0;
	m_cbGameEndCount = 0;
	ZeroMemory(m_bChangCard,sizeof(m_bChangCard));
	ZeroMemory(m_bChangCardDate,sizeof(m_bChangCardDate));
	ZeroMemory(m_bChangDate,sizeof(m_bChangDate));
	ZeroMemory(m_bChangCardCount,sizeof(m_bChangCardCount));
	ZeroMemory(m_cbHasHuCardData,sizeof(m_cbHasHuCardData));
	ZeroMemory(m_cbHuCardData,sizeof(m_cbHuCardData));
	ZeroMemory(m_bHupaiType,sizeof(m_bHupaiType));

	ZeroMemory(lGameScore_all,sizeof(lGameScore_all));
	ZeroMemory(lGameScore,sizeof(lGameScore));
	ZeroMemory(lGameScore_other,sizeof(lGameScore_other));
	ZeroMemory(m_bHupaiTypeRight,sizeof(m_bHupaiTypeRight));
	ZeroMemory(m_bHupaiKindName,sizeof(m_bHupaiKindName));
	ZeroMemory(dwChiHuRight,sizeof(dwChiHuRight));
	ZeroMemory(m_bHupaiZongfan,sizeof(m_bHupaiZongfan));
	ZeroMemory(lGameGangScore,sizeof(lGameGangScore));

	ZeroMemory(m_bGangKai,sizeof(m_bGangKai));
	ZeroMemory(m_bGangPao,sizeof(m_bGangPao));
	ZeroMemory(m_bGangHu,sizeof(m_bGangHu));
	ZeroMemory(m_bMahJongMultipleFan,sizeof(m_bMahJongMultipleFan));

	//ZeroMemory(lGameScore,sizeof(lGameScore));
	//ZeroMemory(lGameScore_other,sizeof(lGameScore_other));
	//自动托管
	ZeroMemory(m_bAutoStustee,sizeof(m_bAutoStustee));
	ZeroMemory(m_bPlayerOffLine,sizeof(m_bPlayerOffLine));
	memset(&m_opterPassTimeArr,PLAYER_TIMER_OPT_NULL,sizeof(m_opterPassTimeArr));
	m_cbLastSendCardData = 0;
	m_cbTheLastSendCardData = 0;
	m_bFirstListen = true;
	m_bDropGoodThisTurn = false;
	m_gamePassSecond = 0;

	// 种牌的数据
	m_tZhongPaiData.m_cbZhonePaiCount = 0;
	m_tZhongPaiData.m_cbCurrentZhongPaiCardData = INVALID_BYTE;
	m_tZhongPaiData.m_preZhongPaiCardData = INVALID_BYTE;

	m_nHaiDiLaoYueTwo = 0;
	m_nDiHuTwo = 0;
	m_nFollowBank = 0;
	m_nZhonePai = 0;
	m_nFollowBankFlag = true;
	m_nFollowCardData = INVALID_BYTE;
	

	//牌局变量
	m_dwStartTime=0;
	m_dwEndTime=0;
	ZeroMemory(m_recordID, sizeof(m_recordID));	//	记录ID
	////测试
	//StartTableID=0;
	//EndTableID=0;

	_tcscpy(m_tcAccount,_TEXT(""));
	_tcscpy(m_tcOriginCards,_TEXT(""));
	_tcscpy(m_tcRecord,_TEXT(""));
	m_iGoodCardPercent = 0;
	m_AmendPercent = 0;
	m_bOtherOperate = false;
	ZeroMemory(m_bPlayerNotHu,sizeof(m_bPlayerNotHu));
	RepositTableFrameSink();

	m_RoomNum=0;
	m_LaiZi = 1;
	m_MaShu =0;
	m_cbPlayJushu =0;
	m_cbHavePlayCount =0;
	m_cbZhaMaCount =0;
	m_nOwnerUserID = INVALID_CHAIR;
	m_wRequestChairID = INVALID_CHAIR;
	m_nLessTime = 0;

	m_ZhongMaCount = 0;
	ZeroMemory(m_cbZhaMaCardData,sizeof(m_cbZhaMaCardData));
	ZeroMemory(m_bZhongZhaMa,sizeof(m_bZhongZhaMa));

	ZeroMemory(m_AllHuTime,sizeof(m_AllHuTime));
	ZeroMemory(m_AllMingGangTime,sizeof(m_AllMingGangTime));
	ZeroMemory(m_AllAnGangTime,sizeof(m_AllAnGangTime));
	ZeroMemory(m_AllFanGangTime,sizeof(m_AllFanGangTime));
	ZeroMemory(m_AllJieGangTime,sizeof(m_AllJieGangTime));
	ZeroMemory(m_AllZhongMaCount,sizeof(m_AllZhongMaCount));

	ZeroMemory(m_AllHuScore,sizeof(m_AllHuScore));
	ZeroMemory(m_AllMingGangScore,sizeof(m_AllMingGangScore));
	ZeroMemory(m_AllAnGangScore,sizeof(m_AllAnGangScore));
	ZeroMemory(m_AllFanJieGangScore,sizeof(m_AllFanJieGangScore));
	ZeroMemory(m_AllZhongMaScore,sizeof(m_AllZhongMaScore));
	ZeroMemory(m_AllWinScore,sizeof(m_AllWinScore));
	m_bGameOver=false;
	ZeroMemory(m_bDisMiss,sizeof(m_bDisMiss));
	ZeroMemory(m_bSelectDisMiss,sizeof(m_bSelectDisMiss));
	m_JieSanTime = 0;
	ZeroMemory(&m_ChaTingCardArray,sizeof(m_ChaTingCardArray));
	return;
}

//析构函数
CTableFrameSink::~CTableFrameSink(void)
{
}

//接口查询
void * __cdecl CTableFrameSink::QueryInterface(const IID & Guid, DWORD dwQueryVer)
{
	QUERYINTERFACE(ITableFrameSink,Guid,dwQueryVer);
	QUERYINTERFACE(ITableUserAction,Guid,dwQueryVer);
	QUERYINTERFACE_IUNKNOWNEX(ITableFrameSink,Guid,dwQueryVer);
	return NULL;
}

//初始化
bool __cdecl CTableFrameSink::InitTableFrameSink(IUnknownEx * pIUnknownEx)
{
	//查询接口
	ASSERT(pIUnknownEx!=NULL);
	m_pITableFrame=GET_OBJECTPTR_INTERFACE(pIUnknownEx,ITableFrame);
	if (m_pITableFrame==NULL) return false;

	//获取参数
	m_pGameServiceOption=m_pITableFrame->GetGameServiceOption();
	ASSERT(m_pGameServiceOption!=NULL);
	ReadConfig();
	m_pITableFrame->SetGameTimer(IDI_TIME_JIESAN,1000,-1,0);
	//CString str,strFileName,strRoomName; 
	//strRoomName.Format(TEXT("%s.ini"),m_pGameServiceOption->szGameRoomName);
	//str.Format(TEXT("%s"),_T(strRoomName));//m_pGameServiceOption->szIniFile
	//TCHAR szPath[MAX_PATH];
	//GetCurrentDirectory(MAX_PATH, szPath);
	//strFileName.Format(TEXT("%s\\%s"), szPath, str);
	//_sntprintf(m_szIniFileName,sizeof(m_szIniFileName),TEXT("%s"),strFileName);
	//m_LRoomAllUserNKuCun = GetPrivateProfileInt(TEXT("GameOption"),TEXT("RoomAllUserNKuCun"),97000,m_szIniFileName);
	//m_LRoomInitNKuCun = GetPrivateProfileInt(TEXT("GameOption"),TEXT("RoomInitNKuCun"),100000,m_szIniFileName);

	CMylogFile::Instance().SetServerID(m_pGameServiceOption->wServerID, true, (TCHAR*)m_pGameServiceOption->szGameRoomName);
	//CMylogFile::Instance().WriteLogFmt("strFileName = %s, m_szIniFileName=%s",m_szIniFileName,m_szIniFileName);
	//CMylogFile::Instance().SetServerTableID(m_pITableFrame->GetTableID(), true, (TCHAR*)m_pGameServiceOption->szGameRoomName);
	return true;
}
void CTableFrameSink::ReadConfig()
{
	TCHAR szPath[MAX_PATH]=TEXT("");
	GetCurrentDirectory(sizeof(szPath),szPath);
	//读取配置
	TCHAR szFileName[MAX_PATH]={0};
	_sntprintf(m_szIniFileName,sizeof(m_szIniFileName),TEXT("MJGameConfig\\HZMJ_%d.ini"),m_pGameServiceOption->wServerID);

	m_LRoomAllUserNKuCun = GetPrivateProfileInt(TEXT("GameOption"),TEXT("RoomAllUserNKuCun"),9700000,m_szIniFileName);
	m_LRoomInitNKuCun = GetPrivateProfileInt(TEXT("GameOption"),TEXT("RoomInitNKuCun"),10000000,m_szIniFileName);
	if (m_pGameServiceOption->wGameZoneType != em_zoneType_zhuangJin)
	{
		//局数
		m_cbPlayJushu = GetPrivateProfileInt(TEXT("GameOption"),TEXT("Jushu"),8,m_szIniFileName);
		//码数
		m_MaShu = GetPrivateProfileInt(TEXT("GameOption"),TEXT("Mashu"),4,m_szIniFileName);
		m_cbZhaMaCount = m_MaShu;
	}
	
	m_RoomBasicScore = m_pGameServiceOption->lCellScore;//房间底分
}
//复位桌子
void __cdecl CTableFrameSink::RepositTableFrameSink()
{
	//游戏变量
	m_wSiceCount=MAKEWORD(1,1);
	ZeroMemory(m_cbCardIndex,sizeof(m_cbCardIndex));
	ZeroMemory(m_bTrustee,sizeof(m_bTrustee));
	ZeroMemory(m_bTianDiHupai,sizeof(m_bTianDiHupai));
	m_bDiHupai = false;
	m_bTianHupai = false;
	m_bGoodCard = false;
	m_bChangCardCountAll = 0;
	//出牌信息
	m_cbOutCardData=0;
	m_cbOutCardCount=0;
	m_wOutCardUser=INVALID_CHAIR;
	ZeroMemory(m_cbDiscardCard,sizeof(m_cbDiscardCard));
	ZeroMemory(m_cbDiscardCount,sizeof(m_cbDiscardCount));

	ZeroMemory(m_bChangCard,sizeof(m_bChangCard));
	ZeroMemory(m_bChangCardDate,sizeof(m_bChangCardDate));
	ZeroMemory(m_bChangDate,sizeof(m_bChangDate));
	ZeroMemory(m_bChangCardCount,sizeof(m_bChangCardCount));
	ZeroMemory(&m_OutCardItemArray,sizeof(m_OutCardItemArray));
	ZeroMemory(m_cbHasHuCardData,sizeof(m_cbHasHuCardData));
	ZeroMemory(m_cbHuCardData,sizeof(m_cbHuCardData));
	ZeroMemory(m_bHupaiType,sizeof(m_bHupaiType));

	ZeroMemory(lGameScore_all,sizeof(lGameScore_all));
	ZeroMemory(lGameScore,sizeof(lGameScore));
	ZeroMemory(lGameScore_other,sizeof(lGameScore_other));
	ZeroMemory(m_bHupaiTypeRight,sizeof(m_bHupaiTypeRight));
	ZeroMemory(m_bHupaiKindName,sizeof(m_bHupaiKindName));
	ZeroMemory(dwChiHuRight,sizeof(dwChiHuRight));
	ZeroMemory(m_bHupaiZongfan,sizeof(m_bHupaiZongfan));
	ZeroMemory(lGameGangScore,sizeof(lGameGangScore));
	ZeroMemory(m_bGangKai,sizeof(m_bGangKai));
	ZeroMemory(m_bGangPao,sizeof(m_bGangPao));
	ZeroMemory(m_bGangHu,sizeof(m_bGangHu));
	ZeroMemory(m_lPiaoQiscore,sizeof(m_lPiaoQiscore));
	ZeroMemory(m_lJiadiScore,sizeof(m_lJiadiScore));
	//发牌信息
	m_cbSendCardData=0;
	m_cbSendCardCount=0;
	m_cbLeftCardCount=0;
	m_cbGetFinalyIndex = 0;

	ZeroMemory(m_cbRepertoryCard,sizeof(m_cbRepertoryCard));

	//运行变量
	m_cbProvideCard=0;
	m_cPlayHuCount = 0;
	m_wResumeUser=INVALID_CHAIR;
	m_wCurrentUser=INVALID_CHAIR;
	m_wProvideUser=INVALID_CHAIR;
	m_wLastOutcardUser = INVALID_CHAIR;

	m_cbfirstIndex = INVALID_CHAIR;
	m_cbscendIndex = INVALID_CHAIR;

	//状态变量
	m_bSendStatus=false;
	m_bGangStatus=false;
	ZeroMemory(m_bEnjoinChiHu,sizeof(m_bEnjoinChiHu));
	ZeroMemory(m_bEnjoinChiPeng,sizeof(m_bEnjoinChiPeng));
	ZeroMemory(m_bEnjoinPeng,sizeof(m_bEnjoinPeng));
	ZeroMemory(m_bEnjoinChiHuIndex,sizeof(m_bEnjoinChiHuIndex));
	ZeroMemory(m_bCanBuGang,sizeof(m_bCanBuGang));
	ZeroMemory(m_bFirstChangeBao,sizeof(m_bFirstChangeBao));
	ZeroMemory(m_bFirstLookBao,sizeof(m_bFirstLookBao));
	ZeroMemory(m_bCanLookBao,sizeof(m_bCanLookBao));
	ZeroMemory(m_bKaimen,sizeof(m_bKaimen));
	ZeroMemory(m_bPlayerStatus,sizeof(m_bPlayerStatus));
	ZeroMemory(m_cPlaySequenceHu,sizeof(m_cPlaySequenceHu));
	m_islookBaopai = false;
	//用户状态
	ZeroMemory(m_bResponse,sizeof(m_bResponse));
	ZeroMemory(m_cbUserAction,sizeof(m_cbUserAction));
	ZeroMemory(m_cbOperateCard,sizeof(m_cbOperateCard));
	ZeroMemory(m_cbPerformAction,sizeof(m_cbPerformAction));

	//查花猪差大叫
	ZeroMemory(m_bChaHuazhu,sizeof(m_bChaHuazhu));
	ZeroMemory(m_bChaDajiao,sizeof(m_bChaDajiao));
	ZeroMemory(m_cbWinMax,sizeof(m_cbWinMax));
	//组合扑克
	ZeroMemory(m_WeaveItemArray,sizeof(m_WeaveItemArray));
	ZeroMemory(m_cbWeaveItemCount,sizeof(m_cbWeaveItemCount));

	//结束信息
	m_cbChiHuCard=0;
	ZeroMemory(&m_ChiHuResult,sizeof(m_ChiHuResult));

	//自动托管
	ZeroMemory(m_bAutoStustee,sizeof(m_bAutoStustee));
	ZeroMemory(m_bPlayerOffLine,sizeof(m_bPlayerOffLine));
	
	memset(&m_opterPassTimeArr,PLAYER_TIMER_OPT_NULL,sizeof(m_opterPassTimeArr));
	m_cbLastSendCardData = 0;
	m_cbTheLastSendCardData = 0;
	m_bFirstListen = true;
	m_bQiangGang = false;
	m_bQiangGangHu = false;
	m_bIsLastGang = false;
	m_bGangStatusOutcard = false;
	m_bGangShangPao = false;
	m_bQiangGangCancel = false;
	m_cbQiangGangCardData = 0;						//抢杠的牌
	m_cbQiangGangUserID = INVALID_CHAIR;						//被抢杠的人
	m_cbQiangGangOpterate = 0;
	m_bIsNoHaveQuemen = false;
	m_iRecordLastGangChairId = INVALID_CHAIR;
	m_bDropGoodThisTurn = false;
	m_bFengZhang = false;
	ZeroMemory(m_cbFengZhangCard,sizeof(m_cbFengZhangCard));
	ZeroMemory(m_bMahJongMultipleFan,sizeof(m_bMahJongMultipleFan));
	//牌局变量
	m_dwStartTime=0;
	m_dwEndTime=0;
	ZeroMemory(m_recordID, sizeof(m_recordID));	//	记录ID
	////测试
	//StartTableID=0;
	//EndTableID=0;

	_tcscpy(m_tcAccount,_TEXT(""));
	_tcscpy(m_tcOriginCards,_TEXT(""));
	_tcscpy(m_tcRecord,_TEXT(""));

	m_wFollowBankCount = 0;
	m_baoPaiStartIndex = 0;
	m_baoPaiRandVal = 0;
	m_baoPaiCardIndex = -1;
	m_bGetCardHead = true;
	m_cbHupaiOperateCount = 0;
	//钓鱼
	m_bCanSelDiaoYu = true;
	ZeroMemory(m_lDiaoYuTimes,sizeof(m_lDiaoYuTimes));
	ZeroMemory(m_bDiaoYuHasSel,sizeof(m_bDiaoYuHasSel));
	ZeroMemory(m_cbQueMen,sizeof(m_cbQueMen));
	ZeroMemory(m_bPiaoQiHasSel,sizeof(m_bPiaoQiHasSel));
	ZeroMemory(m_bChangCardHasSel,sizeof(m_bChangCardHasSel));

	ZeroMemory(m_bNeedWin, sizeof(m_bNeedWin));
	ZeroMemory(m_bNeedLost, sizeof(m_bNeedLost));
	ZeroMemory(m_goodcardTime, sizeof(m_goodcardTime));
	ZeroMemory(m_lastgoodTime, sizeof(m_lastgoodTime));

	m_bCanSelChangCard = true;
	m_bStartAinFinish = false;
	m_bCanSelQuemen = true;
	m_bLastFourCard = false;

	m_baoTingstart = false;
	m_baoTingend = false;
	m_baoTingcount = 0;
	m_bhasbaoting =0;

	m_bHaidiPao = false;
	m_bHaidilao = false;
	m_bServerTableID = 0;

	m_nFollowBankFlag = true;
	m_nFollowCardData = INVALID_BYTE;

	m_ZhongMaCount = 0;
	ZeroMemory(m_cbZhaMaCardData,sizeof(m_cbZhaMaCardData));
	ZeroMemory(m_bZhongZhaMa,sizeof(m_bZhongZhaMa));

	ZeroMemory(m_HuScore,sizeof(m_HuScore));
	ZeroMemory(m_MingGangScore,sizeof(m_MingGangScore));
	ZeroMemory(m_AnGangScore,sizeof(m_AnGangScore));
	ZeroMemory(m_FanJieGangScore,sizeof(m_FanJieGangScore));
	ZeroMemory(m_ZhongMaScore,sizeof(m_ZhongMaScore));
	ZeroMemory(m_WinScore,sizeof(m_WinScore));
	m_cbDisCount=0;
	ZeroMemory(m_cbDisData,sizeof(m_cbDisData));
	m_cbChaTing = false;
	return;
}

//开始模式
enStartMode __cdecl CTableFrameSink::GetGameStartMode()
{
	return m_GameStartMode;
}

//游戏状态
bool __cdecl CTableFrameSink::IsUserPlaying(WORD wChairID)
{
	return true;
}

void CTableFrameSink::AddTestCard(WORD wChairID, BYTE cbCardData)
{
	m_cbCardIndex[wChairID][m_GameLogic.SwitchToCardIndex(cbCardData)]++;
}

// 检测是否可以自摸玩法
bool CTableFrameSink::checkZiMo(DWORD dwChiHuKing)
{
	if(checkJiHuWangFa())
	{
		return true;
	}

	if (!checkJiHuWangFa() && checkChiHuDaHu(dwChiHuKing))
	{
		return true;
	}

	return false;
}

// 是否为大胡
bool CTableFrameSink::checkChiHuDaHu(DWORD dwChiHuKing)
{
	DWORD tempChiHuKinds[]={ CHK_QINGYISE ,CHK_HUNYISE ,CHK_ZIYISE ,CHK_PENPEN_HU, CHK_KANKANHU, CHK_QIDUI, CHK_HAOHUA_QIDUI, CHK_DHAOHUA_QIDUI, CHK_THAOHUA_QIDUI, CHK_TENTHREEYAO ,CHK_QINGYAOJIU_HU ,CHK_HUNYAOJIAO,CHK_HUNYAOJIAO};
	for (int i = 0; i < CountArray(tempChiHuKinds); ++i)
	{
		if ((dwChiHuKing & tempChiHuKinds[i]) != 0)
		{
			return true;
		}
	}

	return false;
}

// 检测是否是鸡胡玩法
bool CTableFrameSink::checkJiHuWangFa()const
{
	return true;
}

// 获取吃胡所需要的数据结构数据
tagChiHuData CTableFrameSink::getChiHuData()const
{
	tagChiHuData tempData;
	tempData.m_bIsLaiZi = m_LaiZi;
	tempData.m_bIsDiHu = m_bDiHupai;
	tempData.m_bHaidilao = m_bHaidilao;
	tempData.m_bIsTianHu = m_bTianHupai;
	tempData.m_bIsGangKai = m_bIsGangKai;
	tempData.m_bIsJiChuWanFa = checkJiHuWangFa();
	tempData.m_tZhonePaiData.m_cbCurrentZhongPaiCardData = m_tZhongPaiData.m_cbCurrentZhongPaiCardData;
	tempData.m_tZhonePaiData.m_cbZhonePaiCount = m_tZhongPaiData.m_cbZhonePaiCount;
	tempData.m_tZhonePaiData.m_preZhongPaiCardData = m_tZhongPaiData.m_preZhongPaiCardData;
	tempData.m_nHaiDiLaoYueTwo = m_nHaiDiLaoYueTwo;
	tempData.m_nDiHuTwo = m_nDiHuTwo;
	return tempData;
}

//游戏开始
bool __cdecl CTableFrameSink::OnEventGameStart()
{
	TRACE("Game start...\n");
	//printf("GameStart: \n");
	//CString str;
	CMylogFile::Instance().WriteLogFmt(m_bServerTableID,"[%s&%s%s&%s]游戏开始game start...", GetPlayerName(0).GetBuffer(0), GetPlayerName(1).GetBuffer(0), GetPlayerName(2).GetBuffer(0), GetPlayerName(3).GetBuffer(0));
	//设置状态
	m_pITableFrame->SetGameStatus(GS_MJ_PLAY);
	//获取封顶番数
	CString str; 
	/*strRoomName.Format(TEXT("%s.ini"),m_pGameServiceOption->szGameRoomName);
	str.Format(TEXT("%s"),_T(strRoomName));
	TCHAR szPath[MAX_PATH];
	GetCurrentDirectory(MAX_PATH, szPath);
	strFileName.Format(TEXT("%s\\%s"), szPath, str);*/
	//写日记
	/*CString strFile,strTemp;
	strFile.Format("log\\scnjmj.log");
	strTemp.Format("strFileName=%s, m_szIniFileName=%s,m_wBankerUser=%d \n", strFileName,m_szIniFileName,m_wBankerUser);
	WriteLog(strFile,strTemp);*/

	//TCHAR szKeyValuestart[64] = "";
	/*GetPrivateProfileString(TEXT("GameOption"),"BasicScore",TEXT(""),szKeyValuestart,sizeof(szKeyValuestart),strFileName);
	sscanf(szKeyValuestart,"%d",&m_RoomBasicScore);*/

	/*str.Format(TEXT("%s"),m_pGameServiceOption->szIniFile);
	TCHAR szPath[MAX_PATH];
	GetCurrentDirectory(MAX_PATH, szPath);
	strFileName.Format(TEXT("%s\\%s"), szPath, str);
	TCHAR szKeyValuestart[64] = "";*/
	/*GetPrivateProfileString(TEXT("GameOption"),"MahJongMultipleFan",TEXT(""),szKeyValuestart,sizeof(szKeyValuestart),strFileName);
	sscanf(szKeyValuestart,"%d",&m_MahJongMultipleFan);*/
	m_MahJongMultipleFan = GetPrivateProfileInt(TEXT("GameOption"),TEXT("MahJongMultipleFan"),4,m_szIniFileName);
	m_LRoomAllUserNKuCun = GetPrivateProfileInt(TEXT("GameOption"),TEXT("RoomAllUserNKuCun"),97000,m_szIniFileName);
	m_LRoomInitNKuCun = GetPrivateProfileInt(TEXT("GameOption"),TEXT("RoomInitNKuCun"),100000,m_szIniFileName);
	m_iGoodCardPercent = GetPrivateProfileInt(TEXT("GameOption"),TEXT("GoodCardPercent"),60,m_szIniFileName);
	if (m_iGoodCardPercent>100)
		m_iGoodCardPercent = 100;
	float Percent = 0.965f;
	if (m_LRoomAllUserNKuCun>0 && m_LRoomInitNKuCun>0)
	{
		Percent = (float)m_LRoomAllUserNKuCun/(float)m_LRoomInitNKuCun;
	}	
	if (Percent>0.98f)
	{
		m_AmendPercent = 35;
	}
	else if (Percent>0.975f)
	{
		m_AmendPercent = 20;
	}
	else if (Percent>0.972f)
	{
		m_AmendPercent = 10;
	}
	else if (Percent>=0.965f)
	{
		m_AmendPercent = 0;
	}
	else if (Percent>0.95f)
	{
		m_AmendPercent = -5;
	}
	else if (Percent>0.90f)
	{
		m_AmendPercent = -10;
	}
	else if (Percent>0.8f)
	{
		m_iGoodCardPercent=10;
		m_AmendPercent=0;
	}
	/*m_wBankerUser++;
	m_wBankerUser %=4;*/
	//m_wBankerUser=rand()%4;
	//还原出过牌用户
	ZeroMemory(m_bBeginOutCard,sizeof(m_bBeginOutCard));
	ZeroMemory(m_cbQueMen,sizeof(m_cbQueMen));
	ZeroMemory(m_lPiaoQiscore,sizeof(m_lPiaoQiscore));
	ZeroMemory(m_bPlayerNotHu,sizeof(m_bPlayerNotHu));
	ZeroMemory(m_lJiadiScore,sizeof(m_lJiadiScore));
	//自动托管
	ZeroMemory(m_bAutoStustee,sizeof(m_bAutoStustee));
	ZeroMemory(m_bPlayerOffLine,sizeof(m_bPlayerOffLine));
	ZeroMemory(m_bTrustee,sizeof(m_bTrustee));
	m_cbBaopai=0;
	m_cPlayHuCount = 0;
	m_cbfirstIndex = INVALID_CHAIR;
	m_cbscendIndex = INVALID_CHAIR;
	m_wNextBankerUser = INVALID_CHAIR;
	m_wLastOutcardUser = INVALID_CHAIR;
	m_wlastUser = INVALID_CHAIR;
	m_bFirstHuUser = true;
	//混乱扑克
	m_wSiceCount= rand()%6+1;//MAKEWORD(rand()%6+1,rand()%6+1);//MAKEWORD(4,1);//
	m_wSiceCount2 = rand()%6+1;
	m_bGoodCard = false;
	m_cbGameIsEnd = false;
	m_bIsGangKai = false;
	//int	m_wCount = rand()%100;
	//if (m_wCount<(m_iGoodCardPercent+m_AmendPercent))
	//{
	//	//判断是否存在AI
	//	bool b=false;
	//	for (int i=0;i<GAME_PLAYER;i++)
	//	{
	//		IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(i);
	//		ASSERT(pServerUserItem);
	//		b=pServerUserItem->IsAndroidUser();
	//		if (b)	break;
	//	}
	//	if (b)	m_bGoodCard = true;
	//}
	m_cbLeftCardCount=MAX_REPERTORY;
	//RandCardData(m_cbRepertoryCard);
	while (true)
	{
		RandCardData(m_cbRepertoryCard);
		str = "洗牌:";
		for (WORD i=0;i<MAX_REPERTORY;i++)
		{
			if ((i % 16) == 0) str += "\n";
			str.Format(str + "%s,", m_GameLogic.GetCardName(m_cbRepertoryCard[i]));
			//str.Format(str + "%02x_", m_cbRepertoryCard[i]);
		}
		CMylogFile::Instance().WriteLog(str,m_bServerTableID);
		//printf(str);
		//////////////////////////////////////////////////////////////////////////	校验扑克
		//printf("分发手牌给玩家。\n");
		BYTE byTmpInd[MAX_INDEX];	// 用户扑克
		m_GameLogic.SwitchToCardIndex(m_cbRepertoryCard, m_cbLeftCardCount, byTmpInd);
		int nTmpCnt = MAX_INDEX;
		while (nTmpCnt--)
		{
			if(nTmpCnt<9) break;
			if ((byTmpInd[nTmpCnt] + m_cbCardIndex[0][nTmpCnt] + m_cbCardIndex[1][nTmpCnt] + m_cbCardIndex[2][nTmpCnt] + m_cbCardIndex[3][nTmpCnt]) != 4)
			{
				ASSERT(false); break;
			}
		}
		if (nTmpCnt < 9) break;
		else ASSERT(false);
	}
	//printf("分发手牌给玩家结束;\n");
	m_bHasSendLastCard =false;
	m_bHasDingQue = false;
	m_cbTheLastSendCardData = 0;
	m_bHasChangCardend = false;
	m_bHasSendHuCard = false;
	m_bGangCount=0;
	m_cbGameHuCount = 0;
	m_cbGameEndCount = 0;
	m_cbHupaiCount = 0;
	ZeroMemory(m_cbHupaiIndex,sizeof(m_cbHupaiIndex));
	ZeroMemory(m_bUserGangCount,sizeof(m_bUserGangCount));
	ZeroMemory(m_bUserGenCount,sizeof(m_bUserGenCount));
	ZeroMemory(m_cbWeaveItemCount,sizeof(m_cbWeaveItemCount));
	ZeroMemory(m_bPlayerStatus,sizeof(m_bPlayerStatus));
	ZeroMemory(m_cPlaySequenceHu,sizeof(m_cPlaySequenceHu));
	ZeroMemory(m_GangCount,sizeof(m_GangCount));
	ZeroMemory(m_GangCountscore,sizeof(m_GangCountscore));
	ZeroMemory(m_GangWinscore,sizeof(m_GangWinscore));
	ZeroMemory(m_lGameScore,sizeof(m_lGameScore));
	//查花猪查大叫
	ZeroMemory(m_bChaHuazhu,sizeof(m_bChaHuazhu));
	ZeroMemory(m_bChaDajiao,sizeof(m_bChaDajiao));
	ZeroMemory(m_cbWinMax,sizeof(m_cbWinMax));

	m_bHaidiPao = false;
	m_bHaidilao = false;
	m_GameLogic.m_bHaidiPao = false;
	m_GameLogic.m_bHaidilao = false;

	m_baoTingstart = false;
	m_baoTingend = false;
	m_baoTingcount = 0;
	m_bhasbaoting =0; 

	for (int i=0;i<GAME_PLAYER;i++)
	{		
		m_bPlayerStatus[i]=true;	
		m_bTianDiHupai[i] = true; 
	}
	m_bTianHupai = true;
	m_bDiHupai = false;
	m_GameLogic.m_bTianHu = true;
	m_GameLogic.m_bDiHu = false;
	/*for (WORD i=0;i<m_wPlayerCount;i++)
		m_bTrustee[i]=true;*/
	getZhongPaiCardData();
	m_cbSendCardCount++;
	if (DEF_TEST)//DEF_TEST .
	{
		//test 修改将要发的牌  0x04,0x05,0x06,0x08,0x08,0x08,0x11,0x12,0x16,0x16,0x22,0x22,0x22,
		
		m_cbRepertoryCard[m_cbLeftCardCount-1] = 0x31;
		m_cbRepertoryCard[m_cbLeftCardCount-2] = 0x37;
		m_cbRepertoryCard[m_cbLeftCardCount-3] = 0x05;
		m_cbRepertoryCard[m_cbLeftCardCount-4] = 0x05;
		m_cbRepertoryCard[m_cbLeftCardCount-5] = 0x23;
		m_cbRepertoryCard[m_cbLeftCardCount-6] = 0x19;
		m_cbRepertoryCard[m_cbLeftCardCount-7] = 0x13;
		m_cbRepertoryCard[m_cbLeftCardCount-8] = 0x19;
		m_cbRepertoryCard[m_cbLeftCardCount-9] = 0x37;
		m_cbRepertoryCard[m_cbLeftCardCount-10] = 0x31;
		m_cbRepertoryCard[m_cbLeftCardCount-11] = 0x17;
		m_cbRepertoryCard[m_cbLeftCardCount-12] = 0x36;
		m_cbRepertoryCard[m_cbLeftCardCount-13] = 0x35;
		m_cbRepertoryCard[m_cbLeftCardCount-14] = 0x12;
		m_cbSendCardData=m_cbRepertoryCard[--m_cbLeftCardCount];

		m_cbRepertoryCard[0] = 0x19;
		m_cbRepertoryCard[1] = 0x13;
		m_cbRepertoryCard[2] = 0x19;
		m_cbRepertoryCard[3] = 0x37;
		m_cbRepertoryCard[4] = 0x31;
		m_cbRepertoryCard[5] = 0x17;
		m_cbRepertoryCard[6] = 0x36;
		m_cbRepertoryCard[7] = 0x35;
		m_cbRepertoryCard[8] = 0x12;
		m_cbRepertoryCard[9] = 0x12;
		m_cbRepertoryCard[10] = 0x13;
		m_cbRepertoryCard[11] = 0x31;
		m_cbRepertoryCard[12] = 0x31;
		m_cbRepertoryCard[13] = 0x31;
		m_cbRepertoryCard[14] = 0x31;

		//玩家的牌
		ZeroMemory(m_cbCardIndex,sizeof(m_cbCardIndex));
		int charID = m_wBankerUser;
		AddTestCard(charID, 0x32);
		AddTestCard(charID, 0x32);
		AddTestCard(charID, 0x32);
		AddTestCard(charID, 0x31);
		AddTestCard(charID, 0x06);
		AddTestCard(charID, 0x06);
		AddTestCard(charID, 0x06);
		AddTestCard(charID, 0x12);
		AddTestCard(charID, 0x13);
		AddTestCard(charID, 0x14);
		AddTestCard(charID, 0x15);
		AddTestCard(charID, 0x16);
		AddTestCard(charID, 0x17);

		charID =(charID+m_wPlayerCount-1)%m_wPlayerCount;
		AddTestCard(charID, 0x05);
		AddTestCard(charID, 0x06);
		AddTestCard(charID, 0x07);
		AddTestCard(charID, 0x11);
		AddTestCard(charID, 0x13);
		AddTestCard(charID, 0x16);
		AddTestCard(charID, 0x17);
		AddTestCard(charID, 0x24);
		AddTestCard(charID, 0x25);
		AddTestCard(charID, 0x26);
		AddTestCard(charID, 0x28);
		AddTestCard(charID, 0x29);
		AddTestCard(charID, 0x29);

		charID =(charID+m_wPlayerCount-1)%m_wPlayerCount;
		
		AddTestCard(charID, 0x01);
		AddTestCard(charID, 0x02);
		AddTestCard(charID, 0x07);
		AddTestCard(charID, 0x07);
		AddTestCard(charID, 0x15);
		AddTestCard(charID, 0x16);
		AddTestCard(charID, 0x16);
		AddTestCard(charID, 0x21);
		AddTestCard(charID, 0x22);
		AddTestCard(charID, 0x23);
		AddTestCard(charID, 0x26);
		AddTestCard(charID, 0x27);
		AddTestCard(charID, 0x28);
		charID =(charID+m_wPlayerCount-1)%m_wPlayerCount;
		
		AddTestCard(charID, 0x02);
		AddTestCard(charID, 0x03);
		AddTestCard(charID, 0x03);
		AddTestCard(charID, 0x05);
		AddTestCard(charID, 0x05);
		AddTestCard(charID, 0x11);
		AddTestCard(charID, 0x18);
		AddTestCard(charID, 0x22);
		AddTestCard(charID, 0x23);
		AddTestCard(charID, 0x24);
		AddTestCard(charID, 0x25);
		AddTestCard(charID, 0x34);
		AddTestCard(charID, 0x36);
	}
	else
	{
		m_cbSendCardData=m_cbRepertoryCard[--m_cbLeftCardCount];
	}

	//保存最后发的牌
	m_cbLastSendCardData = m_cbSendCardData;
	m_cbTheLastSendCardData  = m_cbSendCardData;
	m_cbProvideCard = m_cbSendCardData;
	m_cbCardIndex[m_wBankerUser][m_GameLogic.SwitchToCardIndex(m_cbSendCardData)]++;
	//
	////设置变量
	//m_cbProvideCard=0;
	//m_cbProvideCard=m_cbSendCardData;
	//m_wProvideUser=INVALID_CHAIR;

	m_wCurrentUser=m_wBankerUser;

	//动作分析
	bool bAroseAction=false;
	int k=0;
	CString strp,straction,strtmp;
	for (WORD i=0;i<m_wPlayerCount;i++)
	{
		//特殊胡牌
		//m_cbUserAction[i]|=m_GameLogic.EstimateChiHu(m_cbCardIndex[i]);

		//庄家判断
		if (i==m_wBankerUser)
		{
			strtmp.Format("庄家%d有%d个红中,可操作判断;\n",i,m_cbCardIndex[i][27]);
			//printf(strtmp);
			m_cbUserAction[i] |=m_GameLogic.EstimateChiHu(m_cbCardIndex[i],m_GameLogic.getZhongPaiIndex(m_tZhongPaiData.m_cbCurrentZhongPaiCardData,m_LaiZi));
			//首次出过牌用户标志
			//if (m_bBeginOutCard[i]==0)
			//{
			//	tagGangCardResult GangCardResult;
			//	m_cbUserAction[i]|=m_GameLogic.AnalyseFirstGangCard(m_cbCardIndex[i],
			//		m_WeaveItemArray[i],m_cbWeaveItemCount[i],GangCardResult,m_cbQueMen[i]);

			//	//寻找补杠
			//	//cbActionMask|=AnalyseZuHeSpeGangCard(cbCardIndex,WeaveItem,cbWeaveCount,GangCardResult
			//}
			//else
			{
				tagGangCardResult GangCardResult;
				m_cbUserAction[i]|=m_GameLogic.AnalyseGangCard(m_cbCardIndex[i],
					m_WeaveItemArray[i],m_cbWeaveItemCount[i],GangCardResult, m_cbQueMen[i],m_cbSendCardData);

			}
			//胡牌判断
			tagChiHuResult ChiHuResult;
			tagChiHuData tempData = getChiHuData();
			m_cbUserAction[i]|=m_GameLogic.AnalyseChiHuCard(m_cbCardIndex[i],NULL,0,0,0,ChiHuResult,m_cbQueMen[i],tempData);
			strtmp.Format("庄家%d可操作判断结束;\n",i);
			//printf(strtmp);
		}

		//状态设置
		if ((bAroseAction==false)&&(i!=m_wBankerUser)&&(m_cbUserAction[i]!=WIK_NULL))
		{
			bAroseAction=true;
			m_wResumeUser=m_wCurrentUser;
			m_wCurrentUser=INVALID_CHAIR;
		}
		straction = getCString(m_cbUserAction[i]);
		strtmp.Format("玩家%d有%d个红中,可操作:%s;\n",i,m_cbCardIndex[i][27],straction);
		strp = strp + strtmp;
	}
	strp = strp + "\n";
	//printf(strp);
	//钓鱼(彯起)
	/*m_bCanSelDiaoYu = true;
	m_pITableFrame->SetGameTimer(IDI_TIMER_XUAN_PIAOQI, 10000, 1, 0);
	CMD_S_PiaoQiStart piaoqiStart;
	piaoqiStart.wBankerUser = m_wBankerUser;
	CopyMemory(piaoqiStart.bPiaoqi,m_bPiaoQi,sizeof(piaoqiStart.bPiaoqi));
	m_pITableFrame->SendTableData(INVALID_CHAIR, SUB_S_START_PIAOQI, &piaoqiStart,sizeof(piaoqiStart));
	m_bLastFourCard = false;
	m_gamePassSecond = 0;*/
	if (DEF_TEST)
	{
		//test自动托管
		for (int i=0;i<GAME_PLAYER;i++)
		{
			IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(i);
			//if (pServerUserItem->IsAndroidUser() == true && m_wBankerUser != i)
			if (pServerUserItem->IsAndroidUser() == true)
			{
				m_bAutoStustee[i] = true;
			}
		}
	}

	//获取游戏开始时间(记录牌局)
	m_dwStartTime=time(NULL);
	m_pITableFrame->GetGameRecordID(m_dwStartTime, m_recordID);
	int nSeed = time(0);
	int AInum = 0;
	for (int i=0;i<GAME_PLAYER;i++)
	{
		IServerUserItem* pUserItem=m_pITableFrame->GetServerUserItem(i);
		if (NULL==pUserItem) continue;
		bool bAI=false;
		if (pUserItem->IsAndroidUser())
		{
			AInum++;
			bAI=true;
		}
		if (Percent<0.90f && bAI==false) //系统赢,控制玩家输赢
		{
			nSeed += 100;
			srand(nSeed);
			int itRand = rand() % 100 + 1;
			if (itRand <= (m_iGoodCardPercent+m_AmendPercent))
			{
				m_bNeedWin[i] = true;
			}
		}
		nSeed += 100;
		srand(nSeed);
		int iRand = rand() % 100 + 1;
		if (Percent>=0.972f )//玩家赢,控制AI及玩家输赢
		{
			
			if (iRand <= (m_iGoodCardPercent+m_AmendPercent+25))
			{
				if (bAI)
					m_bNeedWin[i] = true;
				else
					m_bNeedLost[i] = true;
			}
		}
		else if (Percent>=0.95f)
		{
			if(iRand < (m_iGoodCardPercent+m_AmendPercent)/2)
			{
				if (bAI)
					m_bNeedWin[i] = true;
				else
					m_bNeedLost[i] = true;
			}
		}
		
		_tcscat(m_tcAccount,pUserItem->GetAccounts());
		_tcscat(m_tcAccount,_TEXT(";"));
		//
		BYTE cbCardData[MAX_COUNT];
		m_GameLogic.SwitchToCardData(m_cbCardIndex[i],cbCardData);
		for (int j=0;j<MAX_COUNT-1;j++)
		{
			TCHAR tcHandCards[30];
			_stprintf(tcHandCards,"%02X",cbCardData[j]);
			_tcscat(m_tcOriginCards,tcHandCards);
		}
		if (i==m_wBankerUser)
		{
			TCHAR tcHandCards[30];
			_stprintf(tcHandCards,"%02X",cbCardData[MAX_COUNT-1]);
			_tcscat(m_tcOriginCards,tcHandCards);
		}
		_tcscat(m_tcOriginCards,_TEXT(";"));
	}
	//_stprintf(m_tcRecord,"%d,1,%02X;",m_wBankerUser,m_cbSendCardData);
	int randnum = rand()%100;
	if (AInum==0 || randnum < (100-m_iGoodCardPercent) )
	{
		ZeroMemory(m_bNeedWin, sizeof(m_bNeedWin));
		ZeroMemory(m_bNeedLost, sizeof(m_bNeedLost));
	}
	SendStartGameCard();
	m_cbHavePlayCount++;
	////测试
	//StartTableID = m_pITableFrame->GetTableID();
	//CString strFile,strTemp;
	//strFile.Format("log\\CurrentUser.log");
	//strTemp.Format("into StartTableID%2d ",StartTableID);
	//WriteLog(strFile, strTemp);
	return true;
}

void CTableFrameSink::SendStartGameCard()
{
	//构造数据
	CMD_S_GameStart GameStart;
	GameStart.wSiceCount=m_wSiceCount;
	GameStart.wSiceCount2 = m_wSiceCount2;
	GameStart.wBankerUser=m_wBankerUser;
	GameStart.wCurrentUser=m_wCurrentUser;
	GameStart.cbQuemen = m_cbQueMen[m_wCurrentUser];
	GameStart.cbZhongPaiCardData = m_tZhongPaiData.m_cbCurrentZhongPaiCardData;
	//发送数据
	m_bStartAinFinish = true;
	for (WORD i=0;i<m_wPlayerCount;i++)
	{
		//设置变量
		GameStart.cbUserAction=m_cbUserAction[i];
		m_GameLogic.SwitchToCardData(m_cbCardIndex[i],GameStart.cbCardData);
		//GameStart.bTrustee[i]=m_bTrustee[i];
		CopyMemory(GameStart.bTrustee,m_bTrustee,sizeof(m_bTrustee));

		//发送数据
		m_pITableFrame->SendTableData(i,SUB_S_GAME_START,&GameStart,sizeof(GameStart));
		m_pITableFrame->SendLookonData(i,SUB_S_GAME_START,&GameStart,sizeof(GameStart));

		IServerUserItem* pUserItem=m_pITableFrame->GetServerUserItem(i);
		if (pUserItem->IsAndroidUser() == false)
		{
			m_bStartAinFinish = false;
		}
	}

	memset(&m_opterPassTimeArr,PLAYER_TIMER_OPT_NULL,sizeof(m_opterPassTimeArr));
	if (m_wCurrentUser == INVALID_CHAIR)
	{
		ASSERT(NULL);
	}
	//m_opterPassTimeArr[m_wCurrentUser] = TIME_OPERATE_CARD_FIRST + 30;
	if (m_pGameServiceOption->wGameZoneType==em_zoneType_zhuangJin)
	{
		m_opterPassTimeArr[m_wCurrentUser] = TIME_OPERATE_CARD_ZIJIAN + 30;
	} 
	else
	{
		m_opterPassTimeArr[m_wCurrentUser] = TIME_OPERATE_CARD_FIRST + 30;
	}
	m_pITableFrame->SetGameTimer(IDI_TIMER_MAIN, 1000, -1, 0);

	if (m_bStartAinFinish == false)
	{
		m_pITableFrame->SetGameTimer(IDI_TIMER_START_ANI_FINISH, 10000, 1, 0);
	}
}


//游戏结束
bool __cdecl CTableFrameSink::OnEventGameEnd(WORD wChairID, IServerUserItem * pIServerUserItem, BYTE cbReason)
{
	m_pITableFrame->KillGameTimer(IDI_TIMER_MAIN);
	m_pITableFrame->KillGameTimer(IDI_TIMER_OPERATENOTIFY);
	m_pITableFrame->KillGameTimer(IDI_TIMER_SENDCARD);
	m_bGoodCard = false;
	for (WORD i=0;i<m_wPlayerCount;i++)
		m_bTrustee[i]=false;
	
	switch (cbReason)
	{
	case GER_NORMAL:		//常规结束
		{
			
			//变量定义
			CMD_S_GameEnd GameEnd;
			//CMD_S_Baopai sBaopai;
			ZeroMemory(&GameEnd,sizeof(GameEnd));
			bool LiuJu = false;
			m_cbGameIsEnd = true;
			//LONG	m_PlayerWinscore[GAME_PLAYER][GAME_PLAYER];//出现流局时各个玩家之间输赢的分数
			//ZeroMemory(&m_PlayerWinscore,sizeof(m_PlayerWinscore));
			//结束信息
			int winChairID = INVALID_CHAIR;
			int tmp_cbZhaMaCount = 0;
			ZeroMemory(m_cbZhaMaCardData,sizeof(m_cbZhaMaCardData));
			ZeroMemory(m_bZhongZhaMa,sizeof(m_bZhongZhaMa));
			ZeroMemory(m_zhongScore,sizeof(m_zhongScore));//
			ZeroMemory(m_FollowZhongScore,sizeof(m_FollowZhongScore));
			for (WORD i=0;i<GAME_PLAYER;i++)
			{	
				//if (m_bPlayerStatus[i]==false) continue;
				GameEnd.dwChiHuKind[i]=m_ChiHuResult[i].dwChiHuKind;
				GameEnd.dwChiHuRight[i]=m_ChiHuResult[i].dwChiHuRight;
				//m_bHupaiKindName[i] = GameEnd.dwChiHuKind[i];

				if (m_ChiHuResult[i].dwChiHuKind!=CHK_NULL)
				{
					winChairID = i;
					//m_cbCardIndex[winChairID][m_GameLogic.SwitchToCardIndex(m_cbProvideCard)]++;
					m_ZhongMaScore[i]=AddZhaMaData(m_cbCardIndex[i],i,GameEnd.cbPlayerZhongMa[i],m_MaShu == 1);
					m_AllHuTime[i]++;
					m_AllZhongMaCount[i] += m_cbZhaMaCount;
					GameEnd.cbPlayerZhongMaCoun[i] = m_cbZhaMaCount;
				}
				GameEnd.cbCardCount[i]=m_GameLogic.SwitchToCardData(m_cbCardIndex[i],GameEnd.cbCardData[i]);
				//GameEnd.m_bBaoting[i] = m_bEnjoinChiPeng[i];
				//GameEnd.m_bPiaoQi[i] = m_bPiaoQi[i];
			}
			////测试
			//CString strFile,strTemp;
			//strFile.Format("log\\CurrentUser.log");
			//strTemp.Format(" operateHupai %d table %d\n", winChairID, m_pITableFrame->GetTableID());
			//WriteLog(strFile,strTemp);
			//GameEnd.cbBaoCard=m_cbBaopai;
			//GameEnd.cbBaoCard=sBaopai.cbBaoCard;
			//GameEnd.winChairID = winChairID;
			//GameEnd.m_bHupaiCount = m_cbGameEndCount;
			//GameEnd.m_bGameIsEnd = m_cbGameIsEnd;
			//计算钓鱼	如果是放炮的话输分，自摸全赢
			//自摸
			//if (m_ChiHuResult[m_wProvideUser].dwChiHuKind!=CHK_NULL)
			//{

			//}
			//本局底注
			LONG cbdizhu = 0;
			for (int i=0;i<GAME_PLAYER;i++)
			{
				if (m_bPiaoQi[i])
				{
					cbdizhu += m_RoomBasicScore*2;
				}				
			}
			if (cbdizhu == 0)
			{
				cbdizhu = m_RoomBasicScore;
			}
			long cbPiaoQiscore[GAME_PLAYER];
			ZeroMemory(cbPiaoQiscore,sizeof(cbPiaoQiscore));
			//统计积分
			if (m_wProvideUser!=INVALID_CHAIR)
			{
				//胡牌
				//结束信息
				GameEnd.wProvideUser=m_wProvideUser;
				GameEnd.cbProvideCard=m_cbProvideCard;

				
				
				//自摸类型
				if (m_ChiHuResult[m_wProvideUser].dwChiHuKind!=CHK_NULL)
				{
					m_cbHuCardData[m_wProvideUser] = m_cbProvideCard;
					
					int gangHuTimes = 1;
					DWORD fanTimes = m_ChiHuResult[winChairID].dwWinTimes;
					//if ((m_ChiHuResult[winChairID].dwChiHuKind & CHK_GANG_KAI ) != 0 && (m_ChiHuResult[winChairID].dwChiHuKind & CHK_HAIDI_PAO ) && m_bIsLastGang)
					//{
					//	//DWORD fanTimes = m_ChiHuResult[winChairID].dwWinTimes;
					//	int fang = 1+m_ZhongMaScore[winChairID];					
					//	long times = fang*fanTimes*3*2;// pow(2.0, fang );输3份
					//	GameEnd.nHuScore[winChairID] +=  times;
					//	GameEnd.nHuScore[m_iRecordLastGangChairId] -=  times;

					//	m_HuScore[winChairID] +=  times;
					//	m_HuScore[m_iRecordLastGangChairId] -=  times;

					//	lGameScore[winChairID] = GameEnd.nHuScore[winChairID];
					//}
					//else
					//{

					//}
						for (WORD i=0;i<GAME_PLAYER;i++)
						{
							//赢家过滤
							if (m_ChiHuResult[i].dwChiHuKind!=CHK_NULL) continue;
							int fang = 1+m_ZhongMaScore[m_wProvideUser];					
							long times = 0;// pow(2.0, fang );
							times = fang*fanTimes;

							GameEnd.nHuScore[i] -=  times;
							GameEnd.nHuScore[m_wProvideUser] +=  times;
							lGameScore[m_wProvideUser] = GameEnd.nHuScore[m_wProvideUser];						
							m_HuScore[i] -=  times;
							m_HuScore[m_wProvideUser] +=  times;
						}

						// 种分
						BYTE zhonePaiIndex = m_GameLogic.getZhongPaiIndex(m_tZhongPaiData.m_cbCurrentZhongPaiCardData,m_LaiZi);
						if (zhonePaiIndex != INVALID_BYTE)
						{
							for (WORD i=0;i<GAME_PLAYER;i++)
							{
								for (int j = 0; j < GAME_PLAYER; j++)
								{
									if (i == j)
									{
										continue;
									}
									if (zhonePaiIndex >= MAX_INDEX)
									{
										assert(false && zhonePaiIndex >= MAX_INDEX);
										continue;
									}
									int zhongScore = m_cbCardIndex[i][zhonePaiIndex] - m_cbCardIndex[j][zhonePaiIndex];
									if(zhongScore > 0)
									{
										// 系数有1个或者2个种牌时，系数=1有3个种牌时，系数=2
										BYTE zhongScoreRatio = 1;
										if (zhongScore == 3)
										{
											zhongScoreRatio = 2;
										}
										m_zhongScore[i] += m_tZhongPaiData.m_cbZhonePaiCount*zhongScore*zhongScoreRatio;
										m_zhongScore[j] -= m_tZhongPaiData.m_cbZhonePaiCount*zhongScore*zhongScoreRatio;
										
									}
								}
							}
						}
						

						// 跟庄分
						if (m_nFollowBank)
						{
							for (WORD i=0;i<GAME_PLAYER;i++)
							{
								//赢家过滤
								if (m_wBankerUser == i) continue;
								m_FollowZhongScore[m_wBankerUser] -= m_wFollowBankCount;
								m_FollowZhongScore[i] += m_wFollowBankCount;
								//assert(false && 1111);
							}
							m_AllFollowCount[m_wBankerUser] += 1;
							GameEnd.cbFollowCount[m_wBankerUser] = m_wFollowBankCount;
							
						}


				}
				//捉炮类型
				if (m_ChiHuResult[m_wProvideUser].dwChiHuKind==CHK_NULL)
				{
					m_cbHuCardData[winChairID] = m_cbProvideCard;
					for (int i=0;i<GAME_PLAYER;i++)
					{
						if (m_ChiHuResult[i].dwChiHuKind ==CHK_NULL) continue;
						DWORD fanTimes = m_ChiHuResult[i].dwWinTimes;
						int fang = 1+m_ZhongMaScore[i];					
						long times = fang*fanTimes*2;// pow(2.0, fang );
						if ((m_ChiHuResult[i].dwChiHuKind & CHK_GANG_HU))
						{
							times = times * 3;
						}
						GameEnd.nHuScore[i] +=  times;
						GameEnd.nHuScore[m_wProvideUser] -=  times;

						m_HuScore[i] +=  times;
						m_HuScore[m_wProvideUser] -=  times;

						lGameScore[i] = GameEnd.nHuScore[i];

					}

				}
				
			}
			else
			{
				//流局结束
				GameEnd.wProvideUser = m_wProvideUser;
				GameEnd.cbProvideCard = m_cbProvideCard;
				LiuJu = true;				
			}
			//积分变量
			tagScoreInfo ScoreInfoArray[GAME_PLAYER];
			ZeroMemory(&ScoreInfoArray,sizeof(ScoreInfoArray));			
			
			//计算封顶
			//LONG topChangeScore = 0;		//与封顶的差值
			/*int jiaBei = 1;
			for (WORD i=0;i<GAME_PLAYER;i++)
			{
				if (m_bPiaoQi[i])
				{
					jiaBei *= 2;
				}
			}*/
			CString strScore,strScore2,strScoreTemp;
			for (WORD i=0;i<GAME_PLAYER;i++)
			{				
				if (LiuJu)
				{
					continue;
				}
				m_WinScore[i] = m_HuScore[i] + m_MingGangScore[i] + m_AnGangScore[i] + m_FanJieGangScore[i] + m_zhongScore[i] + m_FollowZhongScore[i];

				m_AllHuScore[i] += m_HuScore[i];
				m_AllMingGangScore[i] += m_MingGangScore[i];
				m_AllAnGangScore[i] += m_AnGangScore[i];
				m_AllFanJieGangScore[i] += m_FanJieGangScore[i];
				m_AllZhongMaScore[i] += m_ZhongMaScore[i];
				m_AllWinScore[i] += m_WinScore[i];

				GameEnd.nHuScore[i] += m_HuScore[i];
				GameEnd.nMingGangScore[i] += m_MingGangScore[i];
				GameEnd.nAnGangScore[i] += m_AnGangScore[i];
				GameEnd.nFanJieGangScore[i] += m_FanJieGangScore[i];
				GameEnd.nZhongMaScore[i] += m_ZhongMaScore[i];
				GameEnd.nWinScore[i] += m_WinScore[i];
				GameEnd.cbAllFollowCount[i] += m_AllFollowCount[i];
				strScoreTemp.Format("本局结算player%d:总计=%d,胡牌=%d,公杠=%d,暗杠=%d,放接杠=%d,中码=%d",i,m_WinScore[i],m_HuScore[i],m_MingGangScore[i],m_AnGangScore[i],m_FanJieGangScore[i],m_ZhongMaScore[i]);
				strScore +=strScoreTemp + "\n";

				strScoreTemp.Format("全部结算player%d:总计=%d,胡牌=%d,公杠=%d,暗杠=%d,放接杠=%d,中码=%d",i,m_AllWinScore[i],m_AllHuScore[i],m_AllMingGangScore[i],m_AllAnGangScore[i],m_AllFanJieGangScore[i],m_AllZhongMaScore[i]);
				strScore2 +=strScoreTemp + "\n";
			}
			printf(strScore+"\n"+strScore2);

			//统计积分
			
			for (WORD i=0;i<GAME_PLAYER;i++)
			{
				//任务
				//if (GameEnd.lGameScore[i]>0)
				//{
				//	//玩家获胜
				//	m_pITableFrame->GetServerUserItem(i)->SetMissionCardTypeVal(1);
				//}

				//float fRevenue = m_pGameServiceOption->dwBasicScore * m_pGameServiceOption->wRevenue/100.0L;
				//不用扣税
				//if(m_bPlayerStatus[i]==false) continue;
				float fRevenue = 0;
				LONG allScore = GameEnd.nHuScore[i];
				m_lGameScore[i] += GameEnd.nHuScore[i];
				
				allScore = m_lGameScore[i]; 
				if (allScore>0L /*&& 1==m_pGameServiceOption->wTaxSwitch*/)
				{
					//胜方
					WORD wRation = m_pGameServiceOption->wRevenue;//GetTaxRation(allScore, m_RoomBasicScore);
					fRevenue += allScore * wRation/100.0;
				}
				GameEnd.lGameTax[i] = ceil(fRevenue);
				
				//GameEnd.lGameTax[i] = 0;//不用扣税
			}
			CopyMemory(GameEnd.bZhongMa,m_bZhongZhaMa,sizeof(GameEnd.bZhongMa));
			CopyMemory(GameEnd.cbZaMaCarddata,m_cbZhaMaCardData,sizeof(GameEnd.cbZaMaCarddata));
			//统计剩余没出的牌
			BYTE leftCardCouont = m_cbLeftCardCount - tmp_cbZhaMaCount - 1;
			for (int i=leftCardCouont;i>=m_cbGetFinalyIndex;i--)
			{
				if (m_cbDisCount<60)
				{
					m_cbDisData[m_cbDisCount] = m_cbRepertoryCard[i];
					m_cbDisCount++;
				}
			}
			GameEnd.cbdiscount = m_cbDisCount;
			CopyMemory(GameEnd.cbDisCarddata,m_cbDisData,sizeof(GameEnd.cbDisCarddata));
			
			/*m_cbHavePlayCount++;*/
			if (m_pGameServiceOption->wGameZoneType==em_zoneType_zhuangJin)
			{
				if (m_cbHavePlayCount>=m_cbPlayJushu)	//玩的局数结束，需解散房间
				{
					CopyMemory(GameEnd.cbAllHuScore,m_AllHuTime,sizeof(GameEnd.cbAllHuScore));
					CopyMemory(GameEnd.cbAllMingGangScore,m_AllMingGangTime,sizeof(GameEnd.cbAllMingGangScore));
					CopyMemory(GameEnd.cbAllAnGangScore,m_AllAnGangTime,sizeof(GameEnd.cbAllAnGangScore));
					CopyMemory(GameEnd.cbAllFanGangScore,m_AllFanGangTime,sizeof(GameEnd.cbAllFanGangScore));
					CopyMemory(GameEnd.cbAllJieGangScore,m_AllJieGangTime,sizeof(GameEnd.cbAllJieGangScore));
					CopyMemory(GameEnd.cbAllZhongMaScore,m_AllZhongMaCount,sizeof(GameEnd.cbAllZhongMaScore));
					//CopyMemory(GameEnd.cbAllWinScore,m_AllWinScore,sizeof(GameEnd.cbAllWinScore));
					m_bGameOver=true;				
				}
			}			
			CopyMemory(GameEnd.cbAllWinScore,m_AllWinScore,sizeof(GameEnd.cbAllWinScore));
			GameEnd.bGameOver = m_bGameOver;
			
			int cbZhongIndex = m_GameLogic.getZhongPaiIndex(m_tZhongPaiData.m_cbCurrentZhongPaiCardData,m_LaiZi);
			//发送信息
			// 计算胡牌后的变牌后的数据
			for (int i = 0; i < GAME_PLAYER; i++)
			{
				if (GameEnd.dwChiHuKind[i] != CHK_NULL)
				{
					//胡牌判断
					BYTE cbWeaveItemCount=m_cbWeaveItemCount[i];
					tagWeaveItem * pWeaveItem=m_WeaveItemArray[i];
					tagChiHuData tempData = getChiHuData();
					
					BYTE tempWinUserCardData[MAX_INDEX];
					BYTE temp2[MAX_INDEX]={0};
					m_GameLogic.AnalyseChiHuCardAfterChangeCard(m_cbCardIndex[i],tempWinUserCardData,pWeaveItem,cbWeaveItemCount,GameEnd.dwChiHuKind[i],tempData);
					
					m_GameLogic.SwitchToCardData(tempWinUserCardData,GameEnd.cbWinUserChangeCardData[i]);
					
					for (int j = 0; j < MAX_INDEX; j++)
					{
						if (cbZhongIndex != INVALID_BYTE && j != cbZhongIndex && (m_cbCardIndex[i][j] - tempWinUserCardData[j]) != 0)
						{
							
							temp2[j] = abs( m_cbCardIndex[i][j] - tempWinUserCardData[j]);
						}
					}
					
					m_GameLogic.SwitchToCardData(temp2,GameEnd.cbHZChangeCardData[i]);
				}
			}
			m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_GAME_END,&GameEnd,sizeof(GameEnd));
			m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_GAME_END,&GameEnd,sizeof(GameEnd));
			//printf("游戏结束：发送SUB_S_GAME_END;\n");
			LONGLONG GameScore = 0;
			for (WORD i=0;i<GAME_PLAYER;i++)
			{
				ScoreInfoArray[i].lScore=GameEnd.nWinScore[i];
				ScoreInfoArray[i].lRevenue = GameEnd.lGameTax[i];
				ScoreInfoArray[i].lScore-=ScoreInfoArray[i].lRevenue;
				//ScoreInfoArray[i].lScore -= m_GangCountscore[i];
				GameScore += ScoreInfoArray[i].lScore;
				//end
				//设置胜负
				if (ScoreInfoArray[i].lScore==0L) ScoreInfoArray[i].ScoreKind=enScoreKind_Draw;
				else ScoreInfoArray[i].ScoreKind=(ScoreInfoArray[i].lScore>0L)?enScoreKind_Win:enScoreKind_Lost;
			}
			//if (m_wProvideUser!=INVALID_CHAIR)
			//{
			//	//庄家设置
			//	if (m_ChiHuResult[m_wBankerUser].dwChiHuKind==CHK_NULL) 
			//	{
			//		m_wBankerUser=(m_wBankerUser+1)%GAME_PLAYER;
			//	}
			//}
			if (LiuJu/*&&m_bFirstHuUser*/)
			{
				m_bFirstHuUser=false;
				m_wNextBankerUser = m_wlastUser;
			}
			else
			{
				m_wNextBankerUser = m_wProvideUser;
			}
			//setFollowBank(m_wNextBankerUser);
			m_wBankerUser = m_wNextBankerUser;
			m_wNextBankerUser = INVALID_CHAIR;
			m_cbBaopai=0;

			//记录牌局
			if (INVALID_CHAIR != winChairID)
			{
				TCHAR tcTemp[30];
				_stprintf(tcTemp,"%d,10,",winChairID);
				_tcscat(m_tcRecord,tcTemp);
				for (int j=0;j<MAX_COUNT;j++)
				{
					TCHAR tcHandCards[30];
					_stprintf(tcHandCards,"%02X",GameEnd.cbCardData[winChairID][j]);
					_tcscat(m_tcRecord,tcHandCards);
				}
				/*if (m_bEnjoinChiPeng[winChairID] && 0!= GameEnd.cbBaoCard)
				{
					TCHAR tcHandCards[30];
					_stprintf(tcHandCards,"%02X",GameEnd.cbBaoCard);
					_tcscat(m_tcRecord,tcHandCards);
				}*/
				_tcscat(m_tcRecord,";");
			}
			m_dwEndTime=time(NULL);
			TCHAR recordID[40] ={};
			m_pITableFrame->SaveGameRecord(m_dwStartTime,m_dwEndTime,m_tcAccount,m_tcOriginCards,m_tcRecord, m_recordID);
			//判断当局是否有AI玩
			bool bHasAI=false;
			for (int i=0;i<GAME_PLAYER;i++)
			{
				IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(i);
				ASSERT(pServerUserItem);
				if (pServerUserItem!=NULL)
				{
					bHasAI=pServerUserItem->IsAndroidUser();
				}
				if (bHasAI)	break;
			}
			//统计积分
			for (WORD i=0;i<GAME_PLAYER;i++)
			{
				IServerUserItem* pUserItem=m_pITableFrame->GetServerUserItem(i);
				if (NULL==pUserItem)	continue;
				//封顶处理
				/*if (ScoreInfoArray[i].lScore < -LtopScore && ScoreInfoArray[i].lScore < 0)
				{
					ScoreInfoArray[i].lScore=-LtopScore;
				}*/
				//写入积分
				if (m_pGameServiceOption->wGameZoneType==em_zoneType_zhuangJin)
				{
					m_pITableFrame->WriteUserScore(i,0,0,ScoreInfoArray[i].ScoreKind,0,enWSR_Normal,m_recordID,0,m_pGameServiceOption->wRevenue*10);
				} 
				else
				{
					m_pITableFrame->WriteUserScore(i,ScoreInfoArray[i].lScore,ScoreInfoArray[i].lRevenue,ScoreInfoArray[i].ScoreKind,0,enWSR_Normal,m_recordID,0,m_pGameServiceOption->wRevenue*10);
				}
				
				//统计真实玩家输赢积分
				if (pUserItem != NULL && bHasAI)
				{
					if (pUserItem->IsAndroidUser()==false)
					{
						m_LRoomAllUserNKuCun += ScoreInfoArray[i].lScore;
						m_LRoomInitNKuCun += ScoreInfoArray[i].lScore;
						TCHAR szBuffer2[MAX_PATH]={0};
						_sntprintf(szBuffer2,CountArray(szBuffer2), TEXT("%d"), m_LRoomAllUserNKuCun);
						LONG UserNKuCun = GetPrivateProfileInt(TEXT("GameOption"),TEXT("RoomAllUserNKuCun"),10,m_szIniFileName);
						if(m_LRoomAllUserNKuCun != UserNKuCun)
						{
							WritePrivateProfileString(TEXT("GameOption"), TEXT("RoomAllUserNKuCun"), szBuffer2, m_szIniFileName);

							_sntprintf(szBuffer2,CountArray(szBuffer2), TEXT("%d"), m_LRoomInitNKuCun);
							WritePrivateProfileString(TEXT("GameOption"), TEXT("RoomInitNKuCun"), szBuffer2, m_szIniFileName);
						}
					}
				}
			}
			CString str, strTemp;
			str.Format("[GameOver]游戏结束:ProvideUser=%s|ProvideCard=%d|m_wBankerUser=%d\n", GetPlayerName(GameEnd.wProvideUser).GetBuffer(0), GameEnd.cbProvideCard,m_wBankerUser);
			/*if (m_wBankerUser==INVALID_CHAIR)
			{
				m_wBankerUser = rand()%4;
				str.Format("[m_wBankerUser==INVALID_CHAIR]:m_wBankerUser=%d\n",m_wBankerUser);
			}*/
			for (int i = 0 ; i < m_wPlayerCount; i++)
			{
				CString str_piaoqi,str_baojiao;
				if (m_bPiaoQi[i]) str_piaoqi = "true";
				else str_piaoqi = "false";
				if (m_bEnjoinChiPeng[i]) str_baojiao = "true";
				else str_baojiao = "false";

				strTemp.Format("player:%s|lGameTax=%d|ChiHuKind=%d|ChiHuRight=%s,%d|GameScore=%d|cbCardCount=%d|GangUserCount=%d|lDiaoYuScore=%d|lGameScore_all=%d|m_bPiaoQi=%s|m_baojiao=%s", 
					GetPlayerName(i).GetBuffer(0), GameEnd.lGameTax[i], GameEnd.dwChiHuKind[i], m_GameLogic.GetHuPaiRightName(GameEnd.dwChiHuRight[i]).GetBuffer(0), GameEnd.dwChiHuRight[i],
					GameEnd.nHuScore[i], GameEnd.cbCardCount[i], GameEnd.nMingGangScore[i]+GameEnd.nAnGangScore[i]+GameEnd.nFanJieGangScore[i],
					0, GameEnd.nWinScore[i],str_piaoqi,str_baojiao);
				str += strTemp;
				for (int j = 0; j < MAX_COUNT; j++)
				{
					if (GameEnd.cbCardData[i][j] == 0)
					{
						continue;
					}
					strTemp.Format("%s,", m_GameLogic.GetCardName(GameEnd.cbCardData[i][j]).GetBuffer(0));
					str += strTemp;
				}
				str += "\n";
			}	
			//  TRACE(str);
			CMylogFile::Instance().WriteLog(str,m_bServerTableID);
			for (int i=0;i<GAME_PLAYER;i++)
			{
				if(m_bPlayerStatus[i]==true) //没胡玩家撤飘
				{
					m_bPiaoQi[i]=false;	
				}
			}
			//结束游戏
			//m_pITableFrame->ConcludeGame(1111);
			m_bGangCount=0;
			ZeroMemory(m_bUserGangCount,sizeof(m_bUserGangCount));
			CString strf;
			strf.Format("设定玩 %d 局，已经玩了 %d 局;",m_cbPlayJushu,m_cbHavePlayCount);
			//解散房间
			if (m_bGameOver && m_cbHavePlayCount>=m_cbPlayJushu && m_pGameServiceOption->wGameZoneType==em_zoneType_zhuangJin)
			{
				bool isFanHuanFangKa=false;
				if (m_cbHavePlayCount<=0)
				{
					isFanHuanFangKa=true;
				}
				m_cbHavePlayCount=0;
				//m_pITableFrame->ConcludeZiJian(isFanHuanFangKa);
				strf += "局数结束，需解散房间";
				m_RoomNum=0;
				m_MaShu = 0;
				m_cbPlayJushu = 0;
				m_cbHavePlayCount = 0;
				m_nOwnerUserID = INVALID_CHAIR;
				m_wBankerUser=INVALID_CHAIR;

				ZeroMemory(m_AllHuTime,sizeof(m_AllHuTime));
				ZeroMemory(m_AllMingGangTime,sizeof(m_AllMingGangTime));
				ZeroMemory(m_AllAnGangTime,sizeof(m_AllAnGangTime));
				ZeroMemory(m_AllFanGangTime,sizeof(m_AllFanGangTime));
				ZeroMemory(m_AllJieGangTime,sizeof(m_AllJieGangTime));
				ZeroMemory(m_AllZhongMaCount,sizeof(m_AllZhongMaCount));

				ZeroMemory(m_AllHuScore,sizeof(m_AllHuScore));
				ZeroMemory(m_AllMingGangScore,sizeof(m_AllMingGangScore));
				ZeroMemory(m_AllAnGangScore,sizeof(m_AllAnGangScore));
				ZeroMemory(m_AllFanJieGangScore,sizeof(m_AllFanJieGangScore));
				ZeroMemory(m_AllZhongMaScore,sizeof(m_AllZhongMaScore));
				ZeroMemory(m_AllWinScore,sizeof(m_AllWinScore));
				m_pITableFrame->ConcludeGame(1111);
			}
			else
			{
				m_pITableFrame->ConcludeGame();
			}
			strf += "\n";
			//printf(strf);
			//RepositTableFrameSink();
			return true;
		}
	case GER_DISMISS:		//游戏解散
		{
			////测试
			//EndTableID = m_pITableFrame->GetTableID();
			//CString strFile,strTemp;
			//strFile.Format("log\\CurrentUser.log");
			//strTemp.Format("into 游戏解散%2d ",EndTableID);
			//WriteLog(strFile, strTemp);
			//变量定义
			CMD_S_GameEnd GameEnd;
			ZeroMemory(&GameEnd,sizeof(GameEnd));

			//设置变量
			GameEnd.wProvideUser=INVALID_CHAIR;
			//GameEnd.cbBaoCard=m_cbBaopai;
			//拷贝扑克
			for (WORD i=0;i<GAME_PLAYER;i++)
			{
				GameEnd.cbCardCount[i]=m_GameLogic.SwitchToCardData(m_cbCardIndex[i],GameEnd.cbCardData[i]);
			}

			//发送信息
			m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_GAME_END,&GameEnd,sizeof(GameEnd));
			m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_GAME_END,&GameEnd,sizeof(GameEnd));

			//TCHAR tcTemp[30];
			//_stprintf(tcTemp,"%d,1;%d,1;%d,2;%d,2;",wChairID%m_wPlayerCount,
			//	(wChairID+2)%m_wPlayerCount, (wChairID+1)%m_wPlayerCount, (wChairID+3)%m_wPlayerCount);
			//_tcscat(m_tcRecord,tcTemp);

			//记录牌局
			m_dwEndTime=time(NULL);
			TCHAR recordID[40] ={};
			m_pITableFrame->SaveGameRecord(m_dwStartTime,m_dwEndTime,m_tcAccount,m_tcOriginCards,m_tcRecord, m_recordID);
			//结束游戏
			m_pITableFrame->ConcludeGame();
			m_bGangCount=0;
			ZeroMemory(m_bUserGangCount,sizeof(m_bUserGangCount));
			return true;
		}
	case GER_USER_LEFT:		//用户强退
		{
			////测试
			//EndTableID = m_pITableFrame->GetTableID();
			//CString strFile,strTemp;
			//strFile.Format("log\\CurrentUser.log");
			//strTemp.Format("into 用户强退%2d ",EndTableID);
			//WriteLog(strFile, strTemp);
			//变量定义
			CMD_S_GameEnd GameEnd;
			ZeroMemory(&GameEnd,sizeof(GameEnd));

			//设置变量
			GameEnd.wProvideUser=INVALID_CHAIR;
			//GameEnd.cbBaoCard=m_cbBaopai;
			//拷贝扑克
			for (WORD i=0;i<GAME_PLAYER;i++)
			{
				GameEnd.nMingGangScore[i] = m_GangCountscore[i];
				GameEnd.cbCardCount[i]=m_GameLogic.SwitchToCardData(m_cbCardIndex[i],GameEnd.cbCardData[i]);
			}

			//积分变量
			tagScoreInfo ScoreInfoArray[GAME_PLAYER];
			ZeroMemory(&ScoreInfoArray,sizeof(ScoreInfoArray));

			//统计积分
			for (WORD i=0;i<GAME_PLAYER;i++)
			{
				//设置积分
				if (i==wChairID)
				{
					ScoreInfoArray[i].ScoreKind=enScoreKind_Flee;
					GameEnd.nHuScore[i]=-4L*m_RoomBasicScore/*m_pGameServiceOption->dwBasicScore*/;
					ScoreInfoArray[i].lScore=-4L*m_RoomBasicScore/*m_pGameServiceOption->dwBasicScore*/;
				}
				else
				{
					GameEnd.nHuScore[i]=4L*m_RoomBasicScore/*m_pGameServiceOption->dwBasicScore*//3;
					if (GameEnd.nHuScore[i]+GameEnd.nMingGangScore[i]>0)
					{
						GameEnd.lGameTax[i]=(GameEnd.nHuScore[i]+GameEnd.nMingGangScore[i])*m_pGameServiceOption->wRevenue/100L;
					}

					ScoreInfoArray[i].lScore=4L*m_RoomBasicScore/*m_pGameServiceOption->dwBasicScore*//3+GameEnd.nMingGangScore[i]-GameEnd.lGameTax[i];
					ScoreInfoArray[i].ScoreKind=enScoreKind_Draw;
				}
			}

			//通知消息
			TCHAR szMessage[128]=TEXT("");
			_snprintf(szMessage,CountArray(szMessage),TEXT("由于 [ %s ] 离开游戏，游戏结束"),pIServerUserItem->GetAccounts());
			for (WORD i=0;i<m_wPlayerCount;i++)
			{
				IServerUserItem * pISendUserItem=m_pITableFrame->GetServerUserItem(i);
				if (pISendUserItem!=NULL) 
					m_pITableFrame->SendGameMessage(pISendUserItem,szMessage,SMT_INFO);
			}

			WORD wIndex=0;
			do
			{
				IServerUserItem * pISendUserItem=m_pITableFrame->EnumLookonUserItem(wIndex++);
				if (pISendUserItem==NULL)
					break;
				m_pITableFrame->SendGameMessage(pISendUserItem,szMessage,SMT_INFO);
			} while (true);


			//发送信息
			m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_GAME_END,&GameEnd,sizeof(GameEnd));
			m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_GAME_END,&GameEnd,sizeof(GameEnd));

			//TCHAR tcTemp[30];
			//_stprintf(tcTemp,"%d,1;%d,1;%d,2;%d,2;",wChairID%m_wPlayerCount,
			//	(wChairID+2)%m_wPlayerCount, (wChairID+1)%m_wPlayerCount, (wChairID+3)%m_wPlayerCount);
			//_tcscat(m_tcRecord,tcTemp);

			//记录牌局
			m_dwEndTime=time(NULL);
			TCHAR recordID[40] ={};
			m_pITableFrame->SaveGameRecord(m_dwStartTime,m_dwEndTime,m_tcAccount,m_tcOriginCards,m_tcRecord, m_recordID);
			//写入积分
			m_pITableFrame->WriteUserScore(wChairID,ScoreInfoArray[wChairID].lScore,0L,ScoreInfoArray[wChairID].ScoreKind,0,enWSR_Normal,m_recordID,0,m_pGameServiceOption->wRevenue*10);

			//结束游戏
			m_pITableFrame->ConcludeGame();
			m_bGangCount=0;
			ZeroMemory(m_bUserGangCount,sizeof(m_bUserGangCount));
			return true;
		}
	}
	//设置状态
	m_pITableFrame->SetGameStatus(GS_MJ_FREE);
	//错误断言
	ASSERT(FALSE);
	return false;
}
//玩家胡牌
bool CTableFrameSink::OnEventHupai(WORD wChairID, IServerUserItem * pIServerUserItem)
{	
	//变量定义
	CMD_S_HuPai HuPai;
	//CMD_S_Baopai sBaopai;
	ZeroMemory(&HuPai,sizeof(HuPai));
	//结束信息
	WORD winChairID = INVALID_CHAIR;
	for (WORD i=0;i<GAME_PLAYER;i++)
	{
		if (m_bPlayerStatus[i]==false) continue;
		HuPai.dwChiHuKind[i]=m_ChiHuResult[i].dwChiHuKind;				
		HuPai.dwChiHuRight[i]=m_ChiHuResult[i].dwChiHuRight;
		//HuPai.m_bBaoting[i] = m_bEnjoinChiPeng[i];
		m_bHupaiKindName[i] = HuPai.dwChiHuKind[i];
		if (m_ChiHuResult[i].dwChiHuKind!=CHK_NULL)
		{
			winChairID = i;
		}
		else
		{
			continue;
		}
		HuPai.cbCardCount[i]=m_GameLogic.SwitchToCardData(m_cbCardIndex[i],HuPai.cbCardData[i]);
		//m_cbCardIndex[winChairID][m_GameLogic.SwitchToCardIndex(m_cbProvideCard)]--;
	}
	//HuPai.cbBaoCard=m_cbBaopai;
	HuPai.winChairID = winChairID;
	HuPai.m_bHupaiCount = m_cbGameHuCount;
	HuPai.m_bGameIsEnd = m_cbGameIsEnd;
	HuPai.m_cbOperateOther = m_bOtherOperate;
	long cbPiaoQiscore[GAME_PLAYER];
	ZeroMemory(cbPiaoQiscore,sizeof(cbPiaoQiscore));
	//统计积分
	if (m_wProvideUser!=INVALID_CHAIR)
	{		
		//结束信息
		HuPai.wProvideUser=m_wProvideUser;
		HuPai.cbProvideCard=m_cbProvideCard;

		//自摸类型
		if (m_ChiHuResult[m_wProvideUser].dwChiHuKind!=CHK_NULL)
		{
			//TaskHuType(m_wProvideUser,m_ChiHuResult[m_wProvideUser].dwChiHuRight);
			m_bHupaiType[m_wProvideUser] = 0;
			HuPai.m_bHupaiType[m_wProvideUser] = 0;
			//HuPai.m_bHupaiZongfan[m_wProvideUser]= m_ChiHuResult[m_wProvideUser].dwWinTimes;
			//HuPai.m_bGangfan[m_wProvideUser] = m_bUserGangCount[m_wProvideUser];
			//HuPai.m_bGengfan[m_wProvideUser] = m_bUserGenCount[m_wProvideUser];
			m_cbHuCardData[m_wProvideUser] = m_cbProvideCard;
			m_bHupaiTypeRight[m_wProvideUser] = 0;
			//m_bHupaiZongfan[m_wProvideUser] = HuPai.m_bHupaiZongfan[m_wProvideUser];
			if (m_bFirstHuUser)
			{
				m_bFirstHuUser=false;
				m_wNextBankerUser = m_wProvideUser;
			}
			
			//循环累计
			for (WORD i=0;i<GAME_PLAYER;i++)
			{
				if (m_bPlayerStatus[i]==false)	continue;
				//赢家过滤
				if (m_ChiHuResult[i].dwChiHuKind!=CHK_NULL) continue;
				int fang = m_ChiHuResult[m_wProvideUser].dwWinTimes + m_bUserGangCount[m_wProvideUser]+m_bUserGenCount[winChairID];
				//if (m_bBeginOutCard[m_wProvideUser]!=0
				//{
				//	fang += 1;	//自摸加1
				//}						
				if ((m_ChiHuResult[m_wProvideUser].dwChiHuRight&CHK_GANG_KAI)!=WIK_NULL)
				{
					fang += 1;	//杠上花加1
					HuPai.m_bGangKai[m_wProvideUser] = 1;
					m_bGangKai[m_wProvideUser] = 1;
				}
				//海底捞加一番
				if (m_bHaidilao)
				{
					fang += 1;
					m_ChiHuResult[m_wProvideUser].dwChiHuKind |= CHK_HAIDI_LAO;
					HuPai.dwChiHuKind[m_wProvideUser]=m_ChiHuResult[m_wProvideUser].dwChiHuKind;
				}
				//报听加一番
				if (m_bEnjoinChiPeng[m_wProvideUser])
				{
					fang += 1;
				}
				if (fang>m_MahJongMultipleFan)
				{
					fang = m_MahJongMultipleFan;//番数超过封顶番数，按封顶番数计算
					//HuPai.m_MahJongMultipleFan[m_wProvideUser] = m_MahJongMultipleFan;
					m_bMahJongMultipleFan[m_wProvideUser] = m_MahJongMultipleFan;
				}
				/*else
				{
					HuPai.m_MahJongMultipleFan[m_wProvideUser] = 0;
				}*/
				long times = pow(2.0, fang );
				HuPai.lGameScore[i] -= m_RoomBasicScore * times;
				HuPai.lGameScore[m_wProvideUser]+=m_RoomBasicScore * times;
				lGameScore_other[i][m_wProvideUser] = HuPai.lGameScore[i];
				lGameScore[m_wProvideUser] = HuPai.lGameScore[m_wProvideUser];

				//自摸加底注
				long jiadi = m_RoomBasicScore;
				if (m_bPiaoQi[m_wProvideUser])
				{
					if (m_bPiaoQi[i])
						jiadi = m_RoomBasicScore*4;
					else
						jiadi = m_RoomBasicScore*2;
				}
				else
				{
					if (m_bPiaoQi[i])
						jiadi = m_RoomBasicScore*2;
				}
				/*HuPai.cbGangUserCount[i] -= jiadi;
				HuPai.cbGangUserCount[m_wProvideUser] += jiadi;	
				HuPai.m_cbJiadiScore[i] -= jiadi;
				HuPai.m_cbJiadiScore[m_wProvideUser] += jiadi;	*/
				//飘起加倍
				int jiaBei = 0;
				if (m_bPiaoQi[m_wProvideUser])
				{
					if (m_bPiaoQi[i])
						jiaBei = 3;
					else
						jiaBei = 1;
				}
				else
				{
					if (m_bPiaoQi[i])
						jiaBei = 1;
				}
				cbPiaoQiscore[i] -= m_RoomBasicScore * times * jiaBei;
				cbPiaoQiscore[m_wProvideUser] += m_RoomBasicScore * times * jiaBei;
			}
		}

		//捉炮类型
		if (m_ChiHuResult[m_wProvideUser].dwChiHuKind==CHK_NULL)
		{
			//计算放炮的玩家
			//放炮算分
			//放炮加一番
			if (m_bFirstHuUser)
			{
				m_bFirstHuUser=false;
				m_wNextBankerUser = winChairID;
			}
			int fang = m_ChiHuResult[winChairID].dwWinTimes+m_bUserGangCount[winChairID]+m_bUserGenCount[winChairID];
			//if ((m_ChiHuResult[winChairID].dwChiHuRight&CHK_GANG_HU)!=WIK_NULL)
			//{
			//	fang += 1;	//抢杠胡加1
			//	HuPai.m_bGangHu[winChairID] = 1;
			//	m_bGangHu[winChairID] = 1;
			//}
			//if ((m_ChiHuResult[winChairID].dwChiHuRight&CHK_GANG_PAO)!=WIK_NULL)
			//{
			//	fang += 1;	//杠上炮加1
			//	HuPai.m_bGangPao[winChairID] = 1;
			//	m_bGangPao[winChairID] = 1;
			//}
			////报听加一番
			//if (m_bEnjoinChiPeng[winChairID])
			//{
			//	fang += 1;
			//}
			////海底炮加一番					
			//if (m_bHaidiPao)
			//{
			//	fang += 1;
			//	m_ChiHuResult[winChairID].dwChiHuKind |= CHK_HAIDI_PAO;
			//	HuPai.dwChiHuKind[winChairID]=m_ChiHuResult[winChairID].dwChiHuKind;
			//}

			/*HuPai.m_bHupaiZongfan[winChairID]= m_ChiHuResult[winChairID].dwWinTimes;
			HuPai.m_bGangfan[winChairID] = m_bUserGangCount[winChairID];
			HuPai.m_bGengfan[winChairID] = m_bUserGenCount[winChairID];*/
			if (fang>m_MahJongMultipleFan)
			{
				fang = m_MahJongMultipleFan;//番数超过封顶番数，按封顶番数计算
				//HuPai.m_MahJongMultipleFan[m_wProvideUser] = m_MahJongMultipleFan;
				m_bMahJongMultipleFan[m_wProvideUser] = m_MahJongMultipleFan;
			}
			/*else
			{
				HuPai.m_MahJongMultipleFan[m_wProvideUser] = 0;
			}*/
			long times = pow(2.0, fang);
			HuPai.lGameScore[winChairID] += m_RoomBasicScore * times;
			HuPai.lGameScore[m_wProvideUser]-=m_RoomBasicScore * times;

			lGameScore_other[m_wProvideUser][winChairID] = HuPai.lGameScore[m_wProvideUser];

			//TaskHuType(winChairID,m_ChiHuResult[winChairID].dwChiHuRight);
			HuPai.m_bHupaiType[winChairID] = 1;
			m_cbHuCardData[winChairID] = m_cbProvideCard;
			m_bHupaiType[winChairID] = 1;
			m_bHupaiTypeRight[winChairID] = 1;
			//m_bHupaiZongfan[winChairID] = HuPai.m_bHupaiZongfan[winChairID];
			lGameScore[winChairID] = HuPai.lGameScore[winChairID];

			//飘起加倍
			int jiaBei = 0;
			if (m_bPiaoQi[winChairID])
			{
				if (m_bPiaoQi[m_wProvideUser])
					jiaBei = 3;
				else
					jiaBei = 1;
			}
			else
			{
				if (m_bPiaoQi[m_wProvideUser])
					jiaBei = 1;
			}
			cbPiaoQiscore[m_wProvideUser] -= m_RoomBasicScore * times * jiaBei;
			cbPiaoQiscore[winChairID] += m_RoomBasicScore * times * jiaBei;
		}		
	}
	//积分变量
	tagScoreInfo ScoreInfoArray[GAME_PLAYER];
	ZeroMemory(&ScoreInfoArray,sizeof(ScoreInfoArray));
	//杠庄家番倍
	//for (int i = 0; i < GAME_PLAYER; i++)
	//{
	//	if(m_bPlayerStatus[i]==false) continue;
	//	//if (i==winChairID)  continue;
	//	//HuPai.cbGangUserCount[i] = m_GangCountscore[i];
	//	lGameGangScore[i] += HuPai.cbGangUserCount[i];
	//}
	//计算封顶
	LONG topChangeScore = 0;		//与封顶的差值
	for (WORD i=0;i<GAME_PLAYER;i++)
	{	
		m_lPiaoQiscore[i] += cbPiaoQiscore[i];
		//m_lJiadiScore[i] += HuPai.m_cbJiadiScore[i];
		//HuPai.m_cbPiaoqiScore[i] += cbPiaoQiscore[i];		
		//HuPai.lGameScore_all[i] = HuPai.lGameScore[i] + HuPai.m_cbJiadiScore[i] + HuPai.m_cbPiaoqiScore[i];
		lGameScore_all[i] += HuPai.lGameScore_all[i];
	}
	for (WORD i=0;i<GAME_PLAYER;i++)
	{
		//if(m_bPlayerStatus[i]==false) continue;
		//任务
		//if (HuPai.lGameScore[i]>0)
		//{
		//	//玩家获胜
		//	m_pITableFrame->GetServerUserItem(wChairID)->SetMissionCardTypeVal(1);
		//}

		//float fRevenue = m_pGameServiceOption->dwBasicScore * m_pGameServiceOption->wRevenue/100.0L;
		//不用扣税
		if(m_bPlayerStatus[i]==false) continue;
		float fRevenue = 0;
		LONG allScore = HuPai.lGameScore_all[i];
		m_lGameScore[i] += HuPai.lGameScore_all[i] ;
		allScore = m_lGameScore[i];
		if (allScore>0L /*&& 1==m_pGameServiceOption->wTaxSwitch*/)
		{
			//胜方
			WORD wRation = m_pGameServiceOption->wRevenue;//GetTaxRation(allScore, m_RoomBasicScore);
			fRevenue += allScore * wRation/100.0;
		}
		HuPai.lGameTax[i] = ceil(fRevenue);

		//HuPai.lGameTax[i] = 0;//不用扣税
	}			
	
	m_cPlaySequenceHu[winChairID] = m_cPlayHuCount;
	//HuPai.m_cPlayHuSequence = m_cPlaySequenceHu[winChairID];
	//CopyMemory(GameEnd.cbGangUserCount,m_bUserGangCount,sizeof(GameEnd.cbGangUserCount));
	//发送信息
	m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_USER_HUPAI,&HuPai,sizeof(HuPai));
	m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_USER_HUPAI,&HuPai,sizeof(HuPai));
	for (WORD i=0;i<GAME_PLAYER;i++)
	{				
		ScoreInfoArray[i].lScore=HuPai.lGameScore_all[i];
		ScoreInfoArray[i].lRevenue = HuPai.lGameTax[i];
		ScoreInfoArray[i].lScore-=ScoreInfoArray[i].lRevenue;
		//ScoreInfoArray[i].lScore -= HuPai.cbGangUserCount[i];
		//end
		//设置胜负
		if (ScoreInfoArray[i].lScore==0L) ScoreInfoArray[i].ScoreKind=enScoreKind_Draw;
		else ScoreInfoArray[i].ScoreKind=(ScoreInfoArray[i].lScore>0L)?enScoreKind_Win:enScoreKind_Lost;
	}
	TCHAR recordID[40] ={};
	/*m_pITableFrame->SaveGameRecord(m_dwStartTime,m_dwEndTime,m_tcAccount,m_tcOriginCards,m_tcRecord, recordID);*/
	//判断当局是否有AI玩
	bool bHasAI=false;
	for (int i=0;i<GAME_PLAYER;i++)
	{
		IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(i);
		ASSERT(pServerUserItem);
		if (pServerUserItem!=NULL)
		{
			bHasAI=pServerUserItem->IsAndroidUser();
		}
		if (bHasAI)	break;
	}
	//统计积分
	for (WORD i=0;i<GAME_PLAYER;i++)
	{
		if(m_bPlayerStatus[i]==false) continue;
		IServerUserItem* pUserItem=m_pITableFrame->GetServerUserItem(i);
		if (NULL==pUserItem)	continue;
		////封顶处理
		//if (ScoreInfoArray[i].lScore < -LtopScore && ScoreInfoArray[i].lScore < 0)
		//{
		//	ScoreInfoArray[i].lScore=-LtopScore;
		//}
		//写入积分
		m_pITableFrame->WriteUserScore(i,ScoreInfoArray[i].lScore,ScoreInfoArray[i].lRevenue,ScoreInfoArray[i].ScoreKind,0,enWSR_Normal,m_recordID,0,m_pGameServiceOption->wRevenue*10);
		//统计真实玩家输赢积分
		if (pUserItem != NULL && bHasAI)
		{
			if (pUserItem->IsAndroidUser()==false)
			{
				m_LRoomAllUserNKuCun += ScoreInfoArray[i].lScore;
				m_LRoomInitNKuCun += ScoreInfoArray[i].lScore;
				TCHAR szBuffer2[MAX_PATH]={0};
				_sntprintf(szBuffer2,CountArray(szBuffer2), TEXT("%d"), m_LRoomAllUserNKuCun);
				LONG UserNKuCun = GetPrivateProfileInt(TEXT("GameOption"),TEXT("RoomAllUserNKuCun"),10,m_szIniFileName);
				if(m_LRoomAllUserNKuCun != UserNKuCun)
				{
					WritePrivateProfileString(TEXT("GameOption"), TEXT("RoomAllUserNKuCun"), szBuffer2, m_szIniFileName);

					_sntprintf(szBuffer2,CountArray(szBuffer2), TEXT("%d"), m_LRoomInitNKuCun);
					WritePrivateProfileString(TEXT("GameOption"), TEXT("RoomInitNKuCun"), szBuffer2, m_szIniFileName);
				}
			}
		}
	}
	m_bPlayerStatus[winChairID] = false;
	////结束游戏
	//m_pITableFrame->ConcludeGame();
	//m_bGangCount=0;
	//ZeroMemory(m_bUserGangCount,sizeof(m_bUserGangCount));
	//ZeroMemory(m_GangCount,sizeof(m_GangCount));
	ZeroMemory(m_GangCountscore,sizeof(m_GangCountscore));
	m_bHasSendHuCard = false;
	CString str, strTemp;
	str.Format("[GamePlayerHupai]第%d个胡牌:ProvideUser=%s|ProvideCard=%d|winChairID=%d\n",0, GetPlayerName(HuPai.wProvideUser).GetBuffer(0), HuPai.cbProvideCard,HuPai.winChairID);

	/*for (int i = 0 ; i < m_wPlayerCount; i++)
	{*/
		CString str_piaoqi,str_baojiao;
		if (m_bPiaoQi[winChairID]) str_piaoqi = "true";
		else str_piaoqi = "false";
		if (m_bEnjoinChiPeng[winChairID]) str_baojiao = "true";
		else str_baojiao = "false";

		strTemp.Format("player:%s|lGameTax=%d|ChiHuKind=%d|ChiHuRight=%s,%d|GameScore=%d|cbCardCount=%d|GangUserCount=%d|lDiaoYuScore=%d|lGameScore_all=%d|m_bPiaoQi=%s|m_baojiao=%s", 
			GetPlayerName(winChairID).GetBuffer(0), HuPai.lGameTax[winChairID], HuPai.dwChiHuKind[winChairID], m_GameLogic.GetHuPaiRightName(HuPai.dwChiHuRight[winChairID]).GetBuffer(0), HuPai.dwChiHuRight[winChairID],
			HuPai.lGameScore[winChairID], HuPai.cbCardCount[winChairID], 0,
			0, HuPai.lGameScore_all[winChairID],str_piaoqi,str_baojiao);
		str += strTemp;
		for (int j = 0; j < MAX_COUNT; j++)
		{
			if (HuPai.cbCardData[winChairID][j] == 0)
			{
				continue;
			}
			strTemp.Format("%s,", m_GameLogic.GetCardName(HuPai.cbCardData[winChairID][j]).GetBuffer(0));
			str += strTemp;
		}
		str += "\n";
	//}
	CMylogFile::Instance().WriteLog(str,m_bServerTableID);
	////测试
	//CString strFile,strTemp;
	//strFile.Format("log\\CurrentUser.log");
	//strTemp.Format(" operateHupai %d table %d\n", winChairID, m_pITableFrame->GetTableID());
	//WriteLog(strFile,strTemp);

	return true;		
		
}
//发送场景
bool __cdecl CTableFrameSink::SendGameScene(WORD wChiarID, IServerUserItem * pIServerUserItem, BYTE cbGameStatus, bool bSendSecret)
{
	switch (cbGameStatus)
	{
	case GS_MJ_FREE:	//空闲状态
		{
			//变量定义
			CMD_S_StatusFree StatusFree;
			memset(&StatusFree,0,sizeof(StatusFree));

			//构造数据
			StatusFree.wBankerUser=m_wBankerUser;
			StatusFree.lCellScore=m_RoomBasicScore/*m_pGameServiceOption->dwBasicScore*/;
			StatusFree.dwPermitScoreMoreLv = m_pGameServiceOption->dwPermitScoreMoreLv;
			CopyMemory(StatusFree.bTrustee,m_bTrustee,sizeof(m_bTrustee));
			CopyMemory(StatusFree.nWinScore,m_AllWinScore,sizeof(m_AllWinScore));
			if (m_pGameServiceOption->wGameZoneType != em_zoneType_zhuangJin) //游戏区类型
			{
				int randnum1 = rand()%90 + 10;
				int randnum2 = rand()%90 + 10;
				int randnum3 = rand()%10;
				if (m_RoomNum==0)
				{
					m_RoomNum = 1000*randnum1+10*randnum2+randnum3;	//房间号
				}
				if (m_MaShu==0)
				{
					m_MaShu = GetPrivateProfileInt(TEXT("GameOption"),TEXT("Mashu"),2,m_szIniFileName);
					m_cbZhaMaCount = m_MaShu;
				}
				if (m_cbPlayJushu==0)
				{
					m_cbPlayJushu = GetPrivateProfileInt(TEXT("GameOption"),TEXT("Jushu"),8,m_szIniFileName);
				}
			}
			
			StatusFree.nRoomNum = m_RoomNum;
			StatusFree.nMashu = m_MaShu;						//码数
			StatusFree.nLaiZi = m_LaiZi;						// 是否癞子
			StatusFree.nJushu = m_cbPlayJushu;					//设定玩的局数
			StatusFree.nHasPlayJushu = m_cbHavePlayCount;		//已经玩了的局数
			StatusFree.nOwnerChairID   = m_nOwnerUserID;		//房主的椅子号

			StatusFree.nHaiDiLaoYueTwo = m_nHaiDiLaoYueTwo;
			StatusFree.nDiHuTwo = m_nDiHuTwo;
			StatusFree.nFollowBank = m_nFollowBank;
			StatusFree.nZhonePai = m_nZhonePai;
			StatusFree.cbZhongPaiCardData = m_tZhongPaiData.m_cbCurrentZhongPaiCardData;
			//发送场景
			return m_pITableFrame->SendGameScene(pIServerUserItem,&StatusFree,sizeof(StatusFree));
		}
	case GS_MJ_PLAY:	//游戏状态
		{
			//变量定义
			CMD_S_StatusPlay StatusPlay;
			memset(&StatusPlay,0,sizeof(StatusPlay));
			/*for (WORD i=0;i<m_wPlayerCount;i++)
				m_bTrustee[i]=true;*/

			//游戏变量
			StatusPlay.wSiceCount=m_wSiceCount;
			StatusPlay.wBankerUser=m_wBankerUser;
			StatusPlay.wCurrentUser=m_wCurrentUser;
			StatusPlay.lCellScore=m_RoomBasicScore/*m_pGameServiceOption->dwBasicScore*/;
			//StatusPlay.dwPermitScoreMoreLv = m_pGameServiceOption->dwPermitScoreMoreLv;
			//StatusPlay.islookBaopai = m_islookBaopai;
			CopyMemory(StatusPlay.bTrustee,m_bTrustee,sizeof(m_bTrustee));
			CopyMemory(StatusPlay.nWinScore,m_AllWinScore,sizeof(m_AllWinScore));
			//CopyMemory(StatusPlay.m_cbBaoting,m_bEnjoinChiPeng,sizeof(m_bEnjoinChiPeng));
			/*CopyMemory(StatusPlay.m_cbPiaoqi,m_bPiaoQi,sizeof(m_bPiaoQi));
			CopyMemory(StatusPlay.m_cbPiaoqiScore,m_lPiaoQiscore,sizeof(m_lPiaoQiscore));
			CopyMemory(StatusPlay.m_cbJiadiScore,m_lJiadiScore,sizeof(m_lJiadiScore));
			StatusPlay.cbBaopai = 0;*/
			//m_bFirstLookBao
			/*if (m_bEnjoinChiPeng[wChiarID] == true && m_bFirstLookBao[wChiarID] == false)
			{
				StatusPlay.cbBaopai=m_cbBaopai;
			}*/
			//if (!m_bHasDingQue)//选择确定缺门是否已结束
			//{
			//	m_bHasDingQue = true;
			//	CMD_S_PiaoQi pPiaoQi;
			//	bool b = false;
			//	for (int i = 0; i < GAME_PLAYER; i++)
			//	{
			//		if (m_bPiaoQiHasSel[i] == false)
			//		{
			//			m_bPiaoQiHasSel[i] = true;
			//			pPiaoQi.wChiarID = i;
			//			pPiaoQi.wSelType = 0;//m_GameLogic.GetMinQuemenType(m_cbCardIndex[i]);
			//			m_cbQueMen[i] = pPiaoQi.wSelType;
			//			pPiaoQi.wSelType+=10;
			//			IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(i);
			//			ASSERT(pServerUserItem);
			//			if (pServerUserItem!=NULL)
			//			{
			//				b=pServerUserItem->IsAndroidUser();
			//			}
			//			if (!b)	continue;										
			//			m_pITableFrame->SendTableData(i,SUB_S_PIAOQI,&pPiaoQi,sizeof(pPiaoQi));
			//			m_pITableFrame->SendLookonData(i,SUB_S_PIAOQI,&pPiaoQi,sizeof(pPiaoQi));
			//		}
			//	}
			//}
			//if (!m_bHasSendLastCard)//如果没发到最后一张牌
			//{
			//	m_bHasSendLastCard = true;
			//	if (m_bBeginOutCard[m_wBankerUser]==0)
			//	{
			//		DispatchLastCardData();
			//	} 
			//	else
			//	{
			//		IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(m_wBankerUser);
			//		ASSERT(pServerUserItem);
			//		bool AI = false;
			//		if (pServerUserItem!=NULL)
			//		{
			//			AI=pServerUserItem->IsAndroidUser();
			//		}
			//		if (AI)
			//		{
			//			//保存最后发的牌
			//			m_cbCardIndex[m_wBankerUser][m_GameLogic.SwitchToCardIndex(m_cbTheLastSendCardData)]++;
			//			//构造数据
			//			CMD_S_GameLastCard GameStartLastCard;
			//			GameStartLastCard.wCurrentUser=m_wCurrentUser;
			//			//设置变量
			//			GameStartLastCard.cbUserAction=m_cbUserAction[m_wBankerUser];
			//			GameStartLastCard.cbCardData = m_cbTheLastSendCardData;
			//			//发送数据
			//			m_pITableFrame->SendTableData(m_wBankerUser,SUB_S_GAME_SEND_LASTCARD,&GameStartLastCard,sizeof(GameStartLastCard));
			//		}
			//		else
			//		{
			//			m_cbCardIndex[m_wBankerUser][m_GameLogic.SwitchToCardIndex(m_cbTheLastSendCardData)]++;
			//		}
			//		
			//	}				
			//}
			//状态变量
			StatusPlay.cbActionCard=m_cbProvideCard;
			StatusPlay.cbLeftCardCount = m_cbLeftCardCount-m_bGangCount;
			StatusPlay.cbActionMask=(m_bResponse[wChiarID]==false)?m_cbUserAction[wChiarID]:WIK_NULL;

			//听牌状态
			//for (WORD i=0;i<m_wPlayerCount;i++)
			//{
			//	//StatusPlay.cbHearStatus[i]=m_bEnjoinChiPeng[i];
			//	//StatusPlay.iDiaoYuTimes[i]=m_lDiaoYuTimes[i];
			//}
			

			//历史记录
			StatusPlay.wOutCardUser=m_wOutCardUser;
			StatusPlay.cbOutCardData=m_cbOutCardData;
			CopyMemory(StatusPlay.cbDiscardCard,m_cbDiscardCard,sizeof(StatusPlay.cbDiscardCard));
			CopyMemory(StatusPlay.cbDiscardCount,m_cbDiscardCount,sizeof(StatusPlay.cbDiscardCount));

			//组合扑克
			CopyMemory(StatusPlay.WeaveItemArray,m_WeaveItemArray,sizeof(StatusPlay.WeaveItemArray));
			CopyMemory(StatusPlay.cbWeaveCount,m_cbWeaveItemCount,sizeof(StatusPlay.cbWeaveCount));
			SYSTEMTIME time;			
			for(int i=0;i<GAME_PLAYER;i++)
			{
				if(i != wChiarID) continue;
				if(i==m_wCurrentUser) continue;
				/*GetLocalTime(&time);
				printf("胡牌判断前：%02d-%02d-%02d %02d:%02d:%02d.%03d \n",time.wYear,time.wMonth,time.wDay,time.wHour,time.wMinute,time.wSecond,time.wMilliseconds);
				SetChaTingCard(i,false);
				GetLocalTime(&time);
				printf("胡牌判断后：%02d-%02d-%02d %02d:%02d:%02d.%03d \n",time.wYear,time.wMonth,time.wDay,time.wHour,time.wMinute,time.wSecond,time.wMilliseconds);*/
				//SetChaTingCard(i,false);
				if (m_cbChaTing)
				{		
					//发送消息	
					for (int j=0;j<MAX_INDEX;j++)
					{
						if (m_ChaTingCardArray.cbCardData[0][j]==0) break;
						StatusPlay.listenCarddata[j] = m_ChaTingCardArray.cbCardData[0][j];
					}		
				}
			}
			StatusPlay.nRoomNum = m_RoomNum;//m_pITableFrame->GetZiJianID();
			StatusPlay.nMashu = m_MaShu;
			StatusPlay.nJushu = m_cbPlayJushu;					//设定玩的局数
			StatusPlay.nLaiZi = m_LaiZi;
			StatusPlay.nHasPlayJushu = m_cbHavePlayCount;			//已经玩的局数
			StatusPlay.nHaiDiLaoYueTwo = m_nHaiDiLaoYueTwo;
			StatusPlay.nDiHuTwo = m_nDiHuTwo;
			StatusPlay.nFollowBank = m_nFollowBank;
			StatusPlay.nZhonePai = m_nZhonePai;
			StatusPlay.cbZhongPaiCardData = m_tZhongPaiData.m_cbCurrentZhongPaiCardData;
			//CopyMemory(StatusPlay.m_bQuemen,m_cbQueMen,sizeof(StatusPlay.m_bQuemen));
			//扑克数据
			StatusPlay.cbCardCount=m_GameLogic.SwitchToCardData(m_cbCardIndex[wChiarID],StatusPlay.cbCardData);
			StatusPlay.cbSendCardData=((m_cbSendCardData!=0)&&(m_wProvideUser==wChiarID))?m_cbSendCardData:0x00;
			StatusPlay.nOwnerChairID   = m_nOwnerUserID;		//房主的椅子号
			//胡牌状态
			//CopyMemory(StatusPlay.m_bPlayerStatus,m_bPlayerStatus,sizeof(StatusPlay.m_bPlayerStatus));
			//CopyMemory(StatusPlay.m_cbHuCardData,m_cbHuCardData,sizeof(StatusPlay.m_cbHuCardData));
			//CopyMemory(StatusPlay.m_bHupaiType,m_bHupaiType,sizeof(StatusPlay.m_bHupaiType));
			//CopyMemory(StatusPlay.m_cPlaySequenceHu,m_cPlaySequenceHu,sizeof(StatusPlay.m_cPlaySequenceHu));

			//CopyMemory(StatusPlay.lGameScore_all,lGameScore_all,sizeof(StatusPlay.lGameScore_all));
			//CopyMemory(StatusPlay.lGameScore,lGameScore,sizeof(StatusPlay.lGameScore));
			//CopyMemory(StatusPlay.lGameScore_other,lGameScore_other,sizeof(StatusPlay.lGameScore_other));
			//CopyMemory(StatusPlay.m_bHupaiTypeRight,m_bHupaiTypeRight,sizeof(StatusPlay.m_bHupaiTypeRight));
			//CopyMemory(StatusPlay.m_bHupaiKindName,m_bHupaiKindName,sizeof(StatusPlay.m_bHupaiKindName));
			//CopyMemory(StatusPlay.dwChiHuRight,dwChiHuRight,sizeof(StatusPlay.dwChiHuRight));
			//CopyMemory(StatusPlay.m_bHupaiZongfan,m_bHupaiZongfan,sizeof(StatusPlay.m_bHupaiZongfan));

			//CopyMemory(StatusPlay.lGameGangScore,lGameGangScore,sizeof(StatusPlay.lGameGangScore));//刮风下分数
			//CopyMemory(StatusPlay.m_bGangfan,m_bUserGangCount,sizeof(StatusPlay.m_bGangfan));//杠番
			//CopyMemory(StatusPlay.m_bGengfan,m_bUserGenCount,sizeof(StatusPlay.m_bGengfan));//根番
			//CopyMemory(StatusPlay.m_bGangKai,m_bGangKai,sizeof(StatusPlay.m_bGangKai));//杠上花
			////CopyMemory(StatusPlay.m_bGangPao,m_bGangPao,sizeof(StatusPlay.m_bGangPao));//杠上炮
			//CopyMemory(StatusPlay.m_bGangHu,m_bGangHu,sizeof(StatusPlay.m_bGangHu));//枪杠胡
			//CopyMemory(StatusPlay.m_MahJongMultipleFan,m_bMahJongMultipleFan,sizeof(StatusPlay.m_MahJongMultipleFan));//封顶番数
					
			//for (int i=0;i<GAME_PLAYER;i++)
			//{
			//	//if(wChiarID==i) continue;
			//	if (m_bPlayerStatus[i]==false)
			//	{
			//		StatusPlay.m_cbHasHuCardCount[i]=m_GameLogic.SwitchToCardData(m_cbCardIndex[i],StatusPlay.m_cbHasHuCardData[i]);
			//	}
			//}
			
			//发送场景
			return m_pITableFrame->SendGameScene(pIServerUserItem,&StatusPlay,sizeof(StatusPlay));
		}
	}

	return false;
}

//定时器事件
bool __cdecl CTableFrameSink::OnTimerMessage(WORD wTimerID, WPARAM wBindParam)
{
	//操作定时器
	if (wTimerID == IDI_TIMER_MAIN)
	{
		return true;
		m_gamePassSecond++;
		//出牌
		for (WORD i=0;i<m_wPlayerCount;i++)
		{
			if (m_opterPassTimeArr[i] != PLAYER_TIMER_OPT_NULL)
			{
				m_opterPassTimeArr[i]--;
				//时间到了
				if (m_opterPassTimeArr[i] == 0)
				{
					//控制牌(而且不是首杠)
					//if ((m_cbUserAction[i]&WIK_SHOU_GANG)==0)
					//{
					//	int i = 0;
					//}
					//if (m_cbUserAction[i] != WIK_NULL && (m_cbUserAction[i]&WIK_SHOU_GANG)==0)
					//if (!m_bHasDingQue)//选择确定缺门是否已结束
					//{
					//	m_bHasDingQue = true;
					//	CMD_S_PiaoQi pPiaoQi;
					//	bool b = false;
					//	for (int i = 0; i < GAME_PLAYER; i++)
					//	{
					//		if (m_bPiaoQiHasSel[i] == false)
					//		{
					//			m_bPiaoQiHasSel[i] = true;
					//			pPiaoQi.wChiarID = i;
					//			pPiaoQi.wSelType = 0;//m_GameLogic.GetMinQuemenType(m_cbCardIndex[i]);
					//			m_cbQueMen[i] = pPiaoQi.wSelType;
					//			pPiaoQi.wSelType+=10;
					//			IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(i);
					//			ASSERT(pServerUserItem);
					//			if (pServerUserItem!=NULL)
					//			{
					//				b=pServerUserItem->IsAndroidUser();
					//			}
					//			if (!b)	continue;										
					//			m_pITableFrame->SendTableData(i,SUB_S_PIAOQI,&pPiaoQi,sizeof(pPiaoQi));
					//			m_pITableFrame->SendLookonData(i,SUB_S_PIAOQI,&pPiaoQi,sizeof(pPiaoQi));
					//		}
					//	}
					//}
					//if (!m_bHasSendLastCard)//如果没发到最后一张牌
					//{
					//	m_bHasSendLastCard = true;
					//	if (m_bBeginOutCard[m_wBankerUser]==0)
					//	{
					//		DispatchLastCardData();
					//	} 
					//	else
					//	{
					//		IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(m_wBankerUser);
					//		ASSERT(pServerUserItem);
					//		bool AI = false;
					//		if (pServerUserItem!=NULL)
					//		{
					//			AI=pServerUserItem->IsAndroidUser();
					//		}
					//		if (AI)
					//		{
					//			//保存最后发的牌
					//			m_cbCardIndex[m_wBankerUser][m_GameLogic.SwitchToCardIndex(m_cbTheLastSendCardData)]++;
					//			//构造数据
					//			CMD_S_GameLastCard GameStartLastCard;
					//			GameStartLastCard.wCurrentUser=m_wCurrentUser;
					//			//设置变量
					//			GameStartLastCard.cbUserAction=m_cbUserAction[m_wBankerUser];
					//			GameStartLastCard.cbCardData = m_cbTheLastSendCardData;
					//			//发送数据
					//			m_pITableFrame->SendTableData(m_wBankerUser,SUB_S_GAME_SEND_LASTCARD,&GameStartLastCard,sizeof(GameStartLastCard));
					//		}
					//		else
					//		{
					//			m_cbCardIndex[m_wBankerUser][m_GameLogic.SwitchToCardIndex(m_cbTheLastSendCardData)]++;
					//		}

					//	}				
					//}
					//取消真实玩家自动出牌
					IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(i);
					ASSERT(pServerUserItem);
					bool bAI = false;
					if (pServerUserItem!=NULL)
					{
						bAI=pServerUserItem->IsAndroidUser();
					}
					//if (bAI==false)
					//{
					//	m_opterPassTimeArr[i] = PLAYER_TIMER_OPT_NULL;
					//	//printf("---系统托管，取消真实玩家自动出牌----\n");
					//	return true;
					//}
					//printf("---系统托管，定时操作----\n");
					if (m_cbUserAction[i] != WIK_NULL && m_wCurrentUser != i)
					{
						OnUserOperateCard(i, WIK_NULL, 0);
						break;
					}
					//自动托管
					if (m_opterPassTimeArr[i] == 0)
					{
						if (m_wCurrentUser == i)
						{
							//先判断有没有这张牌
							BYTE removeCardData = m_cbLastSendCardData;
							BYTE cbRemoveIndex=m_GameLogic.SwitchToCardIndex(removeCardData);
							for (BYTE k=0;k<(MAX_INDEX-1);k++)
							{
								if (m_cbCardIndex[i][k]==0) continue;
								removeCardData = m_GameLogic.SwitchToCardData(k);
								cbRemoveIndex = k;
								break;
							}
							//switch(m_cbQueMen[m_wCurrentUser])
							//{
							//case 0://万子
							//	if (cbRemoveIndex>8)
							//	{
							//		for (BYTE k=0;k<MAX_INDEX;k++)
							//		{
							//			if(k>8) continue;
							//			if (m_cbCardIndex[i][k]==0) continue;
							//			removeCardData = m_GameLogic.SwitchToCardData(k);
							//			break;
							//		}
							//	}
							//	break;
							//case 1://条子
							//	if (cbRemoveIndex<9||cbRemoveIndex>17)
							//	{
							//		for (BYTE k=0;k<MAX_INDEX;k++)
							//		{
							//			if(k<9||k>17) continue;
							//			if (m_cbCardIndex[i][k]==0) continue;
							//			removeCardData = m_GameLogic.SwitchToCardData(k);
							//			break;
							//		}
							//	}
							//	break;
							//case 2://筒子
							//	if (cbRemoveIndex<18)
							//	{
							//		for (BYTE k=0;k<MAX_INDEX;k++)
							//		{
							//			if(k<18) continue;
							//			if (m_cbCardIndex[i][k]==0) continue;
							//			removeCardData = m_GameLogic.SwitchToCardData(k);
							//			break;
							//		}
							//	}
							//	break;
							//}
							if (m_cbCardIndex[i][cbRemoveIndex]<=0)//没有这张牌就换一张牌打
							{
								for (BYTE j=0;j<(MAX_INDEX-1);j++)
								{
									////出牌效验
									if (m_cbCardIndex[i][j]==0) continue;
									removeCardData = m_GameLogic.SwitchToCardData(j);
									break;
								}
							}
							CMylogFile::Instance().WriteLogFmt(m_bServerTableID,"player:%s Time out out card", GetPlayerName(m_wCurrentUser));
							OnUserOutCard(m_wCurrentUser, removeCardData);
							m_opterPassTimeArr[i] = PLAYER_TIMER_OPT_NULL;
						}
					}
				}
			}
		}

		
		return true;
	}
	//else if (wTimerID == IDI_TIMER_OPERATENOTIFY)
	//{
	//	SendOperateNotify();
	//}
	//else if (wTimerID == IDI_TIMER_SENDCARD)
	//{
	//	SendCard();
	//}
	//else if (wTimerID == IDI_TIMER_XUAN_PIAOQI)
	//{
	//	if (m_bCanSelQuemen == false)
	//	{
	//		return true;
	//	}
	//	CMD_S_PiaoQi pPiaoQi;
	//	for (int i = 0; i < GAME_PLAYER; i++)
	//	{
	//		if (m_bPiaoQiHasSel[i] == false)
	//		{
	//			m_bPiaoQiHasSel[i] = true;				
	//			pPiaoQi.wChiarID = i;
	//			pPiaoQi.wSelType = 0;//m_GameLogic.GetMinQuemenType(m_cbCardIndex[i]);
	//			m_cbQueMen[i] = pPiaoQi.wSelType;				
	//			m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_PIAOQI,&pPiaoQi,sizeof(pPiaoQi));
	//			m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_PIAOQI,&pPiaoQi,sizeof(pPiaoQi));
	//		}
	//	}
	//	//选择缺门结束
	//	m_bHasDingQue = true;
	//	m_pITableFrame->KillGameTimer(IDI_TIMER_XUAN_PIAOQI);
	//	m_pITableFrame->SetGameTimer(IDI_TIMER_BAOTING, 10000, 1, 0);
	//	/*m_pITableFrame->SetGameTimer(IDI_TIMER_CHANG_CARD, 10000, 1, 0);
	//	m_pITableFrame->SendTableData(INVALID_CHAIR, SUB_S_START_CHANGCARD, 0,0);*/
	//}
	//else if (wTimerID == IDI_TIMER_CHANG_CARD)
	//{
	//	if (m_bCanSelChangCard == false)
	//	{
	//		return true;
	//	}
	//	CMD_S_ChangCard Changcard; 
	//	for (int i = 0; i < GAME_PLAYER; i++)
	//	{
	//		if (m_bChangCardHasSel[i] == false)
	//		{
	//			m_bChangCardHasSel[i] = true;
	//			m_bChangCardCount[i] = 0;
	//			m_bChangCard[i] = false;
	//			for (int j=0;j<3;j++)
	//			{
	//				m_bChangCardDate[i][j] = 0;
	//				Changcard.cbCardData[j] = 0;
	//			}
	//		}
	//	}
	//	BYTE cbCardData[12],cbPosition=0;
	//	ZeroMemory(cbCardData,sizeof(cbCardData));
	//	for (int i=0;i<GAME_PLAYER;i++)
	//	{
	//		for (int j=0;j<MAX_CHANG;j++)
	//		{
	//			if (m_bChangCardDate[i][j]==0||m_bChangCardDate[i][j]>0x29) continue;						
	//			m_bChangDate[cbPosition] = m_bChangCardDate[i][j];
	//			cbPosition++;
	//		}
	//	}
	//	//混乱扑克
	//	RandChangCardData(m_bChangDate/*cbCardData*/,m_bChangCardCountAll);
	//	BYTE m_cbPosition=0;
	//	for (int i=0;i<GAME_PLAYER;i++)
	//	{
	//		if(m_bChangCard[i] ==false) continue;
	//		for (int j=0;j<m_bChangCardCount[i];j++)
	//		{
	//			m_bChangCardDate[i][j] = m_bChangDate[m_cbPosition];					
	//			m_cbPosition++;					
	//		}			
	//	}
	//	CMD_S_ChangCard changcard; 
	//	Changcard.bChangeCardEnd = true;
	//	for (int i=0;i<GAME_PLAYER;i++)
	//	{
	//		changcard.wChiarID = i;
	//		for (int j=0;j<MAX_CHANG;j++)
	//		{
	//			changcard.cbCardData[j] = m_bChangCardDate[i][j];
	//		}	
	//		changcard.wAddTimes = m_bChangCardCount[i];
	//		changcard.bChangeCard = m_bChangCard[i];
	//		m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_CHANGCARD,&changcard,sizeof(changcard));
	//		m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_CHANGCARD,&changcard,sizeof(changcard));
	//	}
	//	m_pITableFrame->KillGameTimer(IDI_TIMER_CHANG_CARD);
	//	m_pITableFrame->SetGameTimer(IDI_TIMER_CHANGCARD_END, 4000, 1, 0);
	//	//换牌结束
	//	CMD_S_END_ChangCard ChangCardend; 
	//	if(!m_bHasChangCardend)
	//	{
	//		m_bHasChangCardend  = true;
	//		ChangCardend.bChangeCardEnd = true;
	//		for (int i=0;i<GAME_PLAYER;i++)
	//		{
	//			if(m_bChangCard[i] ==false) continue;
	//			for (int j=0;j<m_bChangCardCount[i];j++)
	//			{					
	//				m_cbCardIndex[i][m_GameLogic.SwitchToCardIndex(m_bChangCardDate[i][j])]++;
	//			}
	//		}	
	//		m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_CHANGCARD_END,&ChangCardend,sizeof(ChangCardend));
	//		//m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_CHANGCARD_END,&ChangCardend,sizeof(ChangCardend));
	//	}
	//}
	//else if (wTimerID == IDI_TIMER_CHANGCARD_END)
	//{
	//	if(!m_bHasSendLastCard)
	//	{
	//		DispatchLastCardData();
	//		m_bHasSendLastCard = true;
	//	}
	//}
	//else if (wTimerID == IDI_TIMER_DIAO_YU)
	//{
	//	if (m_bCanSelDiaoYu == false)
	//	{
	//		return true;
	//	}
	//	for (int i = 0; i < GAME_PLAYER; i++)
	//	{
	//		m_bDiaoYuHasSel[i] = true;
	//	}
	//	SendStartGameCard();
	//}
	else if (wTimerID == IDI_TIMER_START_ANI_FINISH)
	{
		if (m_bStartAinFinish == true)
		{
			return true;
		}
		m_bStartAinFinish = true;
		m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_START_ANI_FINISH, 0, 0);

	}
	else if (wTimerID == IDI_TIME_JIESAN)
	{
		SendJieSanTime();
		return true;
	}
	/*else if (wTimerID == IDI_TIMER_BAOTING)
	{
		m_pITableFrame->KillGameTimer(IDI_TIMER_BAOTING);
		if(!m_bHasSendLastCard)
		{
			DispatchLastCardData();
			m_bHasSendLastCard = true;
		}
	}*/
	
	return false;
}

//游戏消息处理
bool __cdecl CTableFrameSink::OnGameMessage(WORD wSubCmdID, const void * pDataBuffer, WORD wDataSize, IServerUserItem * pIServerUserItem)
{
	switch (wSubCmdID)
	{
	case SUB_C_OUT_CARD:		//出牌消息
		{
			//效验消息
			ASSERT(wDataSize==sizeof(CMD_C_OutCard));
			if (wDataSize!=sizeof(CMD_C_OutCard)) return false;

			//用户效验
			tagServerUserData * pUserData=pIServerUserItem->GetUserData();
			if (pUserData->cbUserStatus!=US_PLAY) return true;

			BYTE status = m_pITableFrame->GetGameStatus();
			ASSERT(status==GS_MJ_PLAY);
			if (status!=GS_MJ_PLAY)	return false;

			//消息处理
			CMD_C_OutCard * pOutCard=(CMD_C_OutCard *)pDataBuffer;
			
			return OnUserOutCard(pUserData->wChairID,pOutCard->cbCardData);
		}
	//case SUB_C_LISTEN_CARD:
	//	{
	//		if(wDataSize != sizeof(CMD_S_BaoTing)) return false;
	//		CMD_S_BaoTing *baoting =(CMD_S_BaoTing *)pDataBuffer;
	//		//用户效验
	//		tagServerUserData * pUserData=pIServerUserItem->GetUserData();
	//		if (pUserData->cbUserStatus!=US_PLAY) return true;	
	//		ASSERT(m_pITableFrame->GetGameStatus()==GS_MJ_PLAY);
	//		if (m_pITableFrame->GetGameStatus()!=GS_MJ_PLAY)	return false;
	//		
	//		return OnUserListenCard(pUserData->wChairID,baoting->bBaoting);
	//	}
	case SUB_C_OPERATE_CARD:	//操作消息
		{
			
			//效验消息
			ASSERT(wDataSize==sizeof(CMD_C_OperateCard));
			if (wDataSize!=sizeof(CMD_C_OperateCard)) return false;
			
			//用户效验
			tagServerUserData * pUserData=pIServerUserItem->GetUserData();
			if (pUserData->cbUserStatus!=US_PLAY) return true;
			
			ASSERT(m_pITableFrame->GetGameStatus()==GS_MJ_PLAY);
			if (m_pITableFrame->GetGameStatus()!=GS_MJ_PLAY)	return false;
			
			//消息处理
			CMD_C_OperateCard * pOperateCard=(CMD_C_OperateCard *)pDataBuffer;
			
			if (m_cbUserAction[pUserData->wChairID]==WIK_NULL)
			{
				
				return true;
			}
			
			return OnUserOperateCard(pUserData->wChairID,pOperateCard->cbOperateCode,pOperateCard->cbOperateCard);
		}
	case SUB_C_TRUSTEE:
		{
			CMD_C_Trustee *pTrustee =(CMD_C_Trustee *)pDataBuffer;
			if(wDataSize != sizeof(CMD_C_Trustee)) return false;

			//用户效验
			tagServerUserData * pUserData=pIServerUserItem->GetUserData();

			//ASSERT(m_pITableFrame->GetGameStatus()==GS_MJ_PLAY);
			//if (m_pITableFrame->GetGameStatus()!=GS_MJ_PLAY)	return false;

			m_bTrustee[pUserData->wChairID]=pTrustee->bTrustee;
			CMD_S_Trustee Trustee;
			Trustee.bTrustee=pTrustee->bTrustee;
			Trustee.wChairID = pUserData->wChairID;
			m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_TRUSTEE,&Trustee,sizeof(Trustee));
			m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_TRUSTEE,&Trustee,sizeof(Trustee));

			return true;
		}
	//case SUB_C_HU_CARD:
	//	{
	//		CMD_C_HuCard *pHuPai =(CMD_C_HuCard *)pDataBuffer;
	//		if(wDataSize != sizeof(CMD_C_HuCard)) return false;
	//		if (!m_cbGameIsEnd && !m_bOtherOperate)
	//		{
	//			
 //				BYTE CurrenUser = pHuPai->wHuPaiUser;
	//			//轮换玩家
	//			do
	//			{
	//				CurrenUser=(CurrenUser+m_wPlayerCount-1)%m_wPlayerCount;
	//			}
	//			while (m_bPlayerStatus[CurrenUser]==FALSE);	
	//			//用户效验
	//			tagServerUserData * pUserData=pIServerUserItem->GetUserData();
	//			if(!m_bHasSendHuCard)
	//			{
 //					DispatchCardData(CurrenUser);
	//				CString strFile,strTemp;
	//				strFile.Format("log\\scnjmj.log");
	//				strTemp.Format(" 胡牌玩家=%d,胡牌发牌 = %d",pHuPai->wHuPaiUser,CurrenUser);
	//				WriteLog(strFile,strTemp);
	//				m_bHasSendHuCard = true;
	//			}				
	//		}			
	//		return true;
	//	}
	//case SUB_C_DIAOYU_SELECT:
	//	{
	//		
	//		//if(wDataSize != sizeof(CMD_S_DiaoYu)) return false;
	//		//CMD_S_DiaoYu *pDiaoYu =(CMD_S_DiaoYu *)pDataBuffer;
	//		////用户效验
	//		//tagServerUserData * pUserData=pIServerUserItem->GetUserData();
	//		//if (!m_bCanSelDiaoYu || m_bDiaoYuHasSel[pUserData->wChairID] == true)
	//		//{
	//		//	return false;
	//		//}
	//		//
	//		//CMD_S_DiaoYu diaoYu;
	//		//diaoYu.wChiarID = pUserData->wChairID;
	//		//diaoYu.wAddTimes = pDiaoYu->wAddTimes;
	//		//m_lDiaoYuTimes[pUserData->wChairID] = pDiaoYu->wAddTimes;

	//		//m_bDiaoYuHasSel[pUserData->wChairID] = true;

	//		//m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_DIAOYU,&diaoYu,sizeof(diaoYu));
	//		//m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_DIAOYU,&diaoYu,sizeof(diaoYu));
	//		//for (int i = 0; i < m_wPlayerCount; i++)
	//		//{
	//		//	if (m_bDiaoYuHasSel[i] == false)
	//		//	{
	//		//		return true;
	//		//	}
	//		//}
	//		////钓鱼结束
	//		//SendStartGameCard();
	//		//m_pITableFrame->KillGameTimer(IDI_TIMER_DIAO_YU);
	//		return true;
	//	}
	case SUB_C_START_ANI_FINISH:
		{
			m_pITableFrame->KillGameTimer(IDI_TIMER_START_ANI_FINISH);
			if (m_bStartAinFinish)
			{
				return true;
			}
			m_bStartAinFinish = true;
			m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_START_ANI_FINISH, 0, 0);

			/*m_pITableFrame->SetGameTimer(IDI_TIMER_XUAN_PIAOQI, 7000, 1, 0);
			m_pITableFrame->SendTableData(INVALID_CHAIR, SUB_S_START_PIAOQI, 0,0);*/
			//m_pITableFrame->SetGameTimer(IDI_TIMER_BAOTING, 10000, 1, 0);
			////判断是否能报听
			//bool bAroseAction=false;
			//m_baoTingstart = true;
			//for (int i=0;i<GAME_PLAYER;i++)
			//{
			//	m_baoTingcount++;
			//	//构造扑克
			//	BYTE cbCardIndexTemp[MAX_INDEX];
			//	CopyMemory(cbCardIndexTemp, m_cbCardIndex[i], sizeof(cbCardIndexTemp));
			//	
			//	if (i==m_wBankerUser)
			//	{
			//		//判断是否是天胡，天胡不能报听
			//		tagChiHuResult mChiHuResult;
			//		BYTE cbHuCard = m_GameLogic.AnalyseChiHuCard(m_cbCardIndex[i],NULL,0,0,0,mChiHuResult,m_cbQueMen[i]);
			//		if(cbHuCard != CHK_NULL)
			//			continue;
			//		cbCardIndexTemp[m_GameLogic.SwitchToCardIndex(m_cbSendCardData)]--;
			//	}

			//	BYTE j;
			//	for (j = 0; j < MAX_INDEX; j++)
			//	{
			//		//胡牌分析
			//		tagChiHuResult ChiHuResult;
			//		BYTE wChiHuRight = 0;
			//		BYTE cbCurrentCard = m_GameLogic.SwitchToCardData(j);
			//		BYTE cbHuCardKind = m_GameLogic.AnalyseChiHuCard(cbCardIndexTemp,NULL,0,cbCurrentCard,0,ChiHuResult,m_cbQueMen[i]);
			//		//结果判断
			//		if (cbHuCardKind != CHK_NULL) 
			//		{
			//			m_cbUserAction[i]|= WIK_LISTEN;
			//			bAroseAction = true;						
			//			break;
			//		}
			//	}				
			//}
			////if (bAroseAction)
			//{
			//	SendBaoTingNotify();
			//}
			//m_cbCardIndex[m_wBankerUser][m_GameLogic.SwitchToCardIndex(m_cbSendCardData)]++;
			return true;
		}
	case SUB_C_ZIJIAN_MSG://客户端返回创建房间的信息
		{
			//效验消息
			ASSERT(wDataSize==sizeof(CMD_C_ZiJianMsg));
			if (wDataSize!=sizeof(CMD_C_ZiJianMsg)) return false;
			//用户效验
			tagServerUserData * pUserData=pIServerUserItem->GetUserData();
			if (pUserData->cbUserStatus!=US_READY) return true;
			WORD wChairID = pUserData->wChairID;
			
			CMD_C_ZiJianMsg *pRoomMsg = (CMD_C_ZiJianMsg *)pDataBuffer;
			
			if (m_RoomNum==0)
			{
				m_cbPlayJushu = pRoomMsg->nJushu;
				//m_cbPlayJushu = 2;
				m_MaShu = pRoomMsg->nMshu;
				m_cbZhaMaCount = m_MaShu;
				m_RoomNum = pRoomMsg->nRoomnum;	
				m_nHaiDiLaoYueTwo = pRoomMsg->nHaiDiLaoYueTwo;
				m_nDiHuTwo = pRoomMsg->nDiHuTwo;
				m_nFollowBank = pRoomMsg->nFollowBank;
				m_nZhonePai = pRoomMsg->nZhonePai;
				m_LaiZi = m_nZhonePai;
				m_wBankerUser=wChairID;
				m_nOwnerUserID = pUserData->dwUserID;
				
				ZeroMemory(m_AllHuTime,sizeof(m_AllHuTime));
				ZeroMemory(m_AllMingGangTime,sizeof(m_AllMingGangTime));
				ZeroMemory(m_AllAnGangTime,sizeof(m_AllAnGangTime));
				ZeroMemory(m_AllFanGangTime,sizeof(m_AllFanGangTime));
				ZeroMemory(m_AllJieGangTime,sizeof(m_AllJieGangTime));
				ZeroMemory(m_AllZhongMaCount,sizeof(m_AllZhongMaCount));

				ZeroMemory(m_AllHuScore,sizeof(m_AllHuScore));
				ZeroMemory(m_AllMingGangScore,sizeof(m_AllMingGangScore));
				ZeroMemory(m_AllAnGangScore,sizeof(m_AllAnGangScore));
				ZeroMemory(m_AllFanJieGangScore,sizeof(m_AllFanJieGangScore));
				ZeroMemory(m_AllZhongMaScore,sizeof(m_AllZhongMaScore));
				ZeroMemory(m_AllWinScore,sizeof(m_AllWinScore));
				m_wRequestChairID = INVALID_CHAIR;
				m_nLessTime = 0;
				m_bGameOver = false;
				int fanka = m_cbPlayJushu/8;
				if (fanka<1)
				{
					fanka = 1;
				}
				m_pITableFrame->SetMatchCount(fanka);
			}
			CString str;
			str.Format("自建房间信息：房主=%d,房间号=%d,码数=%d,局数=%d;\n",wChairID,m_RoomNum,m_MaShu,m_cbPlayJushu);
			printf(str);
			return true;
		}
	case SUB_C_ASKFOR_DISMISSROOM:		//申请解散房间
		{
			//效验消息
			ASSERT(wDataSize==sizeof(CMD_C_DisMiss));
			if (wDataSize!=sizeof(CMD_C_DisMiss)) return false;

			//用户效验
			tagServerUserData * pUserData=pIServerUserItem->GetUserData();
			//if (pUserData->cbUserStatus!=US_READY) return true;

			/*BYTE status = m_pITableFrame->GetGameStatus();
			ASSERT(status==GS_MJ_PLAY);
			if (status!=GS_MJ_PLAY)	return false;*/
			//如果没开始过游戏必须房主才能解散
			if (m_cbHavePlayCount<=0)
			{
				if (m_wBankerUser!=pUserData->wChairID) return true;
			}
			if(m_bGameOver)  return true;
			//if(m_wRequestChairID!=INVALID_CHAIR)  return true;
			//消息处理
			CMD_C_DisMiss * pDisMiss=(CMD_C_DisMiss *)pDataBuffer;
			bool bDisMiss = pDisMiss->bDisMiss;
			if (m_wRequestChairID==INVALID_CHAIR)
			{
				m_wRequestChairID = pUserData->wChairID;
			}
			m_nLessTime = 0;
			return OnUserDisMissRoom(pUserData->wChairID,pDisMiss->bDisMiss);

		}
	//case SUB_C_PIAOQI_SELECT:
	//	{

	//		if(wDataSize != sizeof(CMD_S_PiaoQi)) return false;
	//		CMD_S_PiaoQi *pPiaoQi =(CMD_S_PiaoQi *)pDataBuffer;
	//		//用户效验
	//		tagServerUserData * pUserData=pIServerUserItem->GetUserData();
	//		if (!m_bCanSelQuemen || m_bPiaoQiHasSel[pUserData->wChairID] == true) 
	//			return false;
	//		if (m_bHasDingQue)  return true;
	//		CMD_S_PiaoQi piaoqi;
	//		piaoqi.wChiarID = pUserData->wChairID;
	//		piaoqi.wSelType = pPiaoQi->wSelType;
	//		if (piaoqi.wSelType>0)
	//		{
	//			m_bPiaoQi[pUserData->wChairID] = true;
	//		}
	//		
	//		m_cbQueMen[pUserData->wChairID] = 0;//pQueMen->wSelType;
	//		m_bPiaoQiHasSel[pUserData->wChairID] = true;

	//		m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_PIAOQI,&piaoqi,sizeof(piaoqi));
	//		m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_PIAOQI,&piaoqi,sizeof(piaoqi));
	//		for (int i = 0; i < m_wPlayerCount; i++)
	//		{
	//			if (m_bPiaoQiHasSel[i] == false) 
	//				return true;				
	//		}
	//		//选择缺门结束
	//		//SendStartGameCard();//开始是否换牌
	//		m_bHasDingQue = true;
	//					
	//		/*m_pITableFrame->SetGameTimer(IDI_TIMER_CHANG_CARD, 10000, 1, 0);*/
	//		//彯起结束
	//		SendStartGameCard();
	//		//m_pITableFrame->KillGameTimer(IDI_TIMER_DIAO_YU);
	//		m_pITableFrame->KillGameTimer(IDI_TIMER_XUAN_PIAOQI);

	//		////判断是否能报听
	//		//bool bAroseAction=false;
	//		//for (int i=0;i<GAME_PLAYER;i++)
	//		//{
	//		//	//构造扑克
	//		//	BYTE cbCardIndexTemp[MAX_INDEX];
	//		//	CopyMemory(cbCardIndexTemp, m_cbCardIndex[i], sizeof(cbCardIndexTemp));

	//		//	BYTE j;
	//		//	for (j = 0; j < MAX_INDEX; j++)
	//		//	{
	//		//		//胡牌分析
	//		//		tagChiHuResult ChiHuResult;
	//		//		BYTE wChiHuRight = 0;
	//		//		BYTE cbCurrentCard = m_GameLogic.SwitchToCardData(j);
	//		//		BYTE cbHuCardKind = m_GameLogic.AnalyseChiHuCard(cbCardIndexTemp,NULL,0,cbCurrentCard,0,ChiHuResult,m_cbQueMen[i]);
	//		//		//结果判断
	//		//		if (cbHuCardKind != CHK_NULL) 
	//		//		{
	//		//			m_cbUserAction[i]|= WIK_LISTEN;
	//		//			bAroseAction = true;
	//		//			break;
	//		//		}
	//		//	}				
	//		//}
	//		//if (bAroseAction)
	//		//{
	//		//	SendOperateNotify();
	//		//}
	//		//m_pITableFrame->SendTableData(INVALID_CHAIR, SUB_S_START_CHANGCARD, 0,0);
	//		return true;
	//	}
	//case SUB_C_CHANGCARD_SELECT:
	//	{
	//		if(wDataSize != sizeof(CMD_S_ChangCard)) return false;
	//		CMD_S_ChangCard *pChangCard =(CMD_S_ChangCard *)pDataBuffer;
	//		//用户效验
	//		tagServerUserData * pUserData=pIServerUserItem->GetUserData();
	//		if (!m_bCanSelChangCard || m_bChangCardHasSel[pUserData->wChairID] == true) return false;
	//		CMD_S_ChangCard Changcard; 
	//		if (pChangCard->bChangeCard)
	//		{
	//			m_bChangCardCount[pUserData->wChairID] = pChangCard->wAddTimes;
	//			m_bChangCardCountAll +=pChangCard->wAddTimes;
	//			m_bChangCard[pUserData->wChairID] = pChangCard->bChangeCard;
	//			for (int i=0;i<3;i++)
	//			{
	//				if (pChangCard->cbCardData[i]>0&&pChangCard->cbCardData[i]<0x30)
	//				{
	//					m_bChangCardDate[pUserData->wChairID][i] = pChangCard->cbCardData[i];
	//					Changcard.cbCardData[i] = pChangCard->cbCardData[i];
	//				}
	//				else
	//				{
	//					m_bChangCardDate[pUserData->wChairID][i] = 0;
	//				}
	//			}
	//			for (int i=0;i<pChangCard->wAddTimes;i++)
	//			{
	//				//错误断言
	//				ASSERT(m_GameLogic.IsValidCard(pChangCard->cbCardData[i])==true);
	//				//效验参数
	//				if (m_GameLogic.IsValidCard(pChangCard->cbCardData[i])==false) return false;
	//				//删除扑克
	//				if (m_GameLogic.RemoveCard(m_cbCardIndex[pUserData->wChairID],pChangCard->cbCardData[i])==false)
	//				{
	//					ASSERT(FALSE);
	//					return false;
	//				}
	//			}	
	//			Changcard.wAddTimes = pChangCard->wAddTimes;
	//			Changcard.bChangeCard = true;
	//		}
	//		else
	//		{
	//			Changcard.wAddTimes = 0;
	//			Changcard.bChangeCard = false;
	//			for (int i=0;i<3;i++)
	//			{
	//				m_bChangCardDate[pUserData->wChairID][i] = 0;
	//				Changcard.cbCardData[i] = 0;
	//			}
	//		}			
	//					
	//		m_bChangCardHasSel[pUserData->wChairID] = true;			
	//		Changcard.wChiarID = pUserData->wChairID;						
	//		Changcard.bChangeCardEnd = false;

	//		m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_CHANGCARD,&Changcard,sizeof(Changcard));
	//		m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_CHANGCARD,&Changcard,sizeof(Changcard));

	//		for (int i = 0; i < m_wPlayerCount; i++)
	//		{
	//			if (m_bChangCardHasSel[i] == false) return true;				
	//		}
	//		//BYTE cbCardData[12],cbPosition=0;
	//		//ZeroMemory(cbCardData,sizeof(cbCardData));
	//		//for (int i=0;i<GAME_PLAYER;i++)
	//		//{
	//		//	for (int j=0;j<MAX_CHANG;j++)
	//		//	{
	//		//		if (m_bChangCardDate[i][j]==0||m_bChangCardDate[i][j]>0x29) continue;						
	//		//		m_bChangDate[cbPosition] = m_bChangCardDate[i][j];
	//		//		cbPosition++;
	//		//	}
	//		//}
	//		////混乱扑克
	//		//RandChangCardData(m_bChangDate/*cbCardData*/,m_bChangCardCountAll);
	//		//BYTE m_cbPosition=0;
	//		//for (int i=0;i<GAME_PLAYER;i++)
	//		//{
	//		//	if(m_bChangCard[i] ==false) continue;
	//		//	for (int j=0;j<m_bChangCardCount[i];j++)
	//		//	{
	//		//		m_bChangCardDate[i][j] = m_bChangDate[m_cbPosition];					
	//		//		m_cbPosition++;					
	//		//	}			
	//		//}
	//		//CMD_S_ChangCard changcard; 
	//		//Changcard.bChangeCardEnd = true;
	//		//for (int i=0;i<GAME_PLAYER;i++)
	//		//{
	//		//	changcard.wChiarID = i;
	//		//	for (int j=0;j<MAX_CHANG;j++)
	//		//	{
	//		//		changcard.cbCardData[j] = m_bChangCardDate[i][j];
	//		//	}	
	//		//	changcard.wAddTimes = m_bChangCardCount[i];
	//		//	changcard.bChangeCard = m_bChangCard[i];
	//		//	m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_CHANGCARD,&changcard,sizeof(changcard));
	//		//	m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_CHANGCARD,&changcard,sizeof(changcard));
	//		//}
	//		
	//		//选择换牌结束
	//		//SendStartGameCard();
	//		m_pITableFrame->KillGameTimer(IDI_TIMER_CHANG_CARD);
	//		return true;
	//	}
	/*case SUB_C_END_CHANGCARD_SELECT:
		{
			if(wDataSize != sizeof(CMD_S_END_ChangCard)) return false;
			CMD_S_END_ChangCard *pChangCardend =(CMD_S_END_ChangCard *)pDataBuffer;
			CMD_S_END_ChangCard ChangCardend; 
			if(!m_bHasChangCardend)
			{
				m_bHasChangCardend  = true;
				ChangCardend.bChangeCardEnd = pChangCardend->bChangeCardEnd;
				for (int i=0;i<GAME_PLAYER;i++)
				{
					if(m_bChangCard[i] ==false) continue;
					for (int j=0;j<m_bChangCardCount[i];j++)
					{					
						m_cbCardIndex[i][m_GameLogic.SwitchToCardIndex(m_bChangCardDate[i][j])]++;
					}
				}	
				m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_CHANGCARD_END,&ChangCardend,sizeof(ChangCardend));
				m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_CHANGCARD_END,&ChangCardend,sizeof(ChangCardend));
			}
			return true;
		}*/
	/*case SUB_C_SEND_LASTCARD:
		{
			if(wDataSize != sizeof(CMD_S_END_ChangCard)) return false;
			CMD_S_END_ChangCard *pChangCardend =(CMD_S_END_ChangCard *)pDataBuffer;
			CMD_S_END_ChangCard ChangCardend; 
			ChangCardend.bChangeCardEnd = pChangCardend->bChangeCardEnd;
			for (int i=0;i<GAME_PLAYER;i++)
			{
			if(m_bChangCard[i] ==false) continue;
			for (int j=0;j<m_bChangCardCount[i];j++)
			{					
			m_cbCardIndex[i][m_GameLogic.SwitchToCardIndex(m_bChangCardDate[i][j])]++;
			}
			}*/	
			/*if(!m_bHasSendLastCard)
			{
				DispatchLastCardData();
				m_bHasSendLastCard = true;
			}
			return true;
		}*/
	}

	return false;
}
//混乱扑克
void CTableFrameSink::RandChangCardData(BYTE cbCardData[], BYTE cbMaxCount)
{
	//混乱准备
	BYTE cbCardDataTemp[CountArray(m_bChangDate)];
	CopyMemory(cbCardDataTemp,m_bChangDate,sizeof(m_bChangDate));

	//混乱扑克
	BYTE cbRandCount=0,cbPosition=0;
	if (cbMaxCount>0)
	{
		do
		{
			cbPosition=rand()%(cbMaxCount-cbRandCount);
			cbCardData[cbRandCount++]=cbCardDataTemp[cbPosition];
			cbCardDataTemp[cbPosition]=cbCardDataTemp[cbMaxCount-cbRandCount];
			//m_bChangDate =cbCardDataTemp[cbPosition];
		} while (cbRandCount<cbMaxCount);
	}
	return;
}
//框架消息处理
bool __cdecl CTableFrameSink::OnFrameMessage(WORD wSubCmdID, const void * pDataBuffer, WORD wDataSize, IServerUserItem * pIServerUserItem)
{
	return false;
}

//用户坐下
bool __cdecl CTableFrameSink::OnActionUserSitDown(WORD wChairID, IServerUserItem * pIServerUserItem, bool bLookonUser)
{
	//庄家设置
	if ((bLookonUser==false)&&(m_wBankerUser==INVALID_CHAIR))
	{
		if (DEF_TEST)
		{
			//test
			if (pIServerUserItem->IsAndroidUser() == false)
			{
				m_wBankerUser=pIServerUserItem->GetChairID();
			}
		}
		else
		{
				
			if (m_pGameServiceOption->wGameZoneType != em_zoneType_zhuangJin) //游戏区类型
			{
				//m_wBankerUser=(pIServerUserItem->GetChairID()+3)%4;
				//m_wBankerUser=pIServerUserItem->GetChairID();
				m_wBankerUser=pIServerUserItem->GetChairID();//rand()%4;
				//setFollowBank(m_wBankerUser);
			}                   
		}
		ZeroMemory(m_bPiaoQi,sizeof(m_bPiaoQi));
	}	
	//测试
	/*CString strFile,strTemp;
	strFile.Format("log\\scnjmj.log");
	strTemp.Format("%s(%d) sitdown in %d table %d chair,m_wBankerUser=%d \n", pIServerUserItem->GetNickName(), pIServerUserItem->GetUserID(), 
		pIServerUserItem->GetTableID(), wChairID,m_wBankerUser);
	WriteLog(strFile,strTemp);*/
	
	m_bServerTableID = pIServerUserItem->GetTableID();
	CMylogFile::Instance().WriteLogFmt(m_bServerTableID,"%s(%d) sitdown in %d table %d chair,m_wBankerUser=%d \n", pIServerUserItem->GetNickName(), pIServerUserItem->GetUserID(), 
		pIServerUserItem->GetTableID(), wChairID,m_wBankerUser);
	CString str;
	str.Format("%s(%d) sitdown in %d table %d chair,m_wBankerUser=%d \n", pIServerUserItem->GetNickName(), pIServerUserItem->GetUserID(),pIServerUserItem->GetTableID(), wChairID,m_wBankerUser);
	printf(str);

	//CString strFileName,str,strRoomName; //m_pGameServiceOption->szGameRoomName
	//strRoomName.Format(TEXT("%s.ini"),m_pGameServiceOption->szGameRoomName);
	//str.Format(TEXT("%s"),_T(strRoomName));//m_pGameServiceOption->szIniFile
	//TCHAR szPath[MAX_PATH];
	//GetCurrentDirectory(MAX_PATH, szPath);
	//strFileName.Format(TEXT("%s\\%s"), szPath, str);
	//TCHAR szKeyValuestart[64] = "";
	//GetPrivateProfileString(TEXT("GameOption"),"BasicScore",TEXT(""),szKeyValuestart,sizeof(szKeyValuestart),strFileName);
	//sscanf(szKeyValuestart,"%d",&m_RoomBasicScore);
	m_RoomBasicScore = m_pGameServiceOption->lCellScore;//房间底分
	return true;
}

//用户起来
bool __cdecl CTableFrameSink::OnActionUserStandUp(WORD wChairID, IServerUserItem * pIServerUserItem, bool bLookonUser)
{
	CMylogFile::Instance().WriteLogFmt(m_bServerTableID,"%s(%d) standup from %d table %d chair", pIServerUserItem->GetNickName(), pIServerUserItem->GetUserID(), 
		pIServerUserItem->GetTableID(), wChairID);
	//庄家设置
	if ((bLookonUser==false)&&(wChairID==m_wBankerUser))
	{
		if (m_pGameServiceOption->wGameZoneType != em_zoneType_zhuangJin) //游戏区类型
		{
			m_wBankerUser=INVALID_CHAIR;
			for (WORD i=0;i<m_wPlayerCount;i++)
			{
				m_bPiaoQi[i] = false;
				if ((i!=wChairID)&&(m_pITableFrame->GetServerUserItem(i)!=NULL))
				{
					m_wBankerUser=i;
					break;
				}
			}
		}		
	}
	int countplayer = 0;
	for (WORD i=0;i<m_wPlayerCount;i++)
	{
		if (m_pITableFrame->GetServerUserItem(i)!=NULL)
		{
			countplayer++;
		}
	}
	if (m_RoomNum!=0 && m_cbHavePlayCount == 0 && countplayer == 0 )
	{
		//if (m_wBankerUser==wChairID)
		{
			m_cbPlayJushu = 0;
			m_MaShu = 0;
			m_cbZhaMaCount = m_MaShu;
			m_RoomNum = 0;	
			m_wBankerUser=INVALID_CHAIR;
			m_wRequestChairID = INVALID_CHAIR;
		}
	}
	if (m_pITableFrame->GetGameStatus()!=GS_MJ_PLAY)
	{
		ZeroMemory(m_bPiaoQi,sizeof(m_bPiaoQi));
	}
	////测试
	//CString strFile,strTemp;
	//strTemp.Format("%s(%d) StandUp %d table %d chair\n", pIServerUserItem->GetNickName(), pIServerUserItem->GetUserID(), 
	//	pIServerUserItem->GetTableID(), wChairID);
	//WriteLog(strFile,strTemp);
	return true;
}

//用户听牌
bool CTableFrameSink::OnUserListenCard(WORD wChairID,bool wbListen)
{
	//效验状态
	ASSERT(m_pITableFrame->GetGameStatus()==GS_MJ_PLAY);
	if (m_pITableFrame->GetGameStatus()!=GS_MJ_PLAY) return true;

	//效验参数
	/*ASSERT((wChairID==m_wCurrentUser)&&(m_bEnjoinChiPeng[wChairID]==false));
	if ((wChairID!=m_wCurrentUser)||(m_bEnjoinChiPeng[wChairID]==true)) return false;*/
	if ((m_cbUserAction[wChairID]&WIK_LISTEN)!= 0)
	{
		m_cbUserAction[wChairID]&=~WIK_LISTEN;	
	}
	if (wbListen)
	{
		m_bEnjoinChiPeng[wChairID]=true;
	} 
	/*else
	{
		m_bEnjoinChiPeng[wChairID]=false;
	}*/
	//听牌合法判断

	//设置变量
	/*m_bEnjoinChiPeng[wChairID]=true;*/
	//m_bFirstChangeBao[wChairID] = true;
	/*m_bFirstLookBao[wChairID] = true;
	m_bCanLookBao[wChairID] = true;*/

	//构造数据
	CMD_S_ListenCard ListenCard;
	ListenCard.wListenUser=wChairID;
	ListenCard.wbListen = wbListen;
	//发送消息
	m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_LISTEN_CARD,&ListenCard,sizeof(ListenCard));
	m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_LISTEN_CARD,&ListenCard,sizeof(ListenCard));

	if(m_baoTingcount>0) m_bhasbaoting++;
	if (m_bhasbaoting>=m_baoTingcount)
	{
		if(!m_bHasSendLastCard)
		{
			DispatchLastCardData();
			m_bHasSendLastCard = true;
			
		}
	}
	
	return true;
}



//用户出牌
bool CTableFrameSink::OnUserOutCard(WORD wChairID, BYTE cbCardData)
{
	//效验状态
	ASSERT(m_pITableFrame->GetGameStatus()==GS_MJ_PLAY);
	if (m_pITableFrame->GetGameStatus()!=GS_MJ_PLAY) return true;

	//错误断言
	ASSERT(wChairID==m_wCurrentUser);
	ASSERT(m_GameLogic.IsValidCard(cbCardData)==true);

	//效验参数
	if (wChairID!=m_wCurrentUser) return false;
	if (m_GameLogic.IsValidCard(cbCardData)==false) return false;
	m_bHasSendHuCard = false;
	m_bOtherOperate = false;
	ZeroMemory(m_bPlayerNotHu,sizeof(m_bPlayerNotHu));
	// 玩家出牌了才可以碰
	for (int i = 0; i < MAX_INDEX; ++i)
	{
		m_bEnjoinChiHuIndex[wChairID][i]=false;
		m_bEnjoinPeng[wChairID][i]=false;
	}
	
	//删除扑克
	if (m_GameLogic.RemoveCard(m_cbCardIndex[wChairID],cbCardData)==false)
	{
		ASSERT(FALSE);
		return false;
	}
	//牌局
	TCHAR tcTemp[10];
	_stprintf(tcTemp,"%d,2,%02X;",wChairID,cbCardData);
	_tcscat(m_tcRecord,tcTemp);

	// 跟庄逻辑
	if (m_nFollowBankFlag)
	{
		if (m_cbOutCardCount%GAME_PLAYER == GAME_PLAYER - 1)
		{
			if (IsFollowBank())
			{
				setFollowBank(true);
			}
			else
			{
				setFollowBank(false);
				m_nFollowBankFlag = false;
			}
		}
		else if(m_cbOutCardCount%GAME_PLAYER == 0)
		{
			// 记录庄家出的第一张牌
			m_nFollowCardData = cbCardData;
		}
		else
		{
			if (m_nFollowCardData != cbCardData)
			{
				m_nFollowBankFlag = false;
			}
		}
	}

	//设置变量
	m_bQiangGangHu = false;
	m_bIsLastGang = false;
	m_iRecordLastGangChairId = INVALID_CHAIR;
	m_bIsGangKai = false;
	m_bSendStatus=true;
	m_cbUserAction[wChairID]=WIK_NULL;
	m_cbPerformAction[wChairID]=WIK_NULL;
	m_cbHupaiOperateCount = 0;
	//出牌记录
	m_cbOutCardCount++;
	m_wOutCardUser=wChairID;
	m_cbOutCardData=cbCardData;
	m_wLastOutcardUser = wChairID;
	//记录前三个玩家的出牌
	/*if (m_OutCardItemArray.cbCardIndex[0] ==0 && m_OutCardItemArray.wProvideUser[0] == 0)
	{
		m_OutCardItemArray.wProvideUser[0] = m_wOutCardUser;
		m_OutCardItemArray.cbCardIndex[0] = m_cbOutCardData;
	} 
	else if (m_OutCardItemArray.cbCardIndex[1] ==0 && m_OutCardItemArray.wProvideUser[1] == 0)
	{
		m_OutCardItemArray.wProvideUser[1] = m_wOutCardUser;
		m_OutCardItemArray.cbCardIndex[1] = m_cbOutCardData;
	}
	else if (m_OutCardItemArray.cbCardIndex[2] ==0 && m_OutCardItemArray.wProvideUser[2] == 0)
	{
		m_OutCardItemArray.wProvideUser[2] = m_wOutCardUser;
		m_OutCardItemArray.cbCardIndex[2] = m_cbOutCardData;
	}
	else
	{
		m_OutCardItemArray.wProvideUser[0] = m_OutCardItemArray.wProvideUser[1];
		m_OutCardItemArray.cbCardIndex[0] = m_OutCardItemArray.cbCardIndex[1];
		m_OutCardItemArray.wProvideUser[1] = m_OutCardItemArray.wProvideUser[2];;
		m_OutCardItemArray.cbCardIndex[1] = m_OutCardItemArray.cbCardIndex[2];
		m_OutCardItemArray.wProvideUser[2] = m_wOutCardUser;
		m_OutCardItemArray.cbCardIndex[2] = m_cbOutCardData;
	}*/
	//构造数据
	CMD_S_OutCard OutCard;
	OutCard.wOutCardUser=wChairID;
	OutCard.cbOutCardData=cbCardData;
	//测试
	/*CString strFile,strTemp;
	strFile.Format("log\\CurrentUser.log");

	strTemp.Format("into CurrentUser%d ChairID%d CardData%d OutCardUser",m_wCurrentUser,wChairID,cbCardData);
	WriteLog(strFile, strTemp);*/
	//发送消息
	m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_OUT_CARD,&OutCard,sizeof(OutCard));
	m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_OUT_CARD,&OutCard,sizeof(OutCard));
	SYSTEMTIME time;
	/*GetLocalTime(&time);
	printf("胡牌判断前：%02d-%02d-%02d %02d:%02d:%02d.%03d \n",time.wYear,time.wMonth,time.wDay,time.wHour,time.wMinute,time.wSecond,time.wMilliseconds);
	SetChaTingCard(m_wOutCardUser,false);
	GetLocalTime(&time);
	printf("胡牌判断后：%02d-%02d-%02d %02d:%02d:%02d.%03d \n",time.wYear,time.wMonth,time.wDay,time.wHour,time.wMinute,time.wSecond,time.wMilliseconds);*/
	IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(wChairID);
	ASSERT(pServerUserItem);
	bool bAI = true;
	if (pServerUserItem!=NULL)
	{
		bAI=pServerUserItem->IsAndroidUser();
		if(bAI==false)
			SetChaTingCard(m_wOutCardUser,false);
	}	
	CString str,strtmp;
	str.Format("OnUserOutCard:玩家%d出牌=0x%02x;",wChairID,cbCardData);
	CMD_S_CanListenCard pCanListenCard;
	ZeroMemory(&pCanListenCard,sizeof(pCanListenCard));
	//BYTE packData[MAX_INDEX];
	//ZeroMemory(packData,sizeof(packData));
	if (m_cbChaTing)
	{		
		//发送消息
		//BYTE packing;
		str = str + "可胡牌：" ;		
		for (int i=0;i<MAX_INDEX;i++)
		{
			//for (int j=0;j<10;j++)
			{
				if (m_ChaTingCardArray.cbCardData[0][i]==0) break;
				strtmp.Format("0x%02x,",m_ChaTingCardArray.cbCardData[0][i]);
				str = str + strtmp;
				pCanListenCard.cbHuCount++;
				pCanListenCard.cbCardData[i] = m_ChaTingCardArray.cbCardData[0][i];
			}
		}		
	}
	str = str + "\n" ;
	//printf(str);
	//CMD_S_LISTEN_CARD listenPacking;
	//ZeroMemory(&listenPacking,sizeof(listenPacking));
	//CopyMemory(listenPacking.carddata,packData,sizeof(listenPacking.carddata));
	////listenPacking.AddData(packData,sizeof(BYTE) * (MAX_INDEX));	
	if (bAI==false)
	{
		m_pITableFrame->SendTableData(wChairID,SUB_S_LISTEN_CARD,&pCanListenCard,sizeof(pCanListenCard));
	}

	//用户切换
	m_wProvideUser=wChairID;
	m_cbProvideCard=cbCardData;
	m_wCurrentUser=(wChairID+m_wPlayerCount-1)%m_wPlayerCount;
	//轮换玩家
	/*do
	{
		m_wCurrentUser=(m_wCurrentUser+m_wPlayerCount-1)%m_wPlayerCount;
	}
	while (m_bPlayerStatus[m_wCurrentUser]==FALSE);*/

	//测试
	/*strTemp.Format("into CurrentUser%d CurrentUser",m_wCurrentUser);
	WriteLog(strFile, strTemp);*/
	CMylogFile::Instance().WriteLogFmt(m_bServerTableID,"[UserOutCard]:Player=%s|OutCard=%s", GetPlayerName(wChairID).GetBuffer(0), m_GameLogic.GetCardName(cbCardData).GetBuffer(0));
	m_bGangStatus=false;

	bool bAroseAction=true;
	//换宝处理
	//HuanBao();
	//bool bHuanBao = HuanBao1();
	BYTE leftCardCount = m_cbLeftCardCount - m_cbGetFinalyIndex;
	if (leftCardCount==0)//打出最后一张牌15
	{
		m_bHaidiPao = true;
		m_GameLogic.m_bHaidiPao = true;
		m_GameLogic.m_bHaidilao = false;
	}
	// 出过牌
	m_bTianHupai = false;
	//首次出过牌用户标志
	if (m_bBeginOutCard[wChairID]==0)
	{
		m_bBeginOutCard[wChairID]=1; 
		m_bCanBuGang[wChairID] = true;
		if (m_wCurrentUser == m_wBankerUser)
		{
			m_bDiHupai = false;
		}
		else
		{
			m_bDiHupai = true;
		}
		
		ZeroMemory(m_bTianDiHupai,sizeof(m_bTianDiHupai));
	}
	else
	{
		m_bDiHupai = false;
	}
	/*if (bHuanBao)
	{
		if (m_cbBaopai != 0)
		{
			m_pITableFrame->SetGameTimer(IDI_TIMER_HUAN_BAO, TIME_BAO_PAI_DELAY_TIME, 1, wChairID);
		}
		else
		{
			m_pITableFrame->SetGameTimer(IDI_TIMER_HUAN_BAO, 3000, 1, wChairID);
		}
		return true;
	}*/
	
	//响应判断
	//判断其他玩家有没有吃牌，碰牌，吃胡的情况
	//printf("判断是否有操作开始\n");
	bAroseAction=EstimateUserRespond(wChairID,cbCardData,EstimatKind_OutCard);

	//派发扑克
	if (bAroseAction==false)
	{
		//printf("判断是否有操作结束\n");
		DispatchCardData(m_wCurrentUser);
		m_bGangShangPao = false;
		CString strFile,strTemp;
		strFile.Format("log\\scnjmj.log");
		strTemp.Format("玩家%d出牌,其他玩家无操作,发牌给玩家%d",wChairID,m_wCurrentUser);
		WriteLog(strFile,strTemp);
	}
	else
	{
		//printf("判断结果,玩家有操作\n");
	}
	
	return true;
}
//申请解散房间
bool CTableFrameSink::OnUserDisMissRoom(WORD wChairID,bool bdismiss)
{
	m_bDisMiss[wChairID] = bdismiss;
	m_bSelectDisMiss[wChairID] = true;
	for (int i=0;i<GAME_PLAYER;i++)
	{
		IServerUserItem * pUserItem=m_pITableFrame->GetServerUserItem(i);
		if (pUserItem ==NULL)
		{
			m_bDisMiss[i] = true;
			m_bSelectDisMiss[i] = true;
		}
	}
	//如果没开始过游戏必须房主才能解散
	if (m_cbHavePlayCount<=0)
	{
		if (m_wBankerUser==wChairID) 
		{
			for (int i=0;i<GAME_PLAYER;i++)
			{
				m_bDisMiss[i] = true;

				m_bSelectDisMiss[i] = true;
			}
		}
	}
	CMD_S_DisMissRoom cDisMissroom;
	ZeroMemory(&cDisMissroom,sizeof(cDisMissroom));
	cDisMissroom.bDisMiss = bdismiss;
	cDisMissroom.wChairID = wChairID;
	cDisMissroom.wRequestChairID = m_wRequestChairID;
	cDisMissroom.nLessTime = TIME_JIESAN_LEN;
	int count = 0;
	int juJueCount = 0; //拒绝
	bool bIsCloseBoard = false;
	for (int i=0;i<GAME_PLAYER;i++)
	{
		if (m_bDisMiss[i])
		{
			count++;
		}
		else
		{
			if (m_bSelectDisMiss[i])
			{
				juJueCount++;
			}
		}
	}
	//同意解散
	if(count>=3)
	{
		bIsCloseBoard = true;
		cDisMissroom.bDisMiss = true;
		cDisMissroom.bDisMissRoom = true;
		m_bGameOver = true;
		CopyMemory(cDisMissroom.nHuScore,m_AllHuTime,sizeof(cDisMissroom.nHuScore));
		CopyMemory(cDisMissroom.nMingGangScore,m_AllMingGangTime,sizeof(cDisMissroom.nMingGangScore));
		CopyMemory(cDisMissroom.nAnGangScore,m_AllAnGangTime,sizeof(cDisMissroom.nAnGangScore));
		CopyMemory(cDisMissroom.nFanGangScore,m_AllFanGangTime,sizeof(cDisMissroom.nFanGangScore));
		CopyMemory(cDisMissroom.nJieGangScore,m_AllJieGangTime,sizeof(cDisMissroom.nJieGangScore));
		CopyMemory(cDisMissroom.nZhongMaScore,m_AllZhongMaCount,sizeof(cDisMissroom.nZhongMaScore));
		CopyMemory(cDisMissroom.nWinScore,m_AllWinScore,sizeof(cDisMissroom.nWinScore));
		CopyMemory(cDisMissroom.cbAllFollowCount,m_AllFollowCount,sizeof(cDisMissroom.cbAllFollowCount));
		ZeroMemory(m_bDisMiss,sizeof(m_bDisMiss));
		ZeroMemory(m_bSelectDisMiss,sizeof(m_bSelectDisMiss));
		m_JieSanTime = TIME_JIESAN_LEN;
		m_RoomNum=0;
		m_MaShu = 0;
		m_cbPlayJushu = 0;
		m_cbHavePlayCount = 0;
		m_nOwnerUserID = INVALID_CHAIR;
		m_wBankerUser=INVALID_CHAIR;
		ZeroMemory(m_AllHuTime,sizeof(m_AllHuTime));
		ZeroMemory(m_AllMingGangTime,sizeof(m_AllMingGangTime));
		ZeroMemory(m_AllAnGangTime,sizeof(m_AllAnGangTime));
		ZeroMemory(m_AllFanGangTime,sizeof(m_AllFanGangTime));
		ZeroMemory(m_AllJieGangTime,sizeof(m_AllJieGangTime));
		ZeroMemory(m_AllZhongMaCount,sizeof(m_AllZhongMaCount));

		ZeroMemory(m_AllHuScore,sizeof(m_AllHuScore));
		ZeroMemory(m_AllMingGangScore,sizeof(m_AllMingGangScore));
		ZeroMemory(m_AllAnGangScore,sizeof(m_AllAnGangScore));
		ZeroMemory(m_AllFanJieGangScore,sizeof(m_AllFanJieGangScore));
		ZeroMemory(m_AllZhongMaScore,sizeof(m_AllZhongMaScore));
		ZeroMemory(m_AllWinScore,sizeof(m_AllWinScore));
		m_wRequestChairID = INVALID_CHAIR;
	}
	else if(juJueCount>=2) //拒绝解散
	{
		bIsCloseBoard = true;
		cDisMissroom.bDisMiss = false;
		cDisMissroom.bDisMissRoom = false;
		m_bGameOver = false;
		CopyMemory(cDisMissroom.nHuScore,m_AllHuTime,sizeof(cDisMissroom.nHuScore));
		CopyMemory(cDisMissroom.nMingGangScore,m_AllMingGangTime,sizeof(cDisMissroom.nMingGangScore));
		CopyMemory(cDisMissroom.nAnGangScore,m_AllAnGangTime,sizeof(cDisMissroom.nAnGangScore));
		CopyMemory(cDisMissroom.nFanGangScore,m_AllFanGangTime,sizeof(cDisMissroom.nFanGangScore));
		CopyMemory(cDisMissroom.nJieGangScore,m_AllJieGangTime,sizeof(cDisMissroom.nJieGangScore));
		CopyMemory(cDisMissroom.nZhongMaScore,m_AllZhongMaCount,sizeof(cDisMissroom.nZhongMaScore));
		CopyMemory(cDisMissroom.nWinScore,m_AllWinScore,sizeof(cDisMissroom.nWinScore));
		CopyMemory(cDisMissroom.cbAllFollowCount,m_AllFollowCount,sizeof(cDisMissroom.cbAllFollowCount));
		ZeroMemory(m_bDisMiss,sizeof(m_bDisMiss));
		ZeroMemory(m_bSelectDisMiss,sizeof(m_bSelectDisMiss));
		m_JieSanTime = TIME_JIESAN_LEN;
		m_wRequestChairID = INVALID_CHAIR;
	}
	m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_DISMISSROOM, &cDisMissroom, sizeof(cDisMissroom));
	if (m_bGameOver)
	{
		bool isFanHuanFangKa = false;
		if (m_cbHavePlayCount<=0)
		{
			isFanHuanFangKa = true;
		}
		m_cbHavePlayCount = 0;
		m_cbPlayJushu = 0;
		m_wRequestChairID = INVALID_CHAIR;
		//m_pITableFrame->ConcludeZiJian(isFanHuanFangKa);
		m_pITableFrame->ConcludeGame(1111);
	}
	if ((count+juJueCount)>=GAME_PLAYER)
	{
		m_wRequestChairID = INVALID_CHAIR;
	}
	return true;
}
bool CTableFrameSink::OnFengZhangOperateCard(WORD wChairID, WORD cbOperateCode, BYTE cbOperateCard)
{
	//效验状态
	ASSERT(m_bResponse[wChairID]==false);
	ASSERT((cbOperateCode==WIK_NULL)||((m_cbUserAction[wChairID]&cbOperateCode)!=0));

	//效验状态
	if (m_bResponse[wChairID]==true) 
		return false;
	if ((cbOperateCode!=WIK_NULL)&&((m_cbUserAction[wChairID]&cbOperateCode)==0))
		return false;

	//变量定义
	WORD wTargetUser=wChairID;
	WORD cbTargetAction=cbOperateCode;

	WORD minIndex = 4;
	WORD counthu = 0;	

	m_bResponse[wChairID]=true;

	m_cbPerformAction[wChairID]=cbOperateCode;
	m_cbOperateCard[wChairID]=(cbOperateCard==0) ?m_cbProvideCard:cbOperateCard;

	m_opterPassTimeArr[wChairID] = PLAYER_TIMER_OPT_NULL;

	//执行判断
	for (WORD i=0;i<m_wPlayerCount;i++)
	{
		if (m_cbUserAction[i] == 0 || i == wChairID)
			continue;
		//获取动作
		WORD cbUserAction=(m_bResponse[i]==false)?m_cbUserAction[i]:m_cbPerformAction[i];

		//优先级别
		BYTE cbUserActionRank=m_GameLogic.GetUserActionRank(cbUserAction);
		BYTE cbTargetActionRank=m_GameLogic.GetUserActionRank(cbTargetAction);

		//动作判断
		if (cbUserActionRank>cbTargetActionRank)
		{
			wTargetUser=i;
			cbTargetAction=cbUserAction;
		}
		//吃胡优先级
		else if (cbUserActionRank == cbTargetActionRank && 
			cbUserAction == cbTargetAction &&
			(cbUserAction&WIK_CHI_HU) != 0 )
		{
			int targetIndex = 0;
			int userIndex = 0;
			targetIndex = (m_wOutCardUser + m_wPlayerCount) - ((m_wOutCardUser>wChairID)?(wChairID+m_wPlayerCount):(wChairID)) ;
			userIndex = (m_wOutCardUser + m_wPlayerCount) - ((m_wOutCardUser>i)?(i+m_wPlayerCount):(i));
			if (userIndex < targetIndex)
			{
				if (userIndex<minIndex)
				{
					minIndex=userIndex;
					wTargetUser=i;
					cbTargetAction=cbUserAction;
					m_cbfirstIndex = i;
					if (counthu==3)
					{
						m_cbscendIndex = (i+ m_wPlayerCount-1)%m_wPlayerCount;
					} 
					else if (counthu==2)
					{
						for (int i=0;i<m_wPlayerCount;i++)
						{
							if (m_cbUserAction[i] == 0 || i == m_cbfirstIndex)
								continue;
							m_cbscendIndex = i;
						}
					}
				}							
			}
		}
	}
	if (m_bResponse[wTargetUser]==false) 
		return true;
	if ((m_cbUserAction[wTargetUser]&WIK_CHI_HU) != 0 && counthu==3 && m_cbfirstIndex!=INVALID_CHAIR && m_cbscendIndex!=INVALID_CHAIR)
	{
		if (m_cbfirstIndex !=wTargetUser)
		{
			if (m_bResponse[m_cbscendIndex]==true && (m_cbUserAction[m_cbscendIndex]&WIK_CHI_HU) != 0 ) 
				wTargetUser = m_cbscendIndex;
		}
	}
	m_bFengZhang = false;
	//放弃操作
	if (cbTargetAction==WIK_NULL)
	{
		//用户状态
		ZeroMemory(m_bResponse,sizeof(m_bResponse));
		ZeroMemory(m_cbUserAction,sizeof(m_cbUserAction));
		ZeroMemory(m_cbOperateCard,sizeof(m_cbOperateCard));
		ZeroMemory(m_cbPerformAction,sizeof(m_cbPerformAction));

		m_cbChiHuCard=0;
		m_wProvideUser=INVALID_CHAIR;
		OnEventGameEnd(m_wProvideUser,NULL,GER_NORMAL);

		return true;
	}

	

	if ((cbTargetAction&WIK_CHI_HU)!=0)
	{
		//吃牌权位
		DWORD dwChiHuRight=0;
		dwChiHuRight|=CHK_ZI_MO;
		m_wProvideUser = wTargetUser;
		m_cbChiHuCard=m_cbFengZhangCard[wTargetUser];
		//普通胡牌
		BYTE cbWeaveItemCount=m_cbWeaveItemCount[wTargetUser];
		tagWeaveItem * pWeaveItem=m_WeaveItemArray[wTargetUser];

		//去掉胡掉的牌
		BYTE cbCardIndexTemp[MAX_INDEX];
		CopyMemory(cbCardIndexTemp,m_cbCardIndex[wTargetUser],sizeof(cbCardIndexTemp));
		if (m_cbChiHuCard != 0)
		{
			m_GameLogic.RemoveCard(cbCardIndexTemp,m_cbChiHuCard);
		}

		tagChiHuData tempData = getChiHuData();
		DWORD chiHuKind = m_GameLogic.AnalyseChiHuCard(cbCardIndexTemp,pWeaveItem,cbWeaveItemCount,m_cbChiHuCard,dwChiHuRight,m_ChiHuResult[wTargetUser],m_cbQueMen[wTargetUser],tempData);
		if (chiHuKind == CHK_NULL)
		{
			return false;
		}
		if (m_bGangStatus)
		{
			m_ChiHuResult[wTargetUser].dwChiHuRight|=CHK_GANG_KAI;
			//m_ChiHuResult[wTargetUser].dwWinTimes+=1;
		}
		//自摸
		if (m_wProvideUser==wTargetUser)
		{
			//m_ChiHuResult[wTargetUser].dwWinTimes+=1;
		}
		cbCardIndexTemp[m_GameLogic.SwitchToCardIndex(m_cbChiHuCard)]++;
		m_bUserGenCount[wTargetUser] = m_GameLogic.GetFourtoOneCount(cbCardIndexTemp,pWeaveItem,cbWeaveItemCount);
		//if ((m_ChiHuResult[wTargetUser].dwChiHuRight&CHK_LONG_QIDUI)!=0)//是龙七对
		//{
		//	m_bUserGenCount[wTargetUser]-=1;
		//}
		//天胡 不算夹胡
		if (m_cbChiHuCard != 0)
		{
			////判断夹胡(单吊)
			//if ((m_ChiHuResult[wTargetUser].dwChiHuKind&CHK_JIA_HU)==0)
			//{
			//	//判断夹胡
			//	int count =m_GameLogic.ChiHuCardCount(cbCardIndexTemp,pWeaveItem,cbWeaveItemCount,m_cbQueMen[wTargetUser]);
			//	if (count == 1)
			//	{
			//		m_ChiHuResult[wTargetUser].dwChiHuRight|=CHK_JIA_HU;
			//		m_ChiHuResult[wTargetUser].dwWinTimes+=1;
			//	}
			//}
		}

		//结束信息
		//m_cbChiHuCard=m_cbProvideCard;
		//牌局
		TCHAR tcTemp[30];
		_stprintf(tcTemp,"%d,6,%02X;",m_wCurrentUser,m_cbChiHuCard);
		_tcscat(m_tcRecord,tcTemp);

		//结束游戏
		m_cPlayHuCount++;
		if (m_cPlayHuCount>=1 || m_cbLeftCardCount == 0)
		{
			OnEventGameEnd(m_wProvideUser,NULL,GER_NORMAL);
		}
		else
		{
			OnEventHupai(wTargetUser,NULL);
		}
		return true;
	}
	return true;
}

//用户操作
bool CTableFrameSink::OnUserOperateCard(WORD wChairID, WORD cbOperateCode, BYTE cbOperateCard)
{
	//效验状态
	if (m_pITableFrame->GetGameStatus()!=GS_MJ_PLAY)
		return true;

	//效验用户
	ASSERT((wChairID==m_wCurrentUser)||(m_wCurrentUser==INVALID_CHAIR));
	if ((wChairID!=m_wCurrentUser)&&(m_wCurrentUser!=INVALID_CHAIR)) 
		return false;
	CString strm;
	strm=getCString(cbOperateCode);
	//printf("OnUserOperateCard:玩家%d进入操作:%s,data=0x%02x;\n",wChairID,strm,cbOperateCard);
	// 杠上开花取消
	
	CMylogFile::Instance().WriteLogFmt(m_bServerTableID,"[UserOperateCard]:Player=%s|OutCard=%s|OperateCode=%s", 
		GetPlayerName(wChairID).GetBuffer(0), m_GameLogic.GetCardName(cbOperateCard).GetBuffer(0), m_GameLogic.GetActionName(cbOperateCode));
	////分张
	//if (m_bFengZhang == true)
	//{
	//	OnFengZhangOperateCard(wChairID, cbOperateCode, cbOperateCard);
	//	return true;
	//}
	for (int i = 0; i < MAX_INDEX; ++i)
	{
		m_bEnjoinPeng[wChairID][i]=false;
	}

	if (m_nFollowBankFlag && (cbOperateCode == WIK_PENG ||  cbOperateCode == WIK_GANG))
	{
		m_nFollowBankFlag = false;
	}
	
	ZeroMemory(m_GangCount,sizeof(m_GangCount));
	//被动动作
	if (m_wCurrentUser==INVALID_CHAIR)
	{
		//效验状态
		ASSERT(m_bResponse[wChairID]==false);
		ASSERT((cbOperateCode==WIK_NULL)||((m_cbUserAction[wChairID]&cbOperateCode)!=0));

		//效验状态
		if (m_bResponse[wChairID]==true) 
			return false;
		if ((cbOperateCode!=WIK_NULL)&&((m_cbUserAction[wChairID]&cbOperateCode)==0))
			return false;

		//变量定义
		WORD wTargetUser=wChairID;
		WORD cbTargetAction=cbOperateCode;
		WORD minIndex = 4;
		WORD counthu = 0;
		WORD OpetateUsercont = 0;
		WORD wLastChairID = wChairID ;
		//设置变量
		m_bResponse[wChairID]=true;
		for (WORD i=0;i<m_wPlayerCount;i++)
		{
			if ((m_cbUserAction[i]&WIK_CHI_HU) != 0) 
				counthu++;
			if (m_cbUserAction[i] != 0)
			{
				OpetateUsercont++;
			}
		}		
		if (counthu<=1)
		{
			m_cbHupaiCount=1;
			m_cbfirstIndex= wChairID;
		}
		//设置时间
		//m_opterPassTimeArr[wChairID] = PLAYER_TIMER_OPT_NULL;
		
		m_cbPerformAction[wChairID]=cbOperateCode;
		m_cbOperateCard[wChairID]=(cbOperateCard==0) ?m_cbProvideCard:cbOperateCard;
		
		if (counthu>0)
		{
			m_cbHupaiOperateCount++;
		}
		//执行判断
		for (WORD i=0;i<m_wPlayerCount;i++)
		{
			if (m_cbUserAction[i] == 0 || i == wChairID)
				continue;
			//获取动作
			WORD cbUserAction=(m_bResponse[i]==false)?m_cbUserAction[i]:m_cbPerformAction[i];

			//优先级别
			BYTE cbUserActionRank=m_GameLogic.GetUserActionRank(cbUserAction);
			BYTE cbTargetActionRank=m_GameLogic.GetUserActionRank(m_cbPerformAction[wChairID]);//cbTargetAction
			if ((/*cbTargetAction*/m_cbPerformAction[wChairID]&WIK_CHI_HU) != 0 && wLastChairID == wChairID)
			{
				if ((m_cbUserAction[wChairID]&WIK_CHI_HU) != 0) //再次确认玩家是否有胡牌
				{
					if (counthu==1&&m_cbHupaiCount==1)
					{
						m_cbHupaiCount--;
					}
					m_cbHupaiCount++;
					m_cbHupaiIndex[wChairID] = true;
					wLastChairID = INVALID_CHAIR;
				}				
			}
			//动作判断
			if (cbUserActionRank>cbTargetActionRank)
			{
				//m_cbHupaiCount++;////当次操作同时胡牌玩家数;为何要在这里自加？？？
				wTargetUser=i;
				cbTargetAction=cbUserAction;
			}
			//吃胡优先级
			else if (cbUserActionRank == cbTargetActionRank && 
				(cbTargetAction&WIK_CHI_HU) != 0 &&
				(cbUserAction&WIK_CHI_HU) != 0 )
			{
				wTargetUser=i;
				cbTargetAction=cbUserAction;
			}
		}

		if (m_cbUserAction[wChairID] & WIK_CHI_HU)
		{
			m_bEnjoinChiHuIndex[wChairID][m_GameLogic.SwitchToCardIndex(m_cbOperateCard[wChairID])] = true;
		}

		// 如果有碰不碰
		if (m_cbUserAction[wChairID]&WIK_PENG)
		{
			m_bEnjoinPeng[wChairID][m_GameLogic.SwitchToCardIndex(m_cbOperateCard[wChairID])] = true;
		}
		
		if (m_bResponse[wTargetUser]==false) 
			return true;
		if(counthu==3)
		{
			if(m_cbHupaiOperateCount<3) //m_cbHupaiCount
				return true;
		}
		else if(counthu>0)
		{
			if(m_cbHupaiOperateCount<OpetateUsercont) //m_cbHupaiCount
				return true;
		}
		BYTE HupaiIndex=0;
		for (int i=0;i<GAME_PLAYER;i++)
		{
			if (m_cbHupaiIndex[i])
			{
				HupaiIndex++;
			}
			//玩家可以胡牌
			if ((m_cbUserAction[i]&WIK_CHI_HU) != 0 && (m_cbPerformAction[i]==NULL || m_cbPerformAction[i]==WIK_CHI_HU)) 
			{
				m_bPlayerNotHu[i] = true;
			}
		}

		//放弃操作
		if (cbTargetAction==WIK_NULL)
		{

			//用户状态
			ZeroMemory(m_bResponse,sizeof(m_bResponse));
			ZeroMemory(m_cbUserAction,sizeof(m_cbUserAction));
			ZeroMemory(m_cbOperateCard,sizeof(m_cbOperateCard));
			ZeroMemory(m_cbPerformAction,sizeof(m_cbPerformAction));
			ZeroMemory(m_cbHupaiIndex,sizeof(m_cbHupaiIndex));
			if (m_bQiangGang)
			{
				if (m_bLastGangByte == GANG_AN)
				{
					m_AllAnGangTime[wTargetUser]++;
					for (int i=0;i<GAME_PLAYER;i++)
					{
						if (m_cbQiangGangUserID==i)
						{
							m_AnGangScore[i] +=6*m_RoomBasicScore;
						}
						else
						{
							m_AnGangScore[i] -=2*m_RoomBasicScore;
						}
					}
				}
				else if(m_bLastGangByte == GANG_MING)
				{
					m_AllMingGangTime[wTargetUser]++;
					for (int i=0;i<GAME_PLAYER;i++)
					{
						if (m_cbQiangGangUserID==i)
						{
							m_MingGangScore[i] +=3*m_RoomBasicScore;
						}
						else
						{
							m_MingGangScore[i] -=1*m_RoomBasicScore;
						}
					}
				}
			}
			m_bGangShangPao = false;
			m_cbHupaiCount= 0;
			m_cbHupaiOperateCount = 0;
			m_bQiangGang = false;
			m_bQiangGangCancel = true;
			

			//printf("用户进入操作:玩家%d放弃操作;\n",wTargetUser);
			//发送扑克
			DispatchCardData(m_wResumeUser);
			//printf("操作结果:玩家%d放弃操作;发牌给还原玩家%d,\n",wTargetUser,m_wResumeUser);
			CString strFile,strTemp;
			strFile.Format("log\\scnjmj.log");
			strTemp.Format(" 玩家放弃操作发牌 = %d",m_wResumeUser);
			WriteLog(strFile,strTemp);
			return true;
		}

		if(HupaiIndex>=3)
		{
			m_cbGameIsEnd = true;
		}
		memset(&m_opterPassTimeArr,PLAYER_TIMER_OPT_NULL,sizeof(m_opterPassTimeArr));

		//抢杠成功
		if (m_bQiangGang == true)
		{
			CMylogFile::Instance().WriteLogFmt(m_bServerTableID,"[QiangGang]|Player=%s|m_cbQiangGangCardData=%s", GetPlayerName(m_cbQiangGangUserID).GetBuffer(0),
				m_GameLogic.GetCardName(m_cbQiangGangCardData).GetBuffer(0));
			if (m_cbCardIndex[m_cbQiangGangUserID][m_GameLogic.SwitchToCardIndex(m_cbQiangGangCardData)] > 0)
			{
				m_cbCardIndex[m_cbQiangGangUserID][m_GameLogic.SwitchToCardIndex(m_cbQiangGangCardData)]--;
			}
			
			//构造结果
			CMD_S_QiangGang qiangGang;
			qiangGang.wResumeUser = m_cbQiangGangUserID;
			qiangGang.cbActionCard = m_cbQiangGangCardData;
			m_bQiangGang = false;
			m_bQiangGangCancel = false;
			m_bGangStatus = false;
			//printf("用户进入操作:玩家%d抢杠成功;\n",wTargetUser);
			//发送消息
			m_pITableFrame->SendTableData(m_cbQiangGangUserID,SUB_S_QIANG_GANG,&qiangGang,sizeof(qiangGang));
		}	
		BYTE cbTargetCard = 0;	
		BYTE	HuCount=0;
		if (m_cbHupaiCount>1)//当次操作同时胡牌玩家数
		{
			if (m_cPlayHuCount==0) //已经胡牌玩家的个数
			{
				if (m_cbHupaiCount==2)//当次操作同时胡牌玩家数
				{
					m_cbGameHuCount = 2;//一炮多响的玩家个数
					m_cbGameEndCount = 0;
				}
				else if (m_cbHupaiCount==3)
				{
					m_cbGameHuCount = 2;
					m_cbGameEndCount = 2;
				}
			} 
			else if (m_cPlayHuCount==1)
			{
				m_cbGameHuCount = 1;
				m_cbGameEndCount = 1;
			}			
			//printf("一炮多响的玩家个数=%d ;\n",m_cbGameHuCount);
			m_cPlayHuCount++;
			if (m_bFirstHuUser)
			{
				m_bFirstHuUser=false;
				m_wNextBankerUser = m_wProvideUser;
			}
			for (int i=0;i<GAME_PLAYER;i++)
			{
				//int i = (m_wProvideUser + m_wPlayerCount - (index + 1))%m_wPlayerCount;
				if(m_bPlayerStatus[i] == false) continue;				
				if (m_cbHupaiIndex[i])
				{			
					wTargetUser = i;
					//变量定义
					cbTargetCard=m_cbOperateCard[wTargetUser];
					//出牌变量
					m_cbOutCardData=0;
					m_bSendStatus=true;
					m_wOutCardUser=INVALID_CHAIR;
					m_bEnjoinChiHu[wTargetUser]=false;
					//吃别人的胡
					if ((cbTargetAction&WIK_CHI_HU)!=0)
					{
						//结束信息
						m_cbChiHuCard=cbTargetCard;
						//m_wProvideUser=m_wProvideUser;
						//HuCount++;
						//吃牌权位
						DWORD dwChiHuRight=0;
						dwChiHuRight|=CHK_FANG_PAO;
						//普通胡牌
						if (m_cbChiHuCard!=0)
						{
							//胡牌判断
							BYTE cbWeaveItemCount=m_cbWeaveItemCount[wTargetUser];
							tagWeaveItem * pWeaveItem=m_WeaveItemArray[wTargetUser];
							tagChiHuData tempData = getChiHuData();
							
							DWORD chiHuKind = m_GameLogic.AnalyseChiHuCard(m_cbCardIndex[wTargetUser],pWeaveItem,cbWeaveItemCount,m_cbChiHuCard,dwChiHuRight,m_ChiHuResult[wTargetUser],m_cbQueMen[wTargetUser],tempData);
							if (chiHuKind == CHK_NULL)
							{
								return false;
							}
							//插入扑克
							if (m_ChiHuResult[wTargetUser].dwChiHuKind!=CHK_NULL) 
							{
								m_cbCardIndex[wTargetUser][m_GameLogic.SwitchToCardIndex(m_cbChiHuCard)]++;
								//m_bUserGenCount[wTargetUser] = m_GameLogic.GetFourtoOneCount(m_cbCardIndex[wTargetUser],pWeaveItem,cbWeaveItemCount);
								//if ((m_ChiHuResult[wTargetUser].dwChiHuRight&CHK_LONG_QIDUI)!=0)//是龙七对
								//{
								//	m_bUserGenCount[wTargetUser]-=1;
								//}
								// 天胡
								if (m_bTianHupai)
								{
									m_GameLogic.m_bTianHu = true;
								}
								//地胡
								if (m_bDiHupai)
								{
									if (m_ChiHuResult[wTargetUser].dwChiHuKind!=WIK_NULL)
									{
										m_bTianDiHupai[wTargetUser] = false; 
										//m_ChiHuResult[wTargetUser].dwChiHuKind = WIK_NULL;
										//if (wTargetUser!=m_wBankerUser)
										//	m_ChiHuResult[wTargetUser].dwChiHuKind = CHK_DI_HU;//地胡
										//m_ChiHuResult[wTargetUser].dwChiHuRight = m_ChiHuResult[wTargetUser].dwChiHuKind;
										//m_ChiHuResult[wTargetUser].dwWinTimes = 13;
										m_GameLogic.m_bDiHu = true;
									}
								}

								
								if (m_bQiangGangHu)//是否抢杠胡
								{
									m_ChiHuResult[wTargetUser].dwChiHuRight|=CHK_GANG_HU;
									m_ChiHuResult[wTargetUser].dwChiHuKind|=CHK_GANG_HU;
								}
								if (m_bGangShangPao)//杠上炮
								{
									m_ChiHuResult[wTargetUser].dwChiHuRight|=CHK_GANG_PAO;
								}
								//还原扑克
								//m_cbCardIndex[wTargetUser][m_GameLogic.SwitchToCardIndex(m_cbChiHuCard)]--;
								//海底炮
								if (m_bHaidiPao)
								{
									m_ChiHuResult[wTargetUser].dwChiHuRight|=CHK_HAIDI_PAO;
									m_ChiHuResult[wTargetUser].dwChiHuKind|=CHK_HAIDI_PAO;
								}
							}
							
						}
						//牌局
						TCHAR tcTemp[30];
						_stprintf(tcTemp,"%d,6,%02X;",wTargetUser,m_cbChiHuCard);
						_tcscat(m_tcRecord,tcTemp);
						//结束游戏
						ASSERT(m_ChiHuResult[wTargetUser].dwChiHuKind!=CHK_NULL);
						
					}
				}
			}
			OnEventGameEnd(m_wProvideUser,NULL,GER_NORMAL);
			m_bIsGangKai = false;
			m_bQiangGangHu = false;
			m_bGangStatusOutcard = false;
			m_bGangShangPao = false;
			m_cPlayHuCount += (HuCount-1); 
			return true;
		} 
		else
		{
			m_cbGameHuCount = 0;
			m_cbGameEndCount = 0;
			//变量定义
			cbTargetCard=m_cbOperateCard[wTargetUser];
			//出牌变量
			m_cbOutCardData=0;
			m_bSendStatus=true;
			m_wOutCardUser=INVALID_CHAIR;
			m_bEnjoinChiHu[wTargetUser]=false;
			//吃别人的胡
			if ((cbTargetAction&WIK_CHI_HU)!=0)
			{
				//结束信息
				m_cbChiHuCard=cbTargetCard;
				m_wProvideUser=m_wProvideUser;

				//吃牌权位
				DWORD dwChiHuRight=0;
				dwChiHuRight|=CHK_FANG_PAO;
				//普通胡牌
				if (m_cbChiHuCard!=0)
				{
					//胡牌判断
					BYTE cbWeaveItemCount=m_cbWeaveItemCount[wTargetUser];
					tagWeaveItem * pWeaveItem=m_WeaveItemArray[wTargetUser];
					tagChiHuData tempData = getChiHuData();
					DWORD chiHuKind = m_GameLogic.AnalyseChiHuCard(m_cbCardIndex[wTargetUser],pWeaveItem,cbWeaveItemCount,m_cbChiHuCard,dwChiHuRight,m_ChiHuResult[wTargetUser],m_cbQueMen[wTargetUser],tempData);
					if (chiHuKind == WIK_NULL)
					{
						
						return false;
					}
					
					//插入扑克
					if (m_ChiHuResult[wTargetUser].dwChiHuKind!=CHK_NULL) 
					{
						m_cbCardIndex[wTargetUser][m_GameLogic.SwitchToCardIndex(m_cbChiHuCard)]++;
						//m_bUserGenCount[wTargetUser] = m_GameLogic.GetFourtoOneCount(m_cbCardIndex[wTargetUser],pWeaveItem,cbWeaveItemCount);
						//if ((m_ChiHuResult[wTargetUser].dwChiHuRight&CHK_LONG_QIDUI)!=0)//是龙七对
						//{
						//	m_bUserGenCount[wTargetUser]-=1;
						//}
						//地胡
						//if (m_bDiHupai)
						//{
						//	if (m_ChiHuResult[wTargetUser].dwChiHuKind!=WIK_NULL)
						//	{
						//		m_bTianDiHupai[wTargetUser] = false; 
						//		m_ChiHuResult[wTargetUser].dwChiHuKind = WIK_NULL;
						//		if (wTargetUser!=m_wBankerUser)
						//			m_ChiHuResult[wTargetUser].dwChiHuKind = CHK_DI_HU;//地胡
						//		m_ChiHuResult[wTargetUser].dwChiHuRight = m_ChiHuResult[wTargetUser].dwChiHuKind;
						//		m_ChiHuResult[wTargetUser].dwWinTimes = 3;
						//	}
						//}
						if (m_bQiangGangHu)//是否抢杠胡
						{
							m_ChiHuResult[wTargetUser].dwChiHuRight|=CHK_GANG_HU;
							m_ChiHuResult[wTargetUser].dwChiHuKind|=CHK_GANG_HU;
						}
						if (m_bGangShangPao)//杠上炮
						{
							m_ChiHuResult[wTargetUser].dwChiHuRight|=CHK_GANG_PAO;
							m_ChiHuResult[wTargetUser].dwChiHuKind|=CHK_GANG_PAO;
						}
						//还原扑克
						//m_cbCardIndex[wTargetUser][m_GameLogic.SwitchToCardIndex(m_cbChiHuCard)]--;
						//海底炮
						if (m_bHaidiPao)
						{
							m_ChiHuResult[wTargetUser].dwChiHuRight|=CHK_HAIDI_PAO;
							m_ChiHuResult[wTargetUser].dwChiHuKind|=CHK_HAIDI_PAO;
						}
					}
					
				}

				//牌局
				TCHAR tcTemp[30];
				_stprintf(tcTemp,"%d,6,%02X;",wTargetUser,m_cbChiHuCard);
				_tcscat(m_tcRecord,tcTemp);
				//结束游戏
				ASSERT(m_ChiHuResult[wTargetUser].dwChiHuKind!=CHK_NULL);
				m_cPlayHuCount++;
				m_bIsGangKai = false;
				m_bQiangGangHu = false;
				m_bGangStatusOutcard = false;
				m_bGangShangPao = false;				
				//if (m_cPlayHuCount>=3 || m_cbLeftCardCount == 0)
				{
					//printf("用户进入操作:玩家%d胡牌操作,结束游戏;\n",wTargetUser);
					OnEventGameEnd(m_wProvideUser,NULL,GER_NORMAL);
				}
				//else
				//{
				//	for (int i=0;i<GAME_PLAYER;i++)
				//	{
				//		if(m_bPlayerStatus[i] == false || wTargetUser==i ) continue;
				//		if (m_cbPerformAction[i]!=NULL && m_cbPerformAction[i]!=WIK_CHI_HU)
				//		{
				//			m_bOtherOperate = true;
				//		}
				//	}
				//	OnEventHupai(wTargetUser,NULL);
				//}
				//if (m_cbGameIsEnd==false)
				//{
				//	for (int i=0;i<GAME_PLAYER;i++)
				//	{
				//		if(m_bPlayerStatus[i] == false) continue;
				//		if (m_cbPerformAction[i]!=NULL)
				//		{
				//			//用户状态
				//			ZeroMemory(m_bResponse,sizeof(m_bResponse));
				//			ZeroMemory(m_cbUserAction,sizeof(m_cbUserAction));
				//			ZeroMemory(m_cbOperateCard,sizeof(m_cbOperateCard));
				//			cbTargetAction = m_cbPerformAction[i];
				//			//组合扑克
				//			ASSERT(m_cbWeaveItemCount[i]<4);
				//			WORD wIndex=m_cbWeaveItemCount[i]++;
				//			m_WeaveItemArray[i][wIndex].cbPublicCard=TRUE; //开门
				//			m_WeaveItemArray[i][wIndex].cbCenterCard=cbTargetCard;
				//			m_WeaveItemArray[i][wIndex].cbWeaveKind=cbTargetAction;
				//			m_bKaimen[i] = true;
				//			ZeroMemory(m_WeaveItemArray[i][wIndex].cbCardIndex,sizeof(m_WeaveItemArray[i][wIndex].cbCardIndex));
				//			m_WeaveItemArray[i][wIndex].wProvideUser=(m_wProvideUser==INVALID_CHAIR)?i:m_wProvideUser;

				//			//删除扑克
				//			switch (cbTargetAction)
				//			{
				//			case WIK_PENG:		//碰牌操作
				//				{
				//					//删除扑克
				//					BYTE cbRemoveCard[]={cbTargetCard,cbTargetCard};
				//					m_GameLogic.RemoveCard(m_cbCardIndex[i],cbRemoveCard,CountArray(cbRemoveCard));
				//					//牌局
				//					TCHAR tcTemp[30];
				//					_stprintf(tcTemp,"%d,4,%02X%02X%02X;",i,cbTargetCard,cbTargetCard,cbTargetCard);
				//					_tcscat(m_tcRecord,tcTemp);

				//					break;
				//				}
				//			case WIK_GANG:		//杠牌操作（直杠）
				//				{

				//					m_bGangCount++;
				//					m_bUserGangCount[i]++;
				//					if (!m_bQiangGang)
				//					{
				//						m_bGangStatusOutcard = true;
				//					}
				//					//杠牌设置
				//					if ((m_cbSendCardCount==1)&&(m_cbOutCardData==0))
				//					{
				//						//删除扑克
				//						BYTE cbRemoveCard[]={cbTargetCard,cbTargetCard,cbTargetCard};
				//						m_GameLogic.RemoveCard(m_cbCardIndex[i],cbRemoveCard,CountArray(cbRemoveCard));

				//					}
				//					else
				//					{
				//						//删除扑克
				//						BYTE cbRemoveCard[]={cbTargetCard,cbTargetCard,cbTargetCard};
				//						m_GameLogic.RemoveCard(m_cbCardIndex[i],cbRemoveCard,CountArray(cbRemoveCard));

				//					}
				//					//牌局
				//					TCHAR tcTemp[30];
				//					if (m_wProvideUser==INVALID_CHAIR || i==m_wProvideUser)
				//					{
				//						_stprintf(tcTemp,"%d,8,%02X;",i,cbTargetCard);
				//					}
				//					else
				//					{
				//						_stprintf(tcTemp,"%d,5,%02X;",i,cbTargetCard);
				//					}
				//					_tcscat(m_tcRecord,tcTemp);
				//					for(int i=0;i<GAME_PLAYER;i++)
				//					{
				//						m_bTianDiHupai[i] = false; //有碰杠，地胡不算
				//					}
				//					break;
				//				}
				//			}
				//			//构造结果
				//			CMD_S_OperateResult OperateResult;
				//			OperateResult.wOperateUser=i;
				//			OperateResult.cbOperateCard=cbTargetCard;
				//			OperateResult.cbOperateCode=cbTargetAction;
				//			OperateResult.wProvideUser=(m_wProvideUser==INVALID_CHAIR)?i:m_wProvideUser;
				//			
				//			//设置状态
				//			if (cbTargetAction==WIK_GANG) 
				//				m_bGangStatus=true;
				//			//设置用户
				//			m_wCurrentUser=i;

				//			m_opterPassTimeArr[m_wCurrentUser] = TIME_OPERATE_CARD;

				//			//发送消息
				//			m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_OPERATE_RESULT,&OperateResult,sizeof(OperateResult));
				//			m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_OPERATE_RESULT,&OperateResult,sizeof(OperateResult));
				//			m_bQiangGangCancel = false;
				//			
				//			//换宝处理
				//			//HuanBao();

				//			//杠牌处理
				//			if (cbTargetAction==WIK_GANG)
				//			{
				//				//效验动作
				//				bool bAroseAction=EstimateUserRespond(i,cbTargetCard,EstimatKind_GangCard);

				//				//发送扑克
				//				if (bAroseAction==false) 
				//				{
				//					DispatchCardData(i, false);
				//					CString strFile,strTemp;
				//					strFile.Format("log\\scnjmj.log");
				//					strTemp.Format(" 玩家杠操作4367发牌 = %d",m_wResumeUser);
				//					WriteLog(strFile,strTemp);
				//				}
				//				return true;
				//			}
				//			else
				//			{
				//				m_bGangStatusOutcard = false;
				//			}
				//			if (m_cbUserAction[m_wCurrentUser] != WIK_NULL)
				//			{
				//				SendOperateNotify();
				//			}
				//			ZeroMemory(m_cbPerformAction,sizeof(m_cbPerformAction));
				//		}
				//	}
				//}
				return true;
			}
		}
		
		//用户状态
		ZeroMemory(m_bResponse,sizeof(m_bResponse));
		ZeroMemory(m_cbUserAction,sizeof(m_cbUserAction));
		ZeroMemory(m_cbOperateCard,sizeof(m_cbOperateCard));
		ZeroMemory(m_cbPerformAction,sizeof(m_cbPerformAction));

		//组合扑克
		ASSERT(m_cbWeaveItemCount[wTargetUser]<4);
		WORD wIndex=m_cbWeaveItemCount[wTargetUser]++;
		m_WeaveItemArray[wTargetUser][wIndex].cbPublicCard=TRUE; //开门
		m_WeaveItemArray[wTargetUser][wIndex].cbCenterCard=cbTargetCard;
		m_WeaveItemArray[wTargetUser][wIndex].cbWeaveKind=cbTargetAction;
		m_WeaveItemArray[wTargetUser][wIndex].cbGangType=2;//明杠
		m_bIsLastGang = true;
		m_iRecordLastGangChairId = (m_wProvideUser==INVALID_CHAIR)?wTargetUser:m_wProvideUser;;
		m_bKaimen[wTargetUser] = true;
		ZeroMemory(m_WeaveItemArray[wTargetUser][wIndex].cbCardIndex,sizeof(m_WeaveItemArray[wTargetUser][wIndex].cbCardIndex));
		m_WeaveItemArray[wTargetUser][wIndex].wProvideUser=(m_wProvideUser==INVALID_CHAIR)?wTargetUser:m_wProvideUser;

		//删除扑克
		switch (cbTargetAction)
		{
		case WIK_PENG:		//碰牌操作
			{
				//删除扑克
				BYTE cbRemoveCard[]={cbTargetCard,cbTargetCard};
				m_GameLogic.RemoveCard(m_cbCardIndex[wTargetUser],cbRemoveCard,CountArray(cbRemoveCard));
				//牌局
				TCHAR tcTemp[30];
				_stprintf(tcTemp,"%d,4,%02X%02X%02X;",wTargetUser,cbTargetCard,cbTargetCard,cbTargetCard);
				_tcscat(m_tcRecord,tcTemp);

				break;
			}
		case WIK_GANG:		//杠牌操作（直杠）
			{

				m_bGangCount++;
				m_bUserGangCount[wTargetUser]++;
				m_FanJieGangScore[m_wProvideUser] -=3*m_RoomBasicScore;
				m_FanJieGangScore[wTargetUser] +=3*m_RoomBasicScore;
				m_AllFanGangTime[m_wProvideUser]++;
				m_AllJieGangTime[wTargetUser]++;
				if (!m_bQiangGang)
				{
					m_bGangStatusOutcard = true;
				}
				//杠牌设置
				if ((m_cbSendCardCount==1)&&(m_cbOutCardData==0))
				{
					//删除扑克
					BYTE cbRemoveCard[]={cbTargetCard,cbTargetCard,cbTargetCard};
					m_GameLogic.RemoveCard(m_cbCardIndex[wTargetUser],cbRemoveCard,CountArray(cbRemoveCard));

				}
				else
				{
					//删除扑克
					BYTE cbRemoveCard[]={cbTargetCard,cbTargetCard,cbTargetCard};
					m_GameLogic.RemoveCard(m_cbCardIndex[wTargetUser],cbRemoveCard,CountArray(cbRemoveCard));

				}
				//TaskGangType(wTargetUser,m_bUserGangCount[wTargetUser]);
				//牌局
				TCHAR tcTemp[30];
				if (m_wProvideUser==INVALID_CHAIR || wTargetUser==m_wProvideUser)
				{
					_stprintf(tcTemp,"%d,8,%02X;",wTargetUser,cbTargetCard);
				}
				else
				{
					_stprintf(tcTemp,"%d,5,%02X;",wTargetUser,cbTargetCard);
				}
				_tcscat(m_tcRecord,tcTemp);
				//统计刮风下雨得分
				////if(m_wProvideUser==INVALID_CHAIR) wTargetUser=m_wProvideUser;
				//m_GangCount[m_wProvideUser] = -/*m_pGameServiceOption->dwBasicScore*/m_RoomBasicScore*2;
				//m_GangCount[wTargetUser] -=m_GangCount[m_wProvideUser];
				//m_GangCountscore[m_wProvideUser] += m_GangCount[m_wProvideUser];
				//m_GangCountscore[wTargetUser] -= m_GangCount[m_wProvideUser];
				//m_GangWinscore[wTargetUser][m_wProvideUser] += -/*m_pGameServiceOption->dwBasicScore*/m_RoomBasicScore*2;
				//m_GangWinscore[wTargetUser][wTargetUser] += /*m_pGameServiceOption->dwBasicScore*/m_RoomBasicScore*2;
				for(int i=0;i<GAME_PLAYER;i++)
				{
					m_bTianDiHupai[i] = false; //有碰杠，地胡不算
				}
				//TCHAR recordID[40] ={};
				////积分变量
				//tagScoreInfo ScoreInfoArray[GAME_PLAYER];
				//ZeroMemory(&ScoreInfoArray,sizeof(ScoreInfoArray));
				////统计积分
				//for (WORD i=0;i<GAME_PLAYER;i++)
				//{
				//	if(m_bPlayerStatus[i]==false) continue;
				//	ScoreInfoArray[i].lScore=m_GangCount[i];
				//	//设置胜负
				//	if (ScoreInfoArray[i].lScore==0L) ScoreInfoArray[i].ScoreKind=enScoreKind_Draw;
				//	else ScoreInfoArray[i].ScoreKind=(ScoreInfoArray[i].lScore>0L)?enScoreKind_Win:enScoreKind_Lost;
				//	//写入积分
				//	m_pITableFrame->WriteUserScore(i,ScoreInfoArray[i].lScore,0,ScoreInfoArray[i].ScoreKind,0/*,enWSR_Normal,0,recordID*/);
				//}
				break;
			}
		}

		//构造结果
		CMD_S_OperateResult OperateResult;
		OperateResult.wOperateUser=wTargetUser;
		OperateResult.cbOperateCard=cbTargetCard;
		OperateResult.cbOperateCode=cbTargetAction;
		OperateResult.wProvideUser=(m_wProvideUser==INVALID_CHAIR)?wTargetUser:m_wProvideUser;
		OperateResult.cbGangType = m_WeaveItemArray[wTargetUser][wIndex].cbGangType;
		//设置状态
		if (cbTargetAction==WIK_GANG) 
			m_bGangStatus=true;
		//设置用户
		m_wCurrentUser=wTargetUser;
		if (m_pGameServiceOption->wGameZoneType==em_zoneType_zhuangJin)
		{
			m_opterPassTimeArr[m_wCurrentUser] = TIME_OPERATE_CARD_ZIJIAN;
		} 
		else
		{
			m_opterPassTimeArr[m_wCurrentUser] = TIME_OPERATE_CARD;
		}

		//发送消息
		m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_OPERATE_RESULT,&OperateResult,sizeof(OperateResult));
		m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_OPERATE_RESULT,&OperateResult,sizeof(OperateResult));
		m_bQiangGangCancel = false;
		//换宝处理
		//HuanBao();
		CString tempstr;
		tempstr = getCString(cbTargetAction);
		//printf("用户进入操作:玩家%d操作:%s,data=0x%02x,发送SUB_S_OPERATE_RESULT;\n",m_wCurrentUser,tempstr,OperateResult.cbOperateCard);
		//杠牌处理
		if (cbTargetAction==WIK_GANG)
		{
			//效验动作
			bool bAroseAction=EstimateUserRespond(wTargetUser,cbTargetCard,EstimatKind_GangCard);

			//发送扑克
			if (bAroseAction==false) 
			{
				DispatchCardData(wTargetUser, false);
				CString strFile,strTemp;
				strFile.Format("log\\scnjmj.log");
				strTemp.Format(" 玩家杠操作4519发牌 = %d",m_wResumeUser);
				WriteLog(strFile,strTemp);
			}

			return true;
		}
		else
		{
			m_bGangStatusOutcard = false;
		}
		if (m_cbUserAction[m_wCurrentUser] != WIK_NULL)
		{
			SendOperateNotify();
		}
		return true;
	}
	//自己摸到牌自己选择是否操作
	//主动动作
	
	WORD wTargetUser=wChairID;
	if (m_wCurrentUser==wTargetUser)
	{
		
		//扑克效验
		ASSERT((cbOperateCode==WIK_NULL)||((cbOperateCode&WIK_CHI_HU)!=0)||(m_GameLogic.IsValidCard(cbOperateCard)==true)/*||((cbOperateCode&WIK_BAO_HU)!=0)*/);
		if ((cbOperateCode!=WIK_NULL)&&(cbOperateCode&WIK_CHI_HU==0)&&(m_GameLogic.IsValidCard(cbOperateCard)==false)/*&&(cbOperateCode&WIK_BAO_HU==0)*/) 
			return false;
		
		//设置变量
		m_bSendStatus=true;
		m_bEnjoinChiHu[wTargetUser]=false;
		m_cbUserAction[wTargetUser]=WIK_NULL;
		m_cbPerformAction[wTargetUser]=WIK_NULL;

		bool bPublic=true;
		if ((cbOperateCode&WIK_CHI_HU)!=0)
		{
			
			//吃牌权位
			DWORD dwChiHuRight=0;
			dwChiHuRight|=CHK_ZI_MO;
			m_wProvideUser = m_wCurrentUser;
			m_cbChiHuCard=m_cbProvideCard;
			//普通胡牌
			BYTE cbWeaveItemCount=m_cbWeaveItemCount[wTargetUser];
			tagWeaveItem * pWeaveItem=m_WeaveItemArray[wTargetUser];

			//去掉胡掉的牌
			BYTE cbCardIndexTemp[MAX_INDEX];
			CopyMemory(cbCardIndexTemp,m_cbCardIndex[wTargetUser],sizeof(cbCardIndexTemp));
			if (m_cbChiHuCard != 0)
			{
				m_GameLogic.RemoveCard(cbCardIndexTemp,m_cbChiHuCard);
			}
			tagChiHuData tempData = getChiHuData();
			DWORD chiHuKind = m_GameLogic.AnalyseChiHuCard(cbCardIndexTemp,pWeaveItem,cbWeaveItemCount,m_cbChiHuCard,dwChiHuRight,m_ChiHuResult[wTargetUser],m_cbQueMen[wTargetUser],tempData);
			if (chiHuKind == CHK_NULL)
			{
				return false;
			}
			if (m_bGangStatus)
			{
				m_ChiHuResult[wTargetUser].dwChiHuRight|=CHK_GANG_KAI;
			}
			////四归一
			//cbCardIndexTemp[m_GameLogic.SwitchToCardIndex(m_cbChiHuCard)]++;
			//m_bUserGenCount[wTargetUser] = m_GameLogic.GetFourtoOneCount(cbCardIndexTemp,pWeaveItem,cbWeaveItemCount);
			//if ((m_ChiHuResult[wTargetUser].dwChiHuRight&CHK_LONG_QIDUI)!=0)//是龙七对
			//{
			//	m_bUserGenCount[wTargetUser]-=1;
			//}
			////天胡 不算夹胡
			//if (m_bTianDiHupai[wTargetUser])
			//{
			//	if (m_ChiHuResult[wTargetUser].dwChiHuKind!=WIK_NULL)
			//	{
			//		m_bTianDiHupai[wTargetUser] = false; 
			//		m_ChiHuResult[wTargetUser].dwChiHuKind = WIK_NULL;
			//		if (wTargetUser==m_wBankerUser)
			//			m_ChiHuResult[wTargetUser].dwChiHuKind = CHK_TIAN_HU;//天胡
			//		//else
			//		//	m_ChiHuResult[wTargetUser].dwChiHuKind = CHK_DI_HU; //地胡

			//		m_ChiHuResult[wTargetUser].dwChiHuRight = m_ChiHuResult[wTargetUser].dwChiHuKind;
			//		m_ChiHuResult[wTargetUser].dwChiHuRight |= CHK_ZI_MO;
			//		m_ChiHuResult[wTargetUser].dwWinTimes = 3;
			//	}
			//}
			////海底捞
			//if (m_bHaidilao)
			//{
			//	m_ChiHuResult[wTargetUser].dwChiHuRight|=CHK_HAIDI_LAO;
			//}
			//结束信息
			//m_cbChiHuCard=m_cbProvideCard;
			//牌局
			TCHAR tcTemp[30];
			_stprintf(tcTemp,"%d,6,%02X;",m_wCurrentUser,m_cbChiHuCard);
			_tcscat(m_tcRecord,tcTemp);

			m_bGangShangPao = false;
			m_bGangStatusOutcard = false;
			//结束游戏
			m_cPlayHuCount++;
			//if (m_cPlayHuCount>=3 || m_cbLeftCardCount == 0)
			{
				//printf("用户主动进入操作:玩家%d操作,结束游戏:;\n",m_wProvideUser);
				OnEventGameEnd(m_wProvideUser,NULL,GER_NORMAL);
			}
			/*else
			{
			OnEventHupai(wTargetUser,NULL);
			}*/
			return true;
		}
		//如果是补杠是否有人抢杠
		if (cbOperateCard!=0)
		{
			if (m_cbCardIndex[wChairID][m_GameLogic.SwitchToCardIndex(cbOperateCard)]==0)
			{
				return true;
			}
		}
		
		//放弃操作
		if (cbOperateCode==WIK_NULL)
		{
			//用户状态
			ZeroMemory(m_bResponse,sizeof(m_bResponse));
			ZeroMemory(m_cbUserAction,sizeof(m_cbUserAction));
			ZeroMemory(m_cbOperateCard,sizeof(m_cbOperateCard));
			ZeroMemory(m_cbPerformAction,sizeof(m_cbPerformAction));
			m_bGangShangPao = false;
			m_bQiangGang = false;
			m_bQiangGangCancel = true;
			m_bQiangGangHu = false;
			if (wTargetUser == m_wCurrentUser)
			{
				return true;
			}
			//printf("用户进入操作:玩家%d放弃操作;\n",wTargetUser);
			//发送扑克
			DispatchCardData(m_wResumeUser);
			//printf("操作结果:玩家%d放弃操作;发牌给还原玩家%d,\n",wTargetUser,m_wResumeUser);
			CString strFile,strTemp;
			strFile.Format("log\\scnjmj.log");
			strTemp.Format(" 玩家放弃操作发牌 = %d",m_wResumeUser);
			WriteLog(strFile,strTemp);
			return true;
		}

		//执行动作
		switch (cbOperateCode)
		{
		case WIK_GANG:			//杠牌操作(自摸补杠)
			{
				//变量定义
				BYTE cbWeaveIndex=0xFF;
				BYTE cbCardIndex=m_GameLogic.SwitchToCardIndex(cbOperateCard);
				if (!m_bQiangGang)
				{
					m_bGangStatusOutcard = true;
				}			
				//杠牌处理 (明杠)(面下杠)
				BYTE bMingGang = INVALID_BYTE;
				if (m_cbCardIndex[wTargetUser][cbCardIndex]==1)
				{
					//寻找组合
					for (BYTE i=0;i<m_cbWeaveItemCount[wTargetUser];i++)
					{
						BYTE cbWeaveKind=m_WeaveItemArray[wTargetUser][i].cbWeaveKind;
						BYTE cbCenterCard=m_WeaveItemArray[wTargetUser][i].cbCenterCard;
						if ((cbCenterCard==cbOperateCard)&&(cbWeaveKind==WIK_PENG))
						{
							bPublic=true;
							cbWeaveIndex=i;							
							////统计刮风下雨得分
							////杠庄家番倍
							//for (int j = 0; j < GAME_PLAYER; j++)
							//{
							//	if (m_bPlayerStatus[j]==false || j==wTargetUser) continue;
							//	m_GangCount[j] = -m_RoomBasicScore/*m_pGameServiceOption->dwBasicScore*/;
							//	m_GangCountscore[j] += m_GangCount[j];
							//	m_GangWinscore[wTargetUser][j] += m_GangCount[j];
							//}
							////开始扣分
							//for (int k = 0; k < GAME_PLAYER; k++)
							//{
							//	if(m_bPlayerStatus[k]==false || k==wTargetUser) continue;
							//	m_GangCount[wTargetUser] -=m_GangCount[k];
							//	m_GangCountscore[wTargetUser] -= m_GangCount[k];
							//	m_GangWinscore[wTargetUser][wTargetUser] -= m_GangCount[k];
							//}
							//
							//TCHAR recordID[40] ={};
							////积分变量
							//tagScoreInfo ScoreInfoArray[GAME_PLAYER];
							//ZeroMemory(&ScoreInfoArray,sizeof(ScoreInfoArray));
							////统计积分
							//for (WORD i=0;i<GAME_PLAYER;i++)
							//{
							//	if(m_bPlayerStatus[i]==false) continue;
							//	ScoreInfoArray[i].lScore=m_GangCount[i];
							//	//设置胜负
							//	if (ScoreInfoArray[i].lScore==0L) ScoreInfoArray[i].ScoreKind=enScoreKind_Draw;
							//	else ScoreInfoArray[i].ScoreKind=(ScoreInfoArray[i].lScore>0L)?enScoreKind_Win:enScoreKind_Lost;
							//	//写入积分
							//	m_pITableFrame->WriteUserScore(i,ScoreInfoArray[i].lScore,0,ScoreInfoArray[i].ScoreKind,0/*,enWSR_Normal,0,recordID*/);
							//}
							break;
						}
					}

					//效验动作
					ASSERT(cbWeaveIndex!=0xFF);
					if (cbWeaveIndex==0xFF) return false;
					//组合扑克
					m_WeaveItemArray[wTargetUser][cbWeaveIndex].cbPublicCard=TRUE;
					m_WeaveItemArray[wTargetUser][cbWeaveIndex].wProvideUser=wTargetUser;
					m_WeaveItemArray[wTargetUser][cbWeaveIndex].cbWeaveKind=cbOperateCode;
					m_WeaveItemArray[wTargetUser][cbWeaveIndex].cbCenterCard=cbOperateCard;
					m_WeaveItemArray[wTargetUser][cbWeaveIndex].cbGangType=1;//公杠
					m_AllMingGangTime[wTargetUser]++;
					bMingGang = GANG_MING;
					for (int i=0;i<GAME_PLAYER;i++)
					{
						if (wTargetUser==i)
						{
							m_MingGangScore[i] +=3*m_RoomBasicScore;
						}
						else
						{
							m_MingGangScore[i]-=1*m_RoomBasicScore;
						}
					}
					
					
				}
				else
				{
					//扑克效验
					ASSERT(m_cbCardIndex[wTargetUser][cbCardIndex]==4);
					if (m_cbCardIndex[wTargetUser][cbCardIndex]!=4) 
						return false;

					//设置变量
					bPublic=false;
					cbWeaveIndex=m_cbWeaveItemCount[wTargetUser]++;
					m_WeaveItemArray[wTargetUser][cbWeaveIndex].cbPublicCard=FALSE;
					m_WeaveItemArray[wTargetUser][cbWeaveIndex].wProvideUser=wTargetUser;
					m_WeaveItemArray[wTargetUser][cbWeaveIndex].cbWeaveKind=cbOperateCode;
					m_WeaveItemArray[wTargetUser][cbWeaveIndex].cbCenterCard=cbOperateCard;
					m_WeaveItemArray[wTargetUser][cbWeaveIndex].cbGangType=0;//暗杠
					bMingGang = GANG_AN;
					//TaskType(wTargetUser,cbOperateCode);
					#pragma region //统计刮风下雨得分
					////杠庄家番倍
					//for (int i = 0; i < GAME_PLAYER; i++)
					//{
					//	if (m_bPlayerStatus[i]==false || i==wTargetUser) continue;
					//	m_GangCount[i] = -/*m_pGameServiceOption->dwBasicScore*/m_RoomBasicScore*2;
					//	m_GangCountscore[i] += m_GangCount[i];
					//	m_GangWinscore[wTargetUser][i] += m_GangCount[i];
					//}
					////开始扣分
					//for (int j = 0; j < GAME_PLAYER; j++)
					//{
					//	if (m_bPlayerStatus[j]==false || j==wTargetUser) continue;
					//	m_GangCount[wTargetUser] -=m_GangCount[j];
					//	m_GangCountscore[wTargetUser] -= m_GangCount[j];
					//	m_GangWinscore[wTargetUser][wTargetUser] -= m_GangCount[j];
					//}
					//TCHAR recordID[40] ={};
					////积分变量
					//tagScoreInfo ScoreInfoArray[GAME_PLAYER];
					//ZeroMemory(&ScoreInfoArray,sizeof(ScoreInfoArray));
					////统计积分
					//for (WORD i=0;i<GAME_PLAYER;i++)
					//{
					//	if(m_bPlayerStatus[i]==false) continue;
					//	ScoreInfoArray[i].lScore=m_GangCount[i];
					//	//设置胜负
					//	if (ScoreInfoArray[i].lScore==0L) ScoreInfoArray[i].ScoreKind=enScoreKind_Draw;
					//	else ScoreInfoArray[i].ScoreKind=(ScoreInfoArray[i].lScore>0L)?enScoreKind_Win:enScoreKind_Lost;
					//	//写入积分
					//	m_pITableFrame->WriteUserScore(i,ScoreInfoArray[i].lScore,0,ScoreInfoArray[i].ScoreKind,0/*,enWSR_Normal,0,recordID*/);
					//}
					#pragma endregion
					m_AllAnGangTime[wTargetUser]++;
					for (int i=0;i<GAME_PLAYER;i++)
					{
						if (wTargetUser==i)
						{
							m_AnGangScore[i] +=6*m_RoomBasicScore;
						}
						else
						{
							m_AnGangScore[i]-=2*m_RoomBasicScore;
						}
					}
				}

				//删除扑克
				m_cbCardIndex[wTargetUser][cbCardIndex]=0;

				//设置状态
				if (cbOperateCode==WIK_GANG)
					m_bGangStatus=true;

				//构造结果
				CMD_S_OperateResult OperateResult;
				OperateResult.wOperateUser=wTargetUser;
				OperateResult.wProvideUser=wTargetUser;
				OperateResult.cbOperateCode=cbOperateCode;
				OperateResult.cbOperateCard=cbOperateCard;
				OperateResult.cbGangType = m_WeaveItemArray[wTargetUser][cbWeaveIndex].cbGangType;
				//发送消息
				m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_OPERATE_RESULT,&OperateResult,sizeof(OperateResult));
				m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_OPERATE_RESULT,&OperateResult,sizeof(OperateResult));
				m_bQiangGangCancel = false;
				CString tmmpstr;
				tmmpstr = getCString(cbOperateCode);
				//printf("用户主动进入操作:玩家%d操作:%s,data = 0x%02x,发送SUB_S_OPERATE_RESULT;\n",wTargetUser,tmmpstr,cbOperateCard);
				//效验动作
				bool bAroseAction=false;
				//发送扑克
				if (bAroseAction==false)
				{
					m_bGangCount++;
					m_bUserGangCount[wTargetUser]++;
					if (HasQiangGang(wTargetUser, cbOperateCode, cbOperateCard,bMingGang) == true)
					{
						//printf("用户主动进入操作补杠:玩家%d操作补杠,被抢杠;\n",wTargetUser);
						m_bLastGangByte = bMingGang;
						if (bMingGang == GANG_AN)
						{
							m_AllAnGangTime[wTargetUser]--;
							for (int i=0;i<GAME_PLAYER;i++)
							{
								if (wTargetUser==i)
								{
									m_AnGangScore[i] -=6*m_RoomBasicScore;
								}
								else
								{
									m_AnGangScore[i] +=2*m_RoomBasicScore;
								}
							}
						}
						else if(bMingGang == GANG_MING)
						{
							m_AllMingGangTime[wTargetUser]--;
							for (int i=0;i<GAME_PLAYER;i++)
							{
								if (wTargetUser==i)
								{
									m_MingGangScore[i] -=3*m_RoomBasicScore;
								}
								else
								{
									m_MingGangScore[i]+=1*m_RoomBasicScore;
								}
							}
						}
						return true;
					}
					//TaskGangType(wTargetUser,m_bUserGangCount[wTargetUser]);
					m_cbQiangGangCardData = 0;						//抢杠的牌
					m_cbQiangGangUserID = INVALID_CHAIR;			//被抢杠的人
					m_cbQiangGangOpterate = 0;
					DispatchCardData(wTargetUser, false);
					CString strFile,strTemp;
					strFile.Format("log\\scnjmj.log");
					strTemp.Format(" 玩家自摸补杠操作4783发牌 = %d",m_wResumeUser);
					WriteLog(strFile,strTemp);
				}
				//牌局
				TCHAR tcTemp[30];
				_stprintf(tcTemp,"%d,8,%02X;",wTargetUser,cbOperateCard);
				_tcscat(m_tcRecord,tcTemp);
				return true;
			}
		}
		return true;
	}
	
	return false;
}

//发送操作
bool CTableFrameSink::SendOperateNotify()
{
	//发送提示
	for (WORD i=0;i<m_wPlayerCount;i++)
	{
		//如果自己的话不广播
		if ((m_wCurrentUser == INVALID_CHAIR) || (m_cbUserAction[i]!=WIK_NULL))
		{
			//构造数据	
			CMD_S_OperateNotify OperateNotify;
			OperateNotify.wResumeUser=m_wResumeUser;
			OperateNotify.cbActionCard=m_cbProvideCard;
			OperateNotify.cbActionMask=m_cbUserAction[i];
			if (m_cbProvideCard==0)
			{
				 continue;
			}
			//OperateNotify.m_bQiangGang = false;
			//添加抢杠
			if (m_bQiangGang && m_cbUserAction[i]!=WIK_NULL)
			{
				//OperateNotify.cbActionMask|=WIK_QIANG_GANG;
				OperateNotify.m_bQiangGang = m_bQiangGang;
				OperateNotify.m_bQiangActionMask = OperateNotify.cbActionMask;
			}
			if(m_bQiangGang==false)
			{
				OperateNotify.m_bQiangGang = false;
				OperateNotify.m_bQiangActionMask = WIK_NULL;
			}
			
			CString strFile,strTemp;
			strFile.Format("log\\CurrentUser.log");
			strTemp.Format("into %d %d %d SendOperateNotify",m_wResumeUser,m_cbProvideCard,m_cbUserAction[i]);
			if (m_cbUserAction[i]!=WIK_NULL)
			{
				strTemp = getCString(m_cbUserAction[i]);
				//printf("SendOperateNotify:玩家%d可操作:%s \n",i,strTemp);
			}
			strTemp.Format("into %d %d %d SendOperateNotify",m_wResumeUser,m_cbProvideCard,m_cbUserAction[i]);
			//发送数据
			m_pITableFrame->SendTableData(i,SUB_S_OPERATE_NOTIFY,&OperateNotify,sizeof(OperateNotify));
			m_pITableFrame->SendLookonData(i,SUB_S_OPERATE_NOTIFY,&OperateNotify,sizeof(OperateNotify));
			if (i==m_wPlayerCount-1)
			{
				OperateNotify.m_bQiangGang = false;
				OperateNotify.m_bQiangActionMask = WIK_NULL;
			}
			CMylogFile::Instance().WriteLogFmt(m_bServerTableID,"[OperateNotify]:Player=%s|ActionCard=%s|ActionMask=%s", GetPlayerName(m_wResumeUser).GetBuffer(0), 
				m_GameLogic.GetCardName(OperateNotify.cbActionCard).GetBuffer(0), 
				m_GameLogic.GetActionName(OperateNotify.cbActionMask).GetBuffer(0));
		}
	}

	memset(&m_opterPassTimeArr,PLAYER_TIMER_OPT_NULL,sizeof(m_opterPassTimeArr));
	for (WORD i=0;i<m_wPlayerCount;i++)
	{
		//自动托管
		if (m_bAutoStustee[i] == true && m_cbUserAction[i] != WIK_NULL)
		{
			//m_opterPassTimeArr[i] = 2;
			if (m_pGameServiceOption->wGameZoneType==em_zoneType_zhuangJin)
			{
				m_opterPassTimeArr[i] = TIME_OPERATE_CARD_ZIJIAN;
			} 
			else
			{
				m_opterPassTimeArr[i] = 2;
			}
		}
		//心跳时间
		else if (m_cbUserAction[i] != WIK_NULL)
		{
			if (m_pGameServiceOption->wGameZoneType==em_zoneType_zhuangJin)
			{
				m_opterPassTimeArr[i] = TIME_OPERATE_CARD_ZIJIAN;
			} 
			else
			{
				m_opterPassTimeArr[i] = TIME_OPERATE_CARD;
			}			
		}
	}
	return true;
}

//发送报听
bool CTableFrameSink::SendBaoTingNotify()
{
	//发送提示
	for (WORD i=0;i<m_wPlayerCount;i++)
	{
		//如果自己的话不广播
		if (m_baoTingstart)
		{
			//构造数据	
			CMD_S_BaoTing OperateBaoTing;
			OperateBaoTing.cbActionMask=m_cbUserAction[i];
			
			if ((m_cbUserAction[i]&WIK_LISTEN)!=0)
			{
				OperateBaoTing.bBaoting = true;
			}
			else
			{
				OperateBaoTing.bBaoting = false;	
			}
						
			CString strFile,strTemp;
			strFile.Format("log\\CurrentUser.log");

			strTemp.Format("into %d %d %d SendBaoTingNotify",m_wResumeUser,m_cbProvideCard,m_cbUserAction[i]);
			//发送数据
			m_pITableFrame->SendTableData(i,SUB_S_BAOTING,&OperateBaoTing,sizeof(OperateBaoTing));
			m_pITableFrame->SendLookonData(i,SUB_S_BAOTING,&OperateBaoTing,sizeof(OperateBaoTing));
			
		}
	}
	return true;
}
//派发庄家最后一个扑克
void CTableFrameSink::DispatchLastCardData()
{
	//保存最后发的牌
	m_cbLastSendCardData = m_cbSendCardData;
	//m_cbCardIndex[m_wBankerUser][m_GameLogic.SwitchToCardIndex(m_cbSendCardData)]++;	
	m_baoTingstart = false;
	m_baoTingend = true;
	//设置变量
	//m_cbProvideCard=0;
	m_cbProvideCard=m_cbSendCardData;
	m_wProvideUser=INVALID_CHAIR;
	m_wCurrentUser=m_wBankerUser;
	//动作分析
	bool bAroseAction=false;
	int k=0;
	for (WORD i=0;i<m_wPlayerCount;i++)
	{
		//庄家判断
		if (i==m_wBankerUser)
		{
			//首次出过牌用户标志
			if (!m_bEnjoinChiPeng[i])
			{
				if (m_bBeginOutCard[i]==0)
				{
					tagGangCardResult GangCardResult;
					m_cbUserAction[i]|=m_GameLogic.AnalyseFirstGangCard(m_cbCardIndex[i],
						m_WeaveItemArray[i],m_cbWeaveItemCount[i],GangCardResult,m_cbQueMen[i]);
				}
				else
				{
					tagGangCardResult GangCardResult;
					m_cbUserAction[i]|=m_GameLogic.AnalyseGangCard(m_cbCardIndex[i],
						m_WeaveItemArray[i],m_cbWeaveItemCount[i],GangCardResult, m_cbQueMen[i],m_cbSendCardData);

				}
			}			
			//胡牌判断
			tagChiHuResult ChiHuResult;
			tagChiHuData tempData = getChiHuData();
			m_cbUserAction[i]|=m_GameLogic.AnalyseChiHuCard(m_cbCardIndex[i],NULL,0,0,0,ChiHuResult,m_cbQueMen[i],tempData);
		}

		////状态设置
		//if ((bAroseAction==false)&&(i!=m_wBankerUser)&&(m_cbUserAction[i]!=WIK_NULL))
		//{
		//	bAroseAction=true;
		//	m_wResumeUser=m_wCurrentUser;
		//	m_wCurrentUser=INVALID_CHAIR;
		//}
	}
	//构造数据
	CMD_S_GameLastCard GameStartLastCard;
	GameStartLastCard.wCurrentUser=m_wCurrentUser;
	for (WORD i=0;i<m_wPlayerCount;i++)
	{
		//设置变量
		GameStartLastCard.cbUserAction=m_cbUserAction[i];
		//m_GameLogic.SwitchToCardData(m_cbCardIndex[i],GameStartLastCard.cbCardData);
		GameStartLastCard.cbCardData = m_cbSendCardData;
		//发送数据
		m_pITableFrame->SendTableData(i,SUB_S_GAME_SEND_LASTCARD,&GameStartLastCard,sizeof(GameStartLastCard));
		m_pITableFrame->SendLookonData(i,SUB_S_GAME_SEND_LASTCARD,&GameStartLastCard,sizeof(GameStartLastCard));
	}

}
//派发扑克
bool CTableFrameSink::DispatchCardData(WORD wCurrentUser, bool bGetHand)
{
	//状态效验
	ASSERT(wCurrentUser!=INVALID_CHAIR);
	if (wCurrentUser==INVALID_CHAIR)
		return false;
	//printf("开始发牌DispatchCardData\n");
	bool b = false;
	m_bIsGangKai = false;
	if (m_pITableFrame!=NULL)
	{
		IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(wCurrentUser);
		if (pServerUserItem!=NULL)
		{
			b = pServerUserItem->IsAndroidUser();
		}
	}		
	if (!b)
	{
		if (!m_GameLogic.IsNeedCard(m_cbCardIndex[wCurrentUser]))
		{
			CString strFile,strTemp;
			strFile.Format("log\\scnjmj.log");
			strTemp.Format(" 玩家%d多发了一张牌", wCurrentUser);
			WriteLog(strFile,strTemp);
			return false;
		}
	}
	
	//丢弃扑克
	if ((m_wOutCardUser!=INVALID_CHAIR)&&(m_cbOutCardData!=0))
	{
		m_cbDiscardCount[m_wOutCardUser]++;
		m_cbDiscardCard[m_wOutCardUser][m_cbDiscardCount[m_wOutCardUser]-1]=m_cbOutCardData;
	}
	m_cbOutCardData=0;
	int count = 0;
	for (int i=0;i<4;i++)
	{
		if (m_bPlayerStatus[i]==false)
		{
			count++;
		}
		m_cbUserAction[i] = WIK_NULL;
		m_cbHupaiIndex[i] = false;
		m_cbHupaiCount = 0;
	}
	//if (m_cbLeftCardCount < (4+m_bGangCount))
	if(m_bEnjoinChiPeng[wCurrentUser])
	{
		m_bLastFourCard = true;
	}
	
	//if (m_cbLeftCardCount <= (m_cbGetFinalyIndex/*+15*/+MAX_REPERTORY-MAX_PLAYCOUNT))
	if (m_cbLeftCardCount <= (m_cbGetFinalyIndex+m_cbZhaMaCount/*+50*/))
	{
		////分张 发牌
		//FengZhang();
		m_wProvideUser=INVALID_CHAIR;
		//printf("流局,游戏结束;\n");
		OnEventGameEnd(m_wProvideUser,NULL,GER_NORMAL);
		return true;
	}
	//BYTE leftCardCount = m_cbLeftCardCount - m_cbGetFinalyIndex;
	//if (leftCardCount==(/*15+*/1))//发最后一张牌
	BYTE leftCardCount = m_cbLeftCardCount - m_cbGetFinalyIndex - m_cbZhaMaCount;
	if (leftCardCount == (m_cbZhaMaCount + 1))//发最后一张牌
	{
		m_bHaidilao = true;
		m_GameLogic.m_bHaidilao = true;
		if (m_bFirstHuUser)
		{
			m_wlastUser = wCurrentUser;
		}		
	}
	m_wCurrentUser=wCurrentUser;

	m_wOutCardUser=INVALID_CHAIR;
	m_bEnjoinChiHu[wCurrentUser]=false;
	//发牌处理
	
	if (m_bSendStatus==true)
	{
		//发送扑克
		m_cbSendCardCount++;
		m_bGetCardHead = bGetHand;
		if (bGetHand)
		{
			m_cbSendCardData=m_cbRepertoryCard[--m_cbLeftCardCount];
			
			m_GameLogic.m_bTianHu = false;
		}
		else
		{
			/*if (m_cbGetFinalyIndex == m_baoPaiCardIndex)
			{
				m_cbGetFinalyIndex++;
			}*/
			m_bIsGangKai = true;
			m_cbSendCardData=m_cbRepertoryCard[m_cbGetFinalyIndex++];
		}
		// 控制发牌
		BYTE cbSendCardData = m_cbSendCardData;
		for (int i = 0; i < MAX_INDEX; ++i)
		{
			m_bEnjoinChiHuIndex[wCurrentUser][i]=false;
			m_bEnjoinPeng[wCurrentUser][i] = false;
		}
		
		bool bChange = false;
		/*bool bAI = m_pITableFrame->GetServerUserItem(wCurrentUser)->IsAndroidUser();
		int Addpercent = 0;
		if(bAI)  Addpercent = 20;*/
		//printf("开始发牌DispatchCardData,控制发牌\n");
		if (m_bNeedWin[wCurrentUser])
		{
			if (m_bEnjoinChiPeng[wCurrentUser]==false)
			{
				int randnum = rand()%100;
				if (randnum<(m_iGoodCardPercent+m_AmendPercent+10))
				{
					if ((m_GameLogic.EstimatePengCard(m_cbCardIndex[wCurrentUser],cbSendCardData,m_cbQueMen[wCurrentUser]) == WIK_NULL) ||
						/*(m_GameLogic.EstimateDuiCard(m_cbCardIndex[wCurrentUser], cbSendCardData,m_cbQueMen[wCurrentUser]) == WIK_NULL) ||*/
						CheckCurrOperate(wCurrentUser,cbSendCardData) == WIK_NULL)
					{			
						BYTE iMaxCard = MAX_INDEX;
						BYTE k =rand()%2;
						if (k==0)
						{
							for (BYTE j=9;j<iMaxCard;j++)
							{
								cbSendCardData = m_GameLogic.SwitchToCardData(j);
								for (BYTE i=m_cbGetFinalyIndex;i<m_cbLeftCardCount;i++)
								{							
									if (m_cbRepertoryCard[i] == cbSendCardData )
									{																		
										if ((CheckCurrOperate(wCurrentUser,cbSendCardData) != WIK_NULL) /*&& (m_lastgoodTime[wCurrentUser]!=2)*/)
										{
											bChange = true;
											m_goodcardTime[wCurrentUser]=2;
											break;
										}
										if (m_bEnjoinChiPeng[wCurrentUser] == false && (m_GameLogic.EstimatePengCard(m_cbCardIndex[wCurrentUser], cbSendCardData,m_cbQueMen[wCurrentUser]) != WIK_NULL)
											/*&&(m_lastgoodTime[wCurrentUser]!=1)*/)
										{
											bChange = true;
											m_goodcardTime[wCurrentUser]=1;
											break;
										}
										if (m_bEnjoinChiPeng[wCurrentUser] == false && (m_GameLogic.EstimateDuiCard(m_cbCardIndex[wCurrentUser], cbSendCardData,1) != WIK_NULL)
											/*&& (m_lastgoodTime[wCurrentUser]!=3)*/)
										{
											bChange = true;
											m_goodcardTime[wCurrentUser]=3;
											break;
										}
									}
								}
								if(bChange) break;
							}
						}
						else if (k==1)
						{
							for (BYTE j=18;j<iMaxCard;j++)
							{
								cbSendCardData = m_GameLogic.SwitchToCardData(j);
								for (BYTE i=m_cbGetFinalyIndex;i<m_cbLeftCardCount;i++)
								{							
									if (m_cbRepertoryCard[i] == cbSendCardData )
									{																		
										if ((CheckCurrOperate(wCurrentUser,cbSendCardData) != WIK_NULL) /*&& (m_lastgoodTime[wCurrentUser]!=2)*/)
										{
											bChange = true;
											m_goodcardTime[wCurrentUser]=2;
											break;
										}
										if (m_bEnjoinChiPeng[wCurrentUser] == false && (m_GameLogic.EstimatePengCard(m_cbCardIndex[wCurrentUser], cbSendCardData,m_cbQueMen[wCurrentUser]) != WIK_NULL)
											/*&&(m_lastgoodTime[wCurrentUser]!=1)*/)
										{
											bChange = true;
											m_goodcardTime[wCurrentUser]=1;
											break;
										}
										if (m_bEnjoinChiPeng[wCurrentUser] == false && (m_GameLogic.EstimateDuiCard(m_cbCardIndex[wCurrentUser], cbSendCardData,1) != WIK_NULL)
											/*&& (m_lastgoodTime[wCurrentUser]!=3)*/)
										{
											bChange = true;
											m_goodcardTime[wCurrentUser]=3;
											break;
										}
									}
								}
								if(bChange) break;
							}
							if (bChange==false)
							{
								for (BYTE j=9;j<18;j++)
								{
									cbSendCardData = m_GameLogic.SwitchToCardData(j);
									for (BYTE i=m_cbGetFinalyIndex;i<m_cbLeftCardCount;i++)
									{							
										if (m_cbRepertoryCard[i] == cbSendCardData )
										{																			
											if ((CheckCurrOperate(wCurrentUser,cbSendCardData) != WIK_NULL) /*&& (m_lastgoodTime[wCurrentUser]!=2)*/)
											{
												bChange = true;
												m_goodcardTime[wCurrentUser]=2;
												break;
											}
											if (m_bEnjoinChiPeng[wCurrentUser] == false && (m_GameLogic.EstimatePengCard(m_cbCardIndex[wCurrentUser], cbSendCardData,m_cbQueMen[wCurrentUser]) != WIK_NULL)
												&&(m_lastgoodTime[wCurrentUser]!=1))
											{
												bChange = true;
												m_goodcardTime[wCurrentUser]=1;
												break;
											}
											if (m_bEnjoinChiPeng[wCurrentUser] == false && (m_GameLogic.EstimateDuiCard(m_cbCardIndex[wCurrentUser], cbSendCardData,1) != WIK_NULL)
												&& (m_lastgoodTime[wCurrentUser]!=3))
											{
												bChange = true;
												m_goodcardTime[wCurrentUser]=3;
												break;
											}
										}
									}
									if(bChange) break;
								}
							}
						}					
					}
				}
				if (bChange)
				{
					for (BYTE i=m_cbGetFinalyIndex;i<m_cbLeftCardCount;i++)
					{
						if (m_cbRepertoryCard[i] == cbSendCardData)
						{
							m_cbRepertoryCard[i] = m_cbSendCardData;
							m_cbSendCardData = cbSendCardData;
							m_lastgoodTime[wCurrentUser]=m_goodcardTime[wCurrentUser];
							break;
						}
					}
				}
			}
			else
			{
				int randnum = rand()%100;
				if (randnum<(m_iGoodCardPercent+m_AmendPercent+10))
				{
					if (CheckCurrOperate(wCurrentUser,cbSendCardData) == WIK_NULL)
					{
						BYTE iMaxCard = MAX_INDEX;
						for (BYTE j=9;j<iMaxCard;j++)
						{
							cbSendCardData = m_GameLogic.SwitchToCardData(j);
							for (BYTE i=m_cbGetFinalyIndex;i<m_cbLeftCardCount;i++)
							{							
								if (m_cbRepertoryCard[i] == cbSendCardData )
								{																		
									if ((CheckCurrOperate(wCurrentUser,cbSendCardData) != WIK_NULL))
									{
										bChange = true;
										break;
									}
								}
							}
							if(bChange) break;
						}
					}
				}
				if (bChange && randnum<(m_iGoodCardPercent+m_AmendPercent+10))
				{
					for (BYTE i=m_cbGetFinalyIndex;i<m_cbLeftCardCount;i++)
					{
						if (m_cbRepertoryCard[i] == cbSendCardData)
						{
							m_cbRepertoryCard[i] = m_cbSendCardData;
							m_cbSendCardData = cbSendCardData;
							m_lastgoodTime[wCurrentUser]=m_goodcardTime[wCurrentUser];
							break;
						}
					}
				}
			}			
		}
		else if (m_bNeedLost[wCurrentUser])
		{
			if (m_GameLogic.EstimatePengCard(m_cbCardIndex[wCurrentUser], cbSendCardData,m_cbQueMen[wCurrentUser]) != WIK_NULL ||
			    m_GameLogic.EstimateDuiCard(m_cbCardIndex[wCurrentUser], cbSendCardData,1) != WIK_NULL ||
				CheckCurrOperate(wCurrentUser, cbSendCardData) != WIK_NULL)
			{
				BYTE iMaxCard = MAX_INDEX;
				for (BYTE j=9;j<iMaxCard;j++)
				{
					cbSendCardData = m_GameLogic.SwitchToCardData(j);
					for (BYTE i=m_cbGetFinalyIndex;i<m_cbLeftCardCount;i++)
					{
						if (m_cbRepertoryCard[i] == cbSendCardData)
						{
							if (m_GameLogic.EstimatePengCard(m_cbCardIndex[wCurrentUser], cbSendCardData,m_cbQueMen[wCurrentUser]) == WIK_NULL &&
								m_GameLogic.EstimateDuiCard(m_cbCardIndex[wCurrentUser], cbSendCardData,1) == WIK_NULL &&
								CheckCurrOperate(wCurrentUser, cbSendCardData) == WIK_NULL)
							{
								bChange = true;
								break;
							}
						}
					}					
					if(bChange) break;
				}				
				if (bChange==false)
				{
					for (BYTE j=9;j<iMaxCard;j++)
					{
						cbSendCardData = m_GameLogic.SwitchToCardData(j);
						for (BYTE i=m_cbGetFinalyIndex;i<m_cbLeftCardCount;i++)
						{
							if (m_cbRepertoryCard[i] == cbSendCardData)
							{
								if (m_GameLogic.EstimatePengCard(m_cbCardIndex[wCurrentUser], cbSendCardData,m_cbQueMen[wCurrentUser]) == WIK_NULL &&
									CheckCurrOperate(wCurrentUser, cbSendCardData) == WIK_NULL)
								{
									bChange = true;
									break;
								}
							}
						}					
						if(bChange) break;
					}
				}
				if (bChange==false)
				{
					for (BYTE j=9;j<iMaxCard;j++)
					{
						cbSendCardData = m_GameLogic.SwitchToCardData(j);
						for (BYTE i=m_cbGetFinalyIndex;i<m_cbLeftCardCount;i++)
						{
							if (m_cbRepertoryCard[i] == cbSendCardData)
							{
								if (m_GameLogic.EstimateDuiCard(m_cbCardIndex[wCurrentUser], cbSendCardData,1) == WIK_NULL &&
									CheckCurrOperate(wCurrentUser, cbSendCardData) == WIK_NULL)
								{
									bChange = true;
									break;
								}
							}
						}					
						if(bChange) break;
					}
				}
				if (bChange==false)
				{
					for (BYTE j=9;j<iMaxCard;j++)
					{
						cbSendCardData = m_GameLogic.SwitchToCardData(j);
						for (BYTE i=m_cbGetFinalyIndex;i<m_cbLeftCardCount;i++)
						{
							if (m_cbRepertoryCard[i] == cbSendCardData)
							{
								if (CheckCurrOperate(wCurrentUser, cbSendCardData) == WIK_NULL)
								{
									bChange = true;
									break;
								}
							}
						}					
						if(bChange) break;
					}
				}
			}
			if (bChange)
			{
				for (BYTE i=m_cbGetFinalyIndex;i<m_cbLeftCardCount;i++)
				{
					if (m_cbRepertoryCard[i] == cbSendCardData)
					{
						m_cbRepertoryCard[i] = m_cbSendCardData;
						m_cbSendCardData = cbSendCardData;
						m_lastgoodTime[wCurrentUser]=m_goodcardTime[wCurrentUser];
						break;
					}
				}
			}
		}
		/*int randnum = rand()%100;
		if (bChange&&(randnum<(m_iGoodCardPercent+m_AmendPercent)))
		{
			for (BYTE i=m_cbGetFinalyIndex;i<m_cbLeftCardCount;i++)
			{
				if (m_cbRepertoryCard[i] == cbSendCardData)
				{
					m_cbRepertoryCard[i] = m_cbSendCardData;
					m_cbSendCardData = cbSendCardData;
					m_lastgoodTime[wCurrentUser]=m_goodcardTime[wCurrentUser];
					break;
				}
			}
		}*/
		//printf("开始发牌DispatchCardData,发牌结束\n");
		m_cbCardIndex[wCurrentUser][m_GameLogic.SwitchToCardIndex(m_cbSendCardData)]++;
		
		//设置变量
		m_wProvideUser=wCurrentUser;
		m_cbProvideCard=m_cbSendCardData;
		////测试
		//CString strFile,strTemp;
		//strFile.Format("log\\CurrentUser.log");
		//strTemp.Format(" OperateSendCard %d table %d\n", wCurrentUser, m_pITableFrame->GetTableID());
		//WriteLog(strFile,strTemp);
		//m_bIsNoHaveQuemen = false;
		//起手杠杠牌判断
		if ((m_bEnjoinChiPeng[wCurrentUser]==false)&&(m_bBeginOutCard[wCurrentUser]==0))
		{
			m_cbUserAction[wCurrentUser] |=m_GameLogic.EstimateChiHu(m_cbCardIndex[wCurrentUser],m_GameLogic.getZhongPaiIndex(m_tZhongPaiData.m_cbCurrentZhongPaiCardData,m_LaiZi));
			tagGangCardResult GangCardResult;
			m_cbUserAction[wCurrentUser]|=m_GameLogic.AnalyseFirstGangCard(m_cbCardIndex[wCurrentUser],
				m_WeaveItemArray[wCurrentUser],m_cbWeaveItemCount[wCurrentUser],GangCardResult,m_cbQueMen[wCurrentUser]);
		}
		//杠牌判断
		if (m_bEnjoinChiPeng[wCurrentUser]==false)
		{
			tagGangCardResult GangCardResult;
			m_cbUserAction[wCurrentUser]|=m_GameLogic.AnalyseGangCard(m_cbCardIndex[wCurrentUser],
				m_WeaveItemArray[wCurrentUser],m_cbWeaveItemCount[wCurrentUser],GangCardResult, m_cbQueMen[m_wCurrentUser],m_cbSendCardData);
		}
		DWORD dwChiHuRight=0;

		//宝胡
		/*if (((m_cbSendCardData==m_cbBaopai)&&m_bEnjoinChiPeng[wCurrentUser]))
		{
			m_cbUserAction[wCurrentUser]|=WIK_BAO_HU;
		}
		else*/
		{
			//胡牌判断
			tagChiHuResult ChiHuResult;
			//防止票胡
			BYTE cbCardIndexTemp[MAX_INDEX];
			CopyMemory(cbCardIndexTemp,m_cbCardIndex[wCurrentUser],sizeof(cbCardIndexTemp));
			cbCardIndexTemp[m_GameLogic.SwitchToCardIndex(m_cbSendCardData)]--;
			//printf("开始发牌DispatchCardData,胡牌判断开始\n");
			tagChiHuData tempData = getChiHuData();
			m_cbUserAction[wCurrentUser]|=m_GameLogic.AnalyseChiHuCard(cbCardIndexTemp,
				m_WeaveItemArray[wCurrentUser],m_cbWeaveItemCount[wCurrentUser],m_cbSendCardData,dwChiHuRight,ChiHuResult,m_cbQueMen[wCurrentUser],tempData);
			//printf("开始发牌DispatchCardData,胡牌判断结束\n");
		}
		//牌局
		TCHAR tcTemp[30];
		_stprintf(tcTemp,"%d,1,%02X;",m_wCurrentUser,m_cbSendCardData);
		_tcscat(m_tcRecord,tcTemp);
		SYSTEMTIME time;
		/*GetLocalTime(&time);
		printf("发牌判断前：%02d-%02d-%02d %02d:%02d:%02d.%03d \n",time.wYear,time.wMonth,time.wDay,time.wHour,time.wMinute,time.wSecond,time.wMilliseconds);
		SetChaTingCard(m_wCurrentUser,true);
		GetLocalTime(&time);
		printf("发牌判断后：%02d-%02d-%02d %02d:%02d:%02d.%03d \n",time.wYear,time.wMonth,time.wDay,time.wHour,time.wMinute,time.wSecond,time.wMilliseconds);*/
		CString str,strtmp;
		str.Format("DispatchCardData:发牌给玩家%d=0x%02x;",m_wCurrentUser,m_cbSendCardData);
		if (m_cbChaTing)
		{		
			str = str + "可胡牌：" ;
			for (int i=0;i<10;i++)
			{
				if (m_ChaTingCardArray.cbCardData[0][i]==0) continue;
				strtmp.Format("0x%02x,",m_ChaTingCardArray.cbCardData[0][i]);
				str = str + strtmp;
			}
		}
		str = str + "\n" ;
		//printf(str);
	}
	if ((m_cbUserAction[wCurrentUser])!=WIK_NULL)
	{
		m_bHasSendHuCard = false;
	}
	//吃碰判断(最后4张牌如果可以胡不做吃碰判断)
	/*if (m_bLastFourCard)
	{
		if ((m_cbUserAction[wCurrentUser]&WIK_CHI_HU)!=WIK_NULL)
		{
			m_cbUserAction[wCurrentUser] = WIK_CHI_HU;
		}
	}*/
	SendCard();
	return true;
}

void CTableFrameSink::SendCard()
{
	//构造数据
	CMD_S_SendCard cSendCard;
	cSendCard.bFengZhang = false;
	cSendCard.wCurrentUser=m_wCurrentUser;
	cSendCard.cbActionMask=m_cbUserAction[m_wCurrentUser];
	cSendCard.cbCardData=(m_bSendStatus==true)?m_cbSendCardData:0x00;
	cSendCard.bGetHead = m_bGetCardHead;
	BYTE leftCardCount = m_cbLeftCardCount - m_cbGetFinalyIndex;
	CString strm;
	strm = getCString(m_cbUserAction[m_wCurrentUser]);
	//printf("SendCard:发牌给玩家%d,data=0x%02x,可操作:%s,剩余%d张牌;\n",m_wCurrentUser,m_cbSendCardData,strm,leftCardCount);
	m_cbLastSendCardData = cSendCard.cbCardData;

	//发送数据
	m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_SEND_CARD,&cSendCard,sizeof(cSendCard));
	m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_SEND_CARD,&cSendCard,sizeof(cSendCard));
	m_bSendStatus=false;
	CMylogFile::Instance().WriteLogFmt(m_bServerTableID,"[SendCard]:Player=%s|ActionMask=%s|CardData=%s", 
		GetPlayerName(m_wCurrentUser).GetBuffer(0), m_GameLogic.GetActionName(cSendCard.cbActionMask).GetBuffer(0), 
		m_GameLogic.GetCardName(cSendCard.cbCardData).GetBuffer(0));
	//时间控制
	memset(&m_opterPassTimeArr,PLAYER_TIMER_OPT_NULL,sizeof(m_opterPassTimeArr));
	if (m_wCurrentUser == INVALID_CHAIR)
	{
		ASSERT(NULL);
	}
	if (m_bAutoStustee[m_wCurrentUser] == true)
	{
		//m_opterPassTimeArr[m_wCurrentUser] = 2;
		if (m_pGameServiceOption->wGameZoneType==em_zoneType_zhuangJin)
		{
			m_opterPassTimeArr[m_wCurrentUser] = TIME_OPERATE_CARD_ZIJIAN;
		} 
		else
		{
			m_opterPassTimeArr[m_wCurrentUser] = 2;
		}
	}
	else
	{
		//m_opterPassTimeArr[m_wCurrentUser] = TIME_OPERATE_CARD;
		if (m_pGameServiceOption->wGameZoneType==em_zoneType_zhuangJin)
		{
			m_opterPassTimeArr[m_wCurrentUser] = TIME_OPERATE_CARD_ZIJIAN;
		} 
		else
		{
			m_opterPassTimeArr[m_wCurrentUser] = TIME_OPERATE_CARD;
		}
	}
}

WORD CTableFrameSink::CheckCurrOperate(WORD wCurrentUser, BYTE cbSendCardData)
{
	m_cbCardIndex[wCurrentUser][m_GameLogic.SwitchToCardIndex(cbSendCardData)]++;

	WORD wRes = CHK_NULL;
		
	//杠牌判断
	if (m_bEnjoinChiPeng[wCurrentUser]==false)
	{
		if (m_cbLeftCardCount > 0)
		{
			tagGangCardResult GangCardResult;
			wRes|=m_GameLogic.AnalyseGangCard(m_cbCardIndex[wCurrentUser],
				m_WeaveItemArray[wCurrentUser],m_cbWeaveItemCount[wCurrentUser],GangCardResult, m_cbQueMen[m_wCurrentUser],m_cbSendCardData);	
		}
	}
	else
	{
		//明杠
		bool hasMingGang = false;
		BYTE cbCardIndexMing = 0;
		for (BYTE i=0;i<m_cbWeaveItemCount[wCurrentUser];i++)
		{
			if (m_WeaveItemArray[wCurrentUser][i].cbWeaveKind==WIK_PENG)
			{
				if (m_cbCardIndex[wCurrentUser][m_GameLogic.SwitchToCardIndex(m_WeaveItemArray[wCurrentUser][i].cbCenterCard)]==1)
				{
					hasMingGang = true;
					cbCardIndexMing = m_GameLogic.SwitchToCardIndex(m_WeaveItemArray[wCurrentUser][i].cbCenterCard);
				}
			}
		}
		BYTE cbCardIndex=m_GameLogic.SwitchToCardIndex(cbSendCardData);
		WORD speGangType = HasSpeGang(wCurrentUser, cbSendCardData);
		bool hasAnGang = false;
		if (m_cbCardIndex[wCurrentUser][cbCardIndex]==4)
		{
			hasAnGang = true;
		}
		if (hasAnGang || speGangType != WIK_NULL || hasMingGang)
		{
			tagChiHuResult ChiHuResult;
			//BYTE cbCardIndexTemp[MAX_INDEX];
			BYTE			cbCardIndexTemp[GAME_PLAYER][MAX_INDEX];	//用户扑克
			CopyMemory(cbCardIndexTemp,m_cbCardIndex,sizeof(cbCardIndexTemp));

			tagWeaveItem	WeaveItemArrayTemp[GAME_PLAYER][4];	//组合扑克
			CopyMemory(WeaveItemArrayTemp,m_WeaveItemArray,sizeof(m_WeaveItemArray));
			BYTE cbWeaveCount = m_cbWeaveItemCount[wCurrentUser];

			if (hasAnGang)
			{
				WeaveItemArrayTemp[wCurrentUser][cbWeaveCount].cbPublicCard=FALSE;
				WeaveItemArrayTemp[wCurrentUser][cbWeaveCount].wProvideUser=wCurrentUser;
				WeaveItemArrayTemp[wCurrentUser][cbWeaveCount].cbWeaveKind=WIK_GANG;
				WeaveItemArrayTemp[wCurrentUser][cbWeaveCount].cbCenterCard=cbSendCardData;
				cbWeaveCount++;
				cbCardIndexTemp[wCurrentUser][cbCardIndex] = 0;
			}
			else if (hasMingGang)
			{
				cbCardIndexTemp[wCurrentUser][cbCardIndexMing] = 0;
			}
			else if (speGangType != WIK_NULL)
			{
				cbCardIndexTemp[wCurrentUser][cbCardIndex]--;
			}
		}
	}

	//牌型权位
	DWORD dwChiHuRight=0;

	{
		//胡牌判断
		tagChiHuResult ChiHuResult;
		//防止票胡
		BYTE cbCardIndexTemp[MAX_INDEX];
		CopyMemory(cbCardIndexTemp,m_cbCardIndex[wCurrentUser],sizeof(cbCardIndexTemp));
		cbCardIndexTemp[m_GameLogic.SwitchToCardIndex(cbSendCardData)]--;
		//  TRACE("Dispatch card analyse:Player=%d\n", wCurrentUser);
		tagChiHuData tempData = getChiHuData();
		wRes|=m_GameLogic.AnalyseChiHuCard(cbCardIndexTemp,
			m_WeaveItemArray[wCurrentUser],m_cbWeaveItemCount[wCurrentUser],cbSendCardData,dwChiHuRight,ChiHuResult, m_cbQueMen[m_wCurrentUser],tempData);
		//  TRACE("Dispatch card analyse end\n");
	}

	if (m_cbCardIndex[wCurrentUser][m_GameLogic.SwitchToCardIndex(cbSendCardData)] > 0)
	{
		m_cbCardIndex[wCurrentUser][m_GameLogic.SwitchToCardIndex(cbSendCardData)]--;
	}
	
	return wRes;
}
//判断是否过水不胡
bool CTableFrameSink::AnalyseChiHuResult(WORD wCurrentUser,WORD wOutCardUser,tagOutCardItem  &w_OutCardItemArray/*,bool w_bChiHuAddFan*/)
{
	bool m_IsCanChihu = false;	

	if (wCurrentUser == (wOutCardUser + 1) % GAME_PLAYER)//上家
	{
		m_IsCanChihu = true;
	}
	else if (wCurrentUser == (wOutCardUser + 2) % GAME_PLAYER)//对家
	{
		if (w_OutCardItemArray.cbIsCanChihu[wCurrentUser][(wOutCardUser + 1) % GAME_PLAYER])
		{
			//是否有加番,即是胡大不胡小
			if((w_OutCardItemArray.cbIsCanChihuFansu[wCurrentUser][wOutCardUser]>w_OutCardItemArray.cbIsCanChihuFansu[wCurrentUser][(wOutCardUser + 1) % GAME_PLAYER]))
				m_IsCanChihu = true;
			else
				m_IsCanChihu = false;
		}
		else
			m_IsCanChihu = true;
	}
	else if (wCurrentUser == (wOutCardUser + 3) % GAME_PLAYER) //下家
	{
		if (w_OutCardItemArray.cbIsCanChihu[wCurrentUser][(wOutCardUser + 1) % GAME_PLAYER] 
		  ||w_OutCardItemArray.cbIsCanChihu[wCurrentUser][(wOutCardUser + 2) % GAME_PLAYER])
		{
			//是否有加番,即是胡大不胡小
			if(((w_OutCardItemArray.cbIsCanChihuFansu[wCurrentUser][wOutCardUser]>w_OutCardItemArray.cbIsCanChihuFansu[wCurrentUser][(wOutCardUser + 1) % GAME_PLAYER])
			  &&(w_OutCardItemArray.cbIsCanChihuFansu[wCurrentUser][wOutCardUser]>w_OutCardItemArray.cbIsCanChihuFansu[wCurrentUser][(wOutCardUser + 2) % GAME_PLAYER])))
				m_IsCanChihu = true;
			else
				m_IsCanChihu = false;
		}
		else
			m_IsCanChihu = true;
	}
	return m_IsCanChihu;
}
void CTableFrameSink::FengZhang()
{
	m_bFengZhang = true;
	m_wCurrentUser = INVALID_CHAIR;

	bool bChiHu = false;
	tagChiHuData tempData = getChiHuData();
	for (WORD i=0;i<m_wPlayerCount;i++)
	{
		if (m_bPlayerStatus[i]==false) continue;
		BYTE sendCard = m_cbRepertoryCard[--m_cbLeftCardCount];
		//判断能否吃胡
		tagChiHuResult ChiHuResult;
		m_cbUserAction[i] = m_GameLogic.AnalyseChiHuCard(m_cbCardIndex[i],m_WeaveItemArray[i],
			m_cbWeaveItemCount[i],sendCard,0,ChiHuResult,m_cbQueMen[i],tempData);

		m_cbCardIndex[i][m_GameLogic.SwitchToCardIndex(sendCard)]++;

		m_cbFengZhangCard[i] = sendCard;
		CMD_S_SendCard SendCard;
		SendCard.wCurrentUser=i;
		SendCard.cbActionMask=m_cbUserAction[i];
		SendCard.cbCardData=sendCard;
		SendCard.bFengZhang = true;
		SendCard.bGetHead = true;

		m_pITableFrame->SendTableData(i,SUB_S_SEND_CARD,&SendCard,sizeof(SendCard));
		if (m_cbUserAction[i] != WIK_NULL)
		{
			m_opterPassTimeArr[i] = TIME_OPERATE_CARD;
			bChiHu = true;
		}
		else
		{
			m_opterPassTimeArr[i] = PLAYER_TIMER_OPT_NULL;
		}
	}
	if (bChiHu == false)
	{
		m_cbChiHuCard=0;
		m_wProvideUser=INVALID_CHAIR;
		OnEventGameEnd(m_wProvideUser,NULL,GER_NORMAL);
	}
	
}

bool CTableFrameSink::HasQiangGang(WORD wChairID, WORD cbOperateCode, BYTE cbOperateCard,BYTE bGangType)
{
	// 暂时不需要抢杠胡（北海麻将）
	return false;
	if (m_bQiangGang == true || m_bQiangGangCancel == true)
	{
		return false;
	}
	m_bQiangGang = false;
	m_cbQiangGangCardData = 0;						//抢杠的牌
	m_cbQiangGangUserID = INVALID_CHAIR;			//被抢杠的人
	m_cbQiangGangOpterate = 0;
	m_bQiangGangHu = false;
	bool bHasNormalGang = false;
	//如果是补杠，不是暗杠
	if ((cbOperateCode&WIK_GANG)!=0)
	{
		BYTE cbCardIndex=m_GameLogic.SwitchToCardIndex(cbOperateCard);
		if (m_cbCardIndex[wChairID][cbCardIndex] != 4)
		{
			bHasNormalGang = true;
		}
	}

	if ((m_bCanBuGang[wChairID] == true && bHasNormalGang) || bGangType == GANG_AN )
	{
		bool bAroseAction=false;

		////用户状态
		//ZeroMemory(m_bResponse,sizeof(m_bResponse));
		//ZeroMemory(m_cbUserAction,sizeof(m_cbUserAction));
		//ZeroMemory(m_cbPerformAction,sizeof(m_cbPerformAction));
		WORD	cbUserActionTemp[GAME_PLAYER];			//用户动作
		ZeroMemory(cbUserActionTemp,sizeof(cbUserActionTemp));

		////动作判断
		
		for (WORD i=0;i<m_wPlayerCount;i++)
		{
			if (wChairID==i || m_bPlayerStatus[i]==false) continue;
			//吃碰判断
			if (m_bEnjoinChiPeng[i]==false && bHasNormalGang == false)
			{
				//碰牌判断
				cbUserActionTemp[i]|=m_GameLogic.EstimatePengCard(m_cbCardIndex[i],cbOperateCard,m_cbQueMen[i]);
				//bAroseAction=true;
			}
			//吃胡判断
			tagChiHuResult ChiHuResult;
			WORD actionTemp = INVALID_WORD;
			//胡牌判断
			if (m_bEnjoinChiHu[i]==false)
			{
				//牌型权位
				DWORD dwChiHuRight=0;

				
				BYTE cbWeaveCount=m_cbWeaveItemCount[i];
				tagChiHuData tempData = getChiHuData();
				actionTemp = m_GameLogic.AnalyseChiHuCard(m_cbCardIndex[i],m_WeaveItemArray[i],cbWeaveCount,cbOperateCard,dwChiHuRight,ChiHuResult,m_cbQueMen[i],tempData);
			}

			//结果判断
			if (actionTemp!=WIK_NULL && ((ChiHuResult.dwChiHuKind & CHK_TENTHREEYAO) != 0 || (ChiHuResult.dwChiHuKind & CHK_TENTHREEYAO) == 0 && bGangType == GANG_MING)) 
			{
				bAroseAction=true;
				cbUserActionTemp[i]|= WIK_CHI_HU;
				if ((actionTemp&WIK_CHI_HU)!=0 && (bGangType == GANG_MING || (ChiHuResult.dwChiHuKind & CHK_TENTHREEYAO) != 0))
				{
					m_bQiangGangHu = true;
				}
			}
		}
		if (bAroseAction == true)
		{
			m_bQiangGang = true;
			m_bQiangGangCancel = false;
			m_cbQiangGangCardData = cbOperateCard;				//抢杠的牌
			m_cbQiangGangUserID = wChairID;						//被抢杠的人
			m_cbQiangGangOpterate = cbOperateCode;
						
			//设置变量
			m_wProvideUser=wChairID;
			m_cbProvideCard=cbOperateCard;
			m_wResumeUser=wChairID;
			m_wCurrentUser=INVALID_CHAIR;

			CopyMemory(m_cbUserAction,cbUserActionTemp,sizeof(cbUserActionTemp));
			//发送提示
			SendOperateNotify();

			return true;
		}
	}
	return false;
}

WORD CTableFrameSink::HasSpeGang(WORD wChairID, BYTE cbOperateCard)
{
	WORD spGangType = WIK_NULL;
	//寻找组合，补杠
	/*for (BYTE i=0;i<m_cbWeaveItemCount[wChairID];i++)
	{
		WORD cbWeaveKind=m_WeaveItemArray[wChairID][i].cbWeaveKind;
		if (cbWeaveKind==WIK_SPE_YAOGANG && 
			(cbOperateCard == 0x01 || cbOperateCard == 0x11 || cbOperateCard == 0x21)
			)
		{
			spGangType = WIK_SPE_YAOGANG;
			break;
		}
		if (cbWeaveKind==WIK_SPE_JIUGANG && 
			(cbOperateCard == 0x09 || cbOperateCard == 0x19 || cbOperateCard == 0x29)
			)
		{
			spGangType = WIK_SPE_JIUGANG;
			break;
		}
		if (cbWeaveKind==WIK_SPE_FENGGANG && 
			(cbOperateCard == 0x31 || cbOperateCard == 0x32 || cbOperateCard == 0x33 || cbOperateCard == 0x34)
			)
		{
			spGangType = WIK_SPE_FENGGANG;
			break;
		}
		if (cbWeaveKind==WIK_SPE_BAIGANG && 
			(cbOperateCard == 0x35 || cbOperateCard == 0x36 || cbOperateCard == 0x37)
			)
		{
			spGangType = WIK_SPE_BAIGANG;
			break;
		}

	}*/
	return spGangType;
}

//响应判断
bool CTableFrameSink::EstimateUserRespond(WORD wCenterUser, BYTE cbCenterCard, enEstimatKind EstimatKind)
{
	//变量定义
	bool bAroseAction=false;

	//用户状态
	ZeroMemory(m_bResponse,sizeof(m_bResponse));
	ZeroMemory(m_cbUserAction,sizeof(m_cbUserAction));
	ZeroMemory(m_cbPerformAction,sizeof(m_cbPerformAction));

	//动作判断
	CString kkf;
	for (WORD i=0;i<m_wPlayerCount;i++)
	{		
		if (wCenterUser==i || m_bPlayerStatus[i]==false) continue;
		kkf.Format("玩家%d判断处理\n",i);
		//出牌类型
		if (EstimatKind==EstimatKind_OutCard)
		{
			//吃碰判断(如果报听了不做吃碰判断)
			//if (m_bLastFourCard==false)
			// 北海麻将不能吃胡
			//if (m_bEnjoinChiHu[i] == false)
			//{
			//	if (wCenterUser != i)
			//	{
			//		DWORD dwChiHuRight=0;
			//		tagChiHuResult ChiHuResult;
			//		BYTE cbWeaveCount=m_cbWeaveItemCount[i];
			//		tagChiHuData tempData = getChiHuData();
			//		m_cbUserAction[i]|=m_GameLogic.AnalyseChiHuCard(m_cbCardIndex[i],m_WeaveItemArray[i],cbWeaveCount,cbCenterCard,dwChiHuRight,ChiHuResult,m_cbQueMen[i],tempData,false);
			//		if ( (m_cbUserAction[i]&WIK_CHI_HU)!=WIK_NULL && (ChiHuResult.dwWinTimes < MAX_CHIHU_PAN_VALUE || m_bQiangGangHu))
			//		{
			//			
			//			m_cbUserAction[i] &= ~WIK_CHI_HU;
			//		}

			//		if (m_bEnjoinChiHuIndex[i][m_GameLogic.SwitchToCardIndex(cbCenterCard)])
			//		{
			//			
			//			m_cbUserAction[i] &= ~WIK_CHI_HU;
			//		}
			//	}
			//}
			if(m_bEnjoinChiPeng[i]==false)
			{
				//碰牌判断
				if (wCenterUser!=i)
				{
					
					m_cbUserAction[i]|=m_GameLogic.EstimatePengCard(m_cbCardIndex[i],cbCenterCard,m_cbQueMen[i]);
					if (m_bEnjoinPeng[i][m_GameLogic.SwitchToCardIndex(cbCenterCard)])
					{
						m_cbUserAction[i] &= ~WIK_PENG;
					}
					if (m_GameLogic.SwitchToCardIndex(cbCenterCard) == m_GameLogic.getZhongPaiIndex(m_tZhongPaiData.m_cbCurrentZhongPaiCardData,m_LaiZi) && m_LaiZi)
					{
						m_cbUserAction[i] &= ~WIK_PENG;
					}
					if (cbCenterCard==0) continue;
				}
				//杠牌判断
				if (wCenterUser!=i) 
				{
					m_cbUserAction[i]|=m_GameLogic.EstimateGangCard(m_cbCardIndex[i],cbCenterCard,m_cbQueMen[i]);
					if (m_GameLogic.SwitchToCardIndex(cbCenterCard) == m_GameLogic.getZhongPaiIndex(m_tZhongPaiData.m_cbCurrentZhongPaiCardData,m_LaiZi) && m_LaiZi)
					{
						m_cbUserAction[i] &= ~WIK_GANG;
					}
				}
			}

			//听牌后 不影响听牌的情况下 可以杠牌
			//if (m_bEnjoinChiPeng[i] == true && wCenterUser!=i)
			//if (m_bEnjoinChiPeng[i] == true)
			//{
			//	
			//	BYTE cbCardIndex=m_GameLogic.SwitchToCardIndex(cbCenterCard);
			//	if (m_cbCardIndex[i][cbCardIndex]==3)
			//	{
			//		tagChiHuResult ChiHuResult;
			//		//BYTE cbCardIndexTemp[MAX_INDEX];
			//		BYTE			cbCardIndexTemp[GAME_PLAYER][MAX_INDEX];	//用户扑克
			//		CopyMemory(cbCardIndexTemp,m_cbCardIndex,sizeof(cbCardIndexTemp));

			//		tagWeaveItem	WeaveItemArrayTemp[GAME_PLAYER][4];	//组合扑克
			//		CopyMemory(WeaveItemArrayTemp,m_WeaveItemArray,sizeof(m_WeaveItemArray));
			//		BYTE cbWeaveCount = m_cbWeaveItemCount[i];
			//		
			//		WeaveItemArrayTemp[i][cbWeaveCount].cbPublicCard=TRUE;
			//		WeaveItemArrayTemp[i][cbWeaveCount].wProvideUser=wCenterUser;
			//		WeaveItemArrayTemp[i][cbWeaveCount].cbWeaveKind=WIK_GANG;
			//		WeaveItemArrayTemp[i][cbWeaveCount].cbCenterCard=cbCenterCard;
			//		cbWeaveCount++;
			//		cbCardIndexTemp[i][cbCardIndex] = 0;
			//			//听牌判断
			//		BYTE cbHuCardKind = CHK_NULL;
			//		BYTE j=0;
			//		for (j=0;j<MAX_INDEX;j++)
			//		{
			//			//胡牌分析
			//			BYTE wChiHuRight=0;
			//			BYTE cbCurrentCard=m_GameLogic.SwitchToCardData(j);
			//			cbHuCardKind=m_GameLogic.AnalyseChiHuCard(cbCardIndexTemp[i],WeaveItemArrayTemp[i],cbWeaveCount,cbCurrentCard,wChiHuRight,ChiHuResult,m_cbQueMen[i]);

			//			//结果判断
			//			if (cbHuCardKind!=CHK_NULL) 
			//			{
			//				m_cbUserAction[i]|=m_GameLogic.EstimateGangCard(m_cbCardIndex[i],cbCenterCard,m_cbQueMen[i]);
			//				break;
			//			}
			//		}
			//	}
			//}
			
		}
		//胡牌判断
		bool m_bChiHuAddFan = false;//吃胡是否有加番
		//if (m_bEnjoinChiHu[i]==false)
		//{
		//	if (wCenterUser!=i && m_wLastOutcardUser != i && m_bPlayerNotHu[i]==false)
		//	{
		//		//牌型权位
		//		DWORD dwChiHuRight=0;
		//		//吃胡判断
		//		tagChiHuResult ChiHuResult;
		//		BYTE cbWeaveCount=m_cbWeaveItemCount[i];
		//		m_cbUserAction[i]|=m_GameLogic.AnalyseChiHuCard(m_cbCardIndex[i],m_WeaveItemArray[i],cbWeaveCount,cbCenterCard,dwChiHuRight,ChiHuResult,m_cbQueMen[i]);
		//		assert(false);
		//		if ((m_cbUserAction[i]&WIK_CHI_HU)!=WIK_NULL && ChiHuResult.dwWinTimes >= MAX_CHIHU_PAN_VALUE)
		//		{
		//			m_OutCardItemArray.cbIsCanChihu[i][wCenterUser] = true;
		//			m_OutCardItemArray.cbIsCanChihuFansu[i][wCenterUser] = ChiHuResult.dwWinTimes;
		//		}
		//		else
		//			m_OutCardItemArray.cbIsCanChihu[i][wCenterUser] = false;
		//		for (int j=0;j<MAX_INDEX;j++)
		//		{
		//			if(m_cbCardIndex[i][j]==0 || cbCenterCard==0) continue;
		//			if (m_cbCardIndex[i][j]==3&&(j==m_GameLogic.SwitchToCardIndex(cbCenterCard))) //有一根
		//			{
		//				//m_bChiHuAddFan = true;
		//				m_OutCardItemArray.cbIsCanChihuFansu[i][wCenterUser]+=1;
		//			}
		//		}
		//	}
		//}
		//结果判断
		if (m_cbUserAction[i]!=WIK_NULL) 
		{			
			//if (m_bGangStatusOutcard)//补杠后出牌
			//{
			//	if ((m_cbUserAction[i]&WIK_CHI_HU)!=WIK_NULL)//杠上炮
			//	{
			//		m_bGangShangPao = true;
			//		//m_bChiHuAddFan = true;
			//		m_OutCardItemArray.cbIsCanChihuFansu[i][wCenterUser]+=1;
			//	}
			//}
			////判断是否过水不胡
			//if ((m_cbUserAction[i]&WIK_CHI_HU)!=WIK_NULL)
			//{
			//	if((!AnalyseChiHuResult(i,m_wOutCardUser,m_OutCardItemArray))&&(!m_bLastFourCard))
			//	{
			//		m_cbUserAction[i] &= ~WIK_CHI_HU;
			//	}
			//}
			if (m_cbUserAction[i]!=WIK_NULL)
			{
				bAroseAction=true;
			}
			//(最后4张牌如果可以胡不做吃碰判断)
			//if (m_bEnjoinChiPeng[i])
			//{
			//	if ((m_cbUserAction[i]&WIK_CHI_HU)!=WIK_NULL)
			//	{
			//		m_cbUserAction[i] = WIK_CHI_HU;
			//		bAroseAction=true;
			//	}
			//}
		}
		//printf(kkf);
	}
	//m_bGangStatusOutcard = false;
	//结果处理
	if (bAroseAction==true) 
	{
		//设置变量
		m_wProvideUser=wCenterUser;
		m_cbProvideCard=cbCenterCard;
		m_wResumeUser=m_wCurrentUser;
		m_wCurrentUser=INVALID_CHAIR;
		//printf("结果处理=true;\n");
		if (cbCenterCard==0)
		{
			return false;
		}
		/*CString strFile,strTemp;
		strFile.Format("log\\CurrentUser.log");

		strTemp.Format("into ResumeUser%d CenterUser%d OnEstimateUserRespond",m_wResumeUser,wCenterUser);
		WriteLog(strFile, strTemp);*/
		//发送提示
		SendOperateNotify();
		//printf("发送结果处理通知\n");
		return true;
	}
	else if (EstimatKind==EstimatKind_OutCard)
	{
		m_bGangStatusOutcard = false;
	}
	return false;
}
//宝牌设定
void CTableFrameSink::Baopai(BYTE cIndex, BYTE addCard)
{
	if (cIndex>=12)
	{
		return;
	}
	BYTE cbIndex= cIndex;
	BYTE cbCard=m_cbRepertoryCard[cbIndex];
	cbIndex++;
	DWORD dwCount=0;

	if (addCard!= 0 && m_cbOutCardData == cbCard)
	{
		dwCount++;
	}
	for (int i=0;i<m_wPlayerCount;i++)
	{
		for (int j =0; j<m_cbDiscardCount[i];j++)
		{
			if (m_cbDiscardCard[i][j]==cbCard)
			{
				dwCount++;
			}
			for (int k=0;k<4;k++)
			{
				if ((m_WeaveItemArray[i][k].cbWeaveKind==WIK_LEFT)&&(m_WeaveItemArray[i][k].cbCenterCard==cbCard||(m_WeaveItemArray[i][k].cbCenterCard+2)==cbCard||(m_WeaveItemArray[i][k].cbCenterCard+1)==cbCard))
				{
					dwCount++;
				}
				if ((m_WeaveItemArray[i][k].cbWeaveKind==WIK_RIGHT)&&(m_WeaveItemArray[i][k].cbCenterCard==cbCard||(m_WeaveItemArray[i][k].cbCenterCard-1)==cbCard||(m_WeaveItemArray[i][k].cbCenterCard-2)==cbCard))
				{
					dwCount++;
				}
				if ((m_WeaveItemArray[i][k].cbWeaveKind==WIK_CENTER)&&(m_WeaveItemArray[i][k].cbCenterCard==cbCard||(m_WeaveItemArray[i][k].cbCenterCard-1)==cbCard||(m_WeaveItemArray[i][k].cbCenterCard+1)==cbCard))
				{
					dwCount++;
				}
				if ((m_WeaveItemArray[i][k].cbWeaveKind==WIK_PENG)&&(m_WeaveItemArray[i][k].cbCenterCard==cbCard))
				{
					dwCount=3;
				}
				if ((m_WeaveItemArray[i][k].cbWeaveKind==WIK_GANG)&&(m_WeaveItemArray[i][k].cbCenterCard==cbCard))
				{
					dwCount=4;
				}
				/*if (m_WeaveItemArray[i][k].cbWeaveKind==WIK_SPE_YAOGANG||m_WeaveItemArray[i][k].cbWeaveKind==WIK_SPE_FENGGANG||m_WeaveItemArray[i][k].cbWeaveKind==WIK_SPE_JIUGANG||m_WeaveItemArray[i][k].cbWeaveKind==WIK_SPE_BAIGANG)
				{
					if (cbCard==0x01||cbCard==0x09||cbCard==0x31||cbCard==0x35)
					{
						for (int l = 0; l<m_WeaveItemArray[i][k].cbCardIndex[0];l++)
						{
							dwCount++;
						}
					}
					if (cbCard==0x11||cbCard==0x19||cbCard==0x32||cbCard==0x36)
					{
						for (int l = 0; l<m_WeaveItemArray[i][k].cbCardIndex[1];l++)
						{
							dwCount++;
						}
					}
					if (cbCard==0x21||cbCard==0x29||cbCard==0x33||cbCard==0x37)
					{
						for (int l = 0; l<m_WeaveItemArray[i][k].cbCardIndex[2];l++)
						{
							dwCount++;
						}
					}
					if (cbCard==0x34)
					{
						for (int l = 0; l<m_WeaveItemArray[i][k].cbCardIndex[3];l++)
						{
							dwCount++;
						}
					}
				}*/
			}
		}
	}
	if (dwCount>=3)
		Baopai(cbIndex);
	else
	{
		m_cbBaopai=cbCard;
	}
}

bool CTableFrameSink::HuanBao1()
{
	if (m_cbBaopai != 0)
	{
		BYTE outCardCount = HasOutCardCout(m_cbBaopai);
		if (m_cbOutCardData == m_cbBaopai)
		{
			outCardCount++;
		}

		//printf("HuanBao1 %d, %d\n", m_cbBaopai, outCardCount);
		//换宝
		if (outCardCount >= 3)
		{
			int beforeBaoPaiIndex = m_baoPaiCardIndex;
			BYTE beforeBaoPai = m_cbBaopai;

			ResetBaoPaiIndexArr(m_cbOutCardData);
			//之前的宝牌放到最后
			if (beforeBaoPaiIndex < m_cbGetFinalyIndex)
			{
				m_cbGetFinalyIndex--;
				m_cbRepertoryCard[m_cbGetFinalyIndex] = beforeBaoPai;
			}
			
			//宝牌放回原位

			//if (m_cbBaopai!=0)
			{

				for (WORD i=0;i<m_wPlayerCount;i++)
				{
					CMD_S_Baopai sBaopai;
					sBaopai.cbBaoCard=m_cbBaopai;
					sBaopai.bFirst = false;
					sBaopai.bChangeBao = true;
					sBaopai.cbRandVal = m_baoPaiRandVal;
					sBaopai.cbBaoPaiCardIndex = m_baoPaiCardIndex;
					sBaopai.bHuangBao = /*m_baoPaiCardIndex == -1?true:*/false;
					if (m_bCanLookBao[i] == true && m_cbBaopai != 0)
					{
						sBaopai.cbBaoCard=m_cbBaopai;
						m_bFirstChangeBao[i] = true;						
					}
					else
					{
						sBaopai.cbBaoCard = 0;
						m_bFirstChangeBao[i] = false;
					}
					m_pITableFrame->SendTableData(i,SUB_S_BAOPAI,&sBaopai,sizeof(sBaopai));


				}
				CMD_S_Baopai sBaopai;
				sBaopai.cbBaoCard=m_cbBaopai;
				sBaopai.bFirst = false;
				sBaopai.bChangeBao = true;
				sBaopai.cbRandVal = m_baoPaiRandVal;
				sBaopai.cbBaoPaiCardIndex = m_baoPaiCardIndex;
				sBaopai.bHuangBao = /*m_baoPaiCardIndex == -1?true:*/false;
				m_pITableFrame->SendLookonData(INVALID_CHAIR,SUB_S_BAOPAI,&sBaopai,sizeof(sBaopai));
				return true;
			}
		}
	}
	return false;
}

void CTableFrameSink::GetBaoPai()
{
	ResetBaoPaiIndexArr();
}

void CTableFrameSink::ResetBaoPaiIndexArr(BYTE addCardData)
{
	int startIndex = int((m_cbGetFinalyIndex + 1) / 2) * 2;
	m_baoPaiStartIndex = startIndex;

	m_baoPaiRandIndexArr.clear();
	int index = m_baoPaiStartIndex;
	for (int i = 0; i < 6; i++)
	{
		BYTE cbCardData = m_cbRepertoryCard[index];
		BYTE outCardCount = HasOutCardCout(cbCardData);
		//计算打出去的牌
		if (addCardData == cbCardData)
		{
			outCardCount++;
		}
		if (outCardCount < 3)
		{
			m_baoPaiRandIndexArr.push_back(index);
		}
		index += 2;
	}
	int randRate = m_baoPaiRandIndexArr.size();
	if (randRate > 0)
	{
		m_baoPaiRandVal = rand() % randRate;
		//m_baoPaiRandVal = 0;
		m_baoPaiCardIndex = m_baoPaiRandIndexArr[m_baoPaiRandVal];
		m_cbBaopai = m_cbRepertoryCard[m_baoPaiCardIndex];

	}
	else		//没有宝牌
	{
		m_cbBaopai = 0;
		m_baoPaiCardIndex = -1;
		m_baoPaiRandVal = 0;
	}
	//printf("ResetBaoPaiIndexArr %d, %d, %d, %d\n", m_cbBaopai, m_baoPaiRandVal, m_baoPaiRandCardIndex, m_baoPaiRandIndexArr.size());
}

int CTableFrameSink::HasOutCardCout(BYTE cbCardData)
{
	DWORD dwCount=0;
	for (int i=0;i<m_wPlayerCount;i++)
	{
		for (int j =0; j<m_cbDiscardCount[i];j++)
		{
			if (m_cbDiscardCard[i][j]==cbCardData)
			{
				dwCount++;
			}
		}
		for (int k=0;k<4;k++)
		{
			if ((m_WeaveItemArray[i][k].cbWeaveKind==WIK_LEFT)&&(m_WeaveItemArray[i][k].cbCenterCard==cbCardData||(m_WeaveItemArray[i][k].cbCenterCard+2)==cbCardData||(m_WeaveItemArray[i][k].cbCenterCard+1)==cbCardData))
			{
				dwCount++;
			}
			if ((m_WeaveItemArray[i][k].cbWeaveKind==WIK_RIGHT)&&(m_WeaveItemArray[i][k].cbCenterCard==cbCardData||(m_WeaveItemArray[i][k].cbCenterCard-1)==cbCardData||(m_WeaveItemArray[i][k].cbCenterCard-2)==cbCardData))
			{
				dwCount++;
			}
			if ((m_WeaveItemArray[i][k].cbWeaveKind==WIK_CENTER)&&(m_WeaveItemArray[i][k].cbCenterCard==cbCardData||(m_WeaveItemArray[i][k].cbCenterCard-1)==cbCardData||(m_WeaveItemArray[i][k].cbCenterCard+1)==cbCardData))
			{
				dwCount++;
			}
			if ((m_WeaveItemArray[i][k].cbWeaveKind==WIK_PENG)&&(m_WeaveItemArray[i][k].cbCenterCard==cbCardData))
			{
				dwCount=3;
			}
			if ((m_WeaveItemArray[i][k].cbWeaveKind==WIK_GANG)&&(m_WeaveItemArray[i][k].cbCenterCard==cbCardData) && m_WeaveItemArray[i][k].cbPublicCard)
			{
				dwCount=4;
			}
			/*if (m_WeaveItemArray[i][k].cbWeaveKind==WIK_SPE_YAOGANG||m_WeaveItemArray[i][k].cbWeaveKind==WIK_SPE_FENGGANG||m_WeaveItemArray[i][k].cbWeaveKind==WIK_SPE_JIUGANG||m_WeaveItemArray[i][k].cbWeaveKind==WIK_SPE_BAIGANG)
			{
				if (cbCardData==0x01||cbCardData==0x09||cbCardData==0x31||cbCardData==0x35)
				{
					for (int l = 0; l<m_WeaveItemArray[i][k].cbCardIndex[0];l++)
					{
						dwCount++;
					}
				}
				if (cbCardData==0x11||cbCardData==0x19||cbCardData==0x32||cbCardData==0x36)
				{
					for (int l = 0; l<m_WeaveItemArray[i][k].cbCardIndex[1];l++)
					{
						dwCount++;
					}
				}
				if (cbCardData==0x21||cbCardData==0x29||cbCardData==0x33||cbCardData==0x37)
				{
					for (int l = 0; l<m_WeaveItemArray[i][k].cbCardIndex[2];l++)
					{
						dwCount++;
					}
				}
				if (cbCardData==0x34)
				{
					for (int l = 0; l<m_WeaveItemArray[i][k].cbCardIndex[3];l++)
					{
						dwCount++;
					}
				}
			}*/
		}
	}
	return dwCount;
}

//混乱分发扑克
void CTableFrameSink::RandCardData(BYTE cbCardData[])
{
	CString str = "";

	BYTE nTestCardCnt[GAME_PLAYER];
	BYTE byTmpCardIndex[GAME_PLAYER][MAX_COUNT];	// 用户扑克
	ZeroMemory(nTestCardCnt, sizeof(nTestCardCnt));
	ZeroMemory(byTmpCardIndex, sizeof(byTmpCardIndex));
	BYTE cbCards[MAX_REPERTORY];
	m_GameLogic.CopyCardDataArray(cbCards);

	int nGoodCard = m_iGoodCardPercent+m_AmendPercent/*m_pGameServiceOption->iGoodCardPercent*/;		//	好牌概率
	int nRandCnt = rand()%100;		//	rand() % 4 + 96;	
	int nProCtl[6] = {70, 90, 95, 98, 99, 100};
	TCHAR tcName[6][8] = {"三组", "二组", "四组", "五对", "四对", "六对"};
	//混乱扑克
	m_GameLogic.RandCardData(cbCardData, MAX_REPERTORY/*,cbAndroidCard,cbAndroidCardCount*/);
	m_cbLeftCardCount = MAX_REPERTORY;
	//////////////////////////////////////////////////////////////////////////	AI好牌机制	151022 wu
	if (nGoodCard > rand() % 100)
	{
		WORD wChair = 0xff;
//		for (int i=0; i<GAME_PLAYER; i++)
//		{
//			IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(i);
//			if (pServerUserItem != NULL)
//			{
//#if ERMM_TEST
//				int iSet = GetPrivateProfileInt(TEXT("AddTestCard"),TEXT("AiSetGoodCard"), 0, "test\\ermjtest.ini");
//				if (iSet)
//				{
//					if		(iSet == 2)		nRandCnt = nProCtl[1] - 1;	//	取两组
//					else if (iSet == 3)		nRandCnt = nProCtl[0] - 1;	//	取三组
//					else if (iSet == 4)		nRandCnt = nProCtl[2] - 1;	//	取四组
//					else if (iSet == 14)	nRandCnt = nProCtl[4] - 1;	//	四对
//					else if (iSet == 15)	nRandCnt = nProCtl[3] - 1;	//	五对
//					else if (iSet == 16)	nRandCnt = nProCtl[5] - 1;	//	六对
//				}
//				if (!pServerUserItem->IsAndroidUser()) { wChair = i; break; }
//#else
//				if (pServerUserItem->IsAndroidUser()) { wChair = i; break; }
//#endif
//			}
//		}
		//查找有几个机器人
		BYTE cbAICount=0,cbPosition=0,m_cbAI[4];
		ZeroMemory(m_cbAI,sizeof(m_cbAI));
		for (int i=0;i<GAME_PLAYER;i++)
		{
			IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(i);
			ASSERT(pServerUserItem);
			bool b=false;
			if (pServerUserItem!=NULL)
			{
				b=pServerUserItem->IsAndroidUser();
			}
			if (b)
			{
				m_cbAI[cbAICount++] = i;
			}
		}
		//选择哪个AI
		if (cbAICount!=0)
		{
			cbPosition = rand()%cbAICount;
			wChair = m_cbAI[cbPosition];
		}	

		int nType = 2;
		if		(nRandCnt < nProCtl[0]) nType = 3;		//	"三组", 3
		else if (nRandCnt < nProCtl[1]) nType = 2;		//	"二组",	2
		else if (nRandCnt < nProCtl[2]) nType = 4;		//	"四组",	4
		else if (nRandCnt < nProCtl[3]) nType = 15;		//	"五对",	15
		else if (nRandCnt < nProCtl[4]) nType = 14;		//	"四对",	14
		else if (nRandCnt < nProCtl[5]) nType = 16;		//	"六对",	16
		if(wChair!=0xff)
			nTestCardCnt[wChair] = m_GameLogic.GetWeaveItem( byTmpCardIndex[wChair], nType, cbCards, true);
	}
	//	修改混乱扑克
	for (int i=0; i<GAME_PLAYER; i++)
	{
		if (nTestCardCnt[i])
		{
			RemakeRandCardDatas(cbCardData, byTmpCardIndex[i], m_cbLeftCardCount);
		}
	}
	//#if ERMM_TEST
	//	CopyMemory(m_cbRepertoryCard, cbCardData, sizeof(m_cbRepertoryCard));
	//#endif


	//分发扑克
	for (WORD i=0;i<GAME_PLAYER;i++)
	{
		//IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(i);
		//ASSERT(pServerUserItem);
		// 		if (i==dwIndex)
		// 			continue;
		//if (DEF_TEST)
		//{
		//	bool b = !pServerUserItem->IsAndroidUser();
		//	if (b)
		//	{
		//		continue;
		//	}
		//}
		if (nTestCardCnt[i])
		{
			int nLeftCnt = (MAX_COUNT-1) - nTestCardCnt[i];
			m_cbLeftCardCount -= nLeftCnt;
			CopyMemory(&byTmpCardIndex[i][nTestCardCnt[i]], &cbCardData[m_cbLeftCardCount], sizeof(BYTE)*nLeftCnt);
			m_GameLogic.SwitchToCardIndex(byTmpCardIndex[i], (MAX_COUNT-1), m_cbCardIndex[i]);
#if ERMM_TEST
			CMD_S_TestData tTestData;
			tTestData.nGoodCardPer = nGoodCard;
			tTestData.nRandCnt = nRandCnt;
			tTestData.nTestCardCnt = nTestCardCnt[i];
			CopyMemory(&tTestData.byCardIndex, byTmpCardIndex[i], sizeof(tTestData.byCardIndex));
			m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_TEST_DATA, &tTestData, sizeof(tTestData));
#endif
			//	写log
			/*bool bWrite = CMylogFile::Instance().GetWriteLog();
			if (!bWrite) CMylogFile::Instance().SetServerID(m_pGameServiceOption->wServerID, true, (TCHAR*)m_pGameServiceOption->szGameRoomName);
			IServerUserItem *pServerUserItem = m_pITableFrame->GetServerUserItem(i);
			CMylogFile::Instance().WriteLogFmt("A = %s, wChair = %d, nGood = %d, nCnt = %d, nRand = %d(%s), Cards = %02x,%02x,%02x,%02x,%02x,%02x, %02x,%02x,%02x,%02x,%02x,%02x,",
				pServerUserItem->GetAccounts(), i, nGoodCard, nTestCardCnt[i], nRandCnt,
				(nRandCnt < nProCtl[0]) ? tcName[0] : 
				((nRandCnt < nProCtl[1]) ? tcName[1] : 
				((nRandCnt < nProCtl[2]) ? tcName[2] : 
				((nRandCnt < nProCtl[3]) ? tcName[3] : 
				((nRandCnt < nProCtl[4]) ? tcName[4] :
				tcName[5])))),
				byTmpCardIndex[i][0], byTmpCardIndex[i][1], byTmpCardIndex[i][2], byTmpCardIndex[i][3], byTmpCardIndex[i][4], byTmpCardIndex[i][5], 
				byTmpCardIndex[i][6], byTmpCardIndex[i][7], byTmpCardIndex[i][8], byTmpCardIndex[i][9], byTmpCardIndex[i][10], byTmpCardIndex[i][11],0,0,0,0);
			if (!bWrite) CMylogFile::Instance().SetWriteLog(false);*/
		}
		else
		{
			m_cbLeftCardCount-=(MAX_COUNT-1);
			m_GameLogic.SwitchToCardIndex(&cbCardData[m_cbLeftCardCount],MAX_COUNT-1,m_cbCardIndex[i]);
		}
	}
}
//混乱分发扑克
//void CTableFrameSink::RandCardData(BYTE cbCardData[])
//{
//	//处理机器人
//	BYTE cbRandCard=MAKEWORD(rand()%40,rand()%40);
//	//czm test 获得哪个底牌
//	if (DEF_TEST)//DEF_TEST
//	{
//		cbRandCard = 0;
//		//cbRandCard %= 5;
//	}
//	//end
//	DWORD dwIndex=-1;
//	if (m_bGoodCard)
//	{
//		BYTE cbAndroidCard[13];
//		ZeroMemory(cbAndroidCard,sizeof(cbAndroidCard));
//		BYTE cbAndroidCardCount=0;
//		m_GameLogic.GetAndroidCard(cbRandCard,cbAndroidCard,13);
//		//查找有几个机器人
//		BYTE cbAICount=0,cbPosition=0,AIIndex=0,m_cbAI[4];
//		ZeroMemory(m_cbAI,sizeof(m_cbAI));
//		for (int i=0;i<GAME_PLAYER;i++)
//		{
//			IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(i);
//			ASSERT(pServerUserItem);
//			bool b=pServerUserItem->IsAndroidUser();
//			if (b)
//			{
//				m_cbAI[cbAICount++] = i;
//			}
//		}
//		//选择哪个AI
//		if (cbAICount!=0)
//			cbPosition = rand()%cbAICount;
//		else
//			cbPosition = 0;
//
//		AIIndex = m_cbAI[cbPosition];
//		//查找机器人
//		for (int i=0;i<GAME_PLAYER;i++)
//		{
//			IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(i);
//			ASSERT(pServerUserItem);
//			bool b=pServerUserItem->IsAndroidUser();
//			if( !b || i!=AIIndex)  continue;
//			if (DEF_TEST)//DEF_TEST
//			{
//				b = (i==m_wBankerUser)?true:false;
//			}
//			if (b)
//			{
//				m_cbLeftCardCount-=(MAX_COUNT-1);
//				cbAndroidCardCount=MAX_COUNT-1;
//				m_GameLogic.SwitchToCardIndex(cbAndroidCard,MAX_COUNT-1,m_cbCardIndex[i]);
//				dwIndex=i;
//				if (DEF_TEST)
//				{
//					continue;
//				}
//				break;
//			}
//		}
//		//混乱扑克
//		m_GameLogic.RandCardData(cbCardData,MAX_REPERTORY,cbAndroidCard,cbAndroidCardCount);
//	} 
//	else
//	{
//		//混乱扑克
//		m_GameLogic.RandCardData(cbCardData,MAX_REPERTORY);
//	}
//
//	//分发扑克
//	for (WORD i=0;i<m_wPlayerCount;i++)
//	{
//		if (m_bGoodCard)
//		{
//			IServerUserItem *pServerUserItem=m_pITableFrame->GetServerUserItem(i);
//			ASSERT(pServerUserItem);
//			if (i==dwIndex)
//				continue;			
//			if (DEF_TEST)
//			{
//				bool b = !pServerUserItem->IsAndroidUser();
//				if (b)
//				{
//					continue;
//				}
//			}
//		}
//		m_cbLeftCardCount-=(MAX_COUNT-1);
//		m_GameLogic.SwitchToCardIndex(&cbCardData[m_cbLeftCardCount],MAX_COUNT-1,m_cbCardIndex[i]);
//	}
//}

//制造AI好牌
void CTableFrameSink::GetGoodCardData(BYTE cbCardData[])
{
	BYTE nTestCardCnt=0;
	BYTE byTmpCardIndex[MAX_COUNT];	// 用户扑克
	ZeroMemory(byTmpCardIndex, sizeof(byTmpCardIndex));
	BYTE cbCards[MAX_REPERTORY];
	ZeroMemory(cbCards, sizeof(cbCards));
	m_GameLogic.CopyCardDataArray(cbCards);

	int nGoodCard = m_iGoodCardPercent;		//	好牌概率
	int nRandCnt = rand()%100;		//	rand() % 4 + 96;	
	int nProCtl[6] = {70, 90, 95, 98, 99, 100};
	TCHAR tcName[6][8] = {"三组", "二组", "四组", "五对", "四对", "六对"};
	//混乱扑克
	m_GameLogic.RandCardData(cbCardData, MAX_REPERTORY/*,cbAndroidCard,cbAndroidCardCount*/);
	m_cbLeftCardCount = MAX_REPERTORY;
	int nType = 2;
	if		(nRandCnt < nProCtl[0]) nType = 3;		//	"三组", 
	else if (nRandCnt < nProCtl[1]) nType = 2;		//	"二组",
	else if (nRandCnt < nProCtl[2]) nType = 4;		//	"四组",
	else if (nRandCnt < nProCtl[3]) nType = 15;		//	"五对",
	else if (nRandCnt < nProCtl[4]) nType = 14;		//	"四对",
	else if (nRandCnt < nProCtl[5]) nType = 16;		//	"六对",
	nTestCardCnt = m_GameLogic.GetWeaveItem( byTmpCardIndex, nType, cbCards, true);

	if (nTestCardCnt)
	{
		RemakeRandCardDatas(cbCardData, byTmpCardIndex, m_cbLeftCardCount);
	}
	//// 设置扑克
	//BYTE cbCardData[MAX_COUNT];
	//BYTE cbCardCount = m_GameLogic.SwitchToCardData(m_cbCardIndex, cbCardData);
}
//混乱分发扑克
void CTableFrameSink::RemakeRandCardData(BYTE cbCardData[MAX_REPERTORY], BYTE byCardIndex, BYTE &cbLeftCnt)
{
	if ((byCardIndex == 0) || (byCardIndex > 0x37)) return;
	bool bFind = false;
	for (int j = 0; j < cbLeftCnt; j ++)	// 去掉风牌
	{
		if (bFind)
		{
			cbCardData[j] = cbCardData[j + 1];
		}
		else
		{
			if (cbCardData[j] == byCardIndex)
			{
				bFind = true;
				cbCardData[j] = cbCardData[j + 1];
			}
		}
	}
	cbLeftCnt --;
	cbCardData[cbLeftCnt] = byCardIndex;
}

//混乱分发扑克
void CTableFrameSink::RemakeRandCardDatas(BYTE cbCardData[MAX_REPERTORY], BYTE byCardIndex[MAX_COUNT], BYTE &cbLeftCnt)
{
	int i = MAX_COUNT - 1;
	while (i --)
	{
		RemakeRandCardData(cbCardData, byCardIndex[i], cbLeftCnt);
	}
}
//	三家闭
bool CTableFrameSink::bSanJiaBi(WORD wChairID)
{
	bool isSanJiaBi=true;
	for (int i = 0;i<GAME_PLAYER;i++)
	{
		if (i==wChairID)
		{
			continue;
		}
		bool bMenQin = IsMenQing(i);
		if (bMenQin == false)
		{
			return false;
		}
	}
	return isSanJiaBi;
}
//是否门清(闭门)
bool CTableFrameSink::IsMenQing(WORD wChairID)
{
	bool bMenQin = true;
	for (int i = 0; i < m_cbWeaveItemCount[wChairID]; i++)
	{
		if (m_WeaveItemArray[wChairID][i].cbWeaveKind != WIK_GANG || m_WeaveItemArray[wChairID][i].cbPublicCard == true)
		{
			bMenQin = false;
			break;
		}
	}
	return bMenQin;
}
//任务胡牌类型
void CTableFrameSink::TaskHuType(WORD wChairID,WORD cbOperateCode)
{
	//m_pITableFrame->GetServerUserItem(wChairID)->SetMissionCardTypeVal(1);
	//for (int i=0;i<8;i++)
	//{
	//	/*if (cbOperateCode&CHK_ZHUANG_HU)
	//	{
	//		m_pITableFrame->GetServerUserItem(wChairID)->SetMissionCardTypeVal(7);
	//	}*/
	//	/*if (cbOperateCode&CHK_LI_HU)
	//	{
	//		m_pITableFrame->GetServerUserItem(wChairID)->SetMissionCardTypeVal(6);
	//	}*/	
	//	if (cbOperateCode&CHK_ZI_MO)
	//	{
	//		m_pITableFrame->GetServerUserItem(wChairID)->SetMissionCardTypeVal(5);
	//	}
	//	/*if (cbOperateCode&CHK_JIA_HU)
	//	{
	//		m_pITableFrame->GetServerUserItem(wChairID)->SetMissionCardTypeVal(4);
	//	}*/
	//	if (cbOperateCode&CHK_PENPEN_HU)
	//	{
	//		m_pITableFrame->GetServerUserItem(wChairID)->SetMissionCardTypeVal(3);
	//	}
	//	
	//	/*if (cbOperateCode&WIK_DUI_BAO)
	//	{
	//		m_pITableFrame->GetServerUserItem(wChairID)->SetMissionCardTypeVal(2);
	//	}*/
	//	
	//}
}
//任务条件
void CTableFrameSink::TaskType(WORD wChairID,WORD cbOperateCode)
{
	/*if (cbOperateCode&WIK_SPE_YAOGANG)
	{
		m_pITableFrame->GetServerUserItem(wChairID)->SetMissionCardTypeVal(9);
		return;
	}
	if (cbOperateCode&WIK_SPE_JIUGANG)
	{
		m_pITableFrame->GetServerUserItem(wChairID)->SetMissionCardTypeVal(10);
		return;
	}
	if (cbOperateCode&WIK_SPE_FENGGANG)
	{
		m_pITableFrame->GetServerUserItem(wChairID)->SetMissionCardTypeVal(11);
		return;
	}
	if (cbOperateCode&WIK_SPE_BAIGANG)
	{
		m_pITableFrame->GetServerUserItem(wChairID)->SetMissionCardTypeVal(12);
		return;
	}*/
	/*if (cbOperateCode&WIK_GANG)
	{
		m_pITableFrame->GetServerUserItem(wChairID)->SetMissionCardTypeVal(15);
		return;
	}*/
}
//任务条件
void CTableFrameSink::TaskGangType(WORD wChairID,WORD dGangCount)
{
	/*switch(dGangCount)
	{
	case 1:
		{
			m_pITableFrame->GetServerUserItem(wChairID)->SetMissionCardTypeVal(13);
		}
		break;
	case 2:
		{
			m_pITableFrame->GetServerUserItem(wChairID)->SetMissionCardTypeVal(14);
		}
		break;
	case 3:
		{
			m_pITableFrame->GetServerUserItem(wChairID)->SetMissionCardTypeVal(8);
		}
		break;
	default:
		break;
	}*/
}

// 赢的用户
int CTableFrameSink::getWinUser()
{
	for (int i = 0; i < GAME_PLAYER; i++)
	{
		if(m_ChiHuResult[i].dwChiHuKind != CHK_NULL)
		{
			return i;
		}
	}

	return INVALID_CHAIR;
}

int CTableFrameSink::AddZhaMaData(BYTE cbCardIndex[MAX_INDEX],int chairId,BYTE cbZhongMa[MAX_ZhaMaNum],bool isOneMa )
{
	int zhongmaCount = 0;
	BYTE cbLeftCardCount = m_cbLeftCardCount;
	BYTE leftcardcount = m_cbLeftCardCount - m_cbGetFinalyIndex;
	m_cbZhaMaCount = GetZhaMaCount();
	if (leftcardcount<m_cbZhaMaCount)
	{
		m_cbZhaMaCount = leftcardcount;
	}
	//胡牌玩家手上是否没有红中，没有就加一个码
	//if (bhaveHongzhong==false)
	//{		 
	//	if ((leftcardcount-m_cbZhaMaCount)>0)
	//	{
	//		m_cbZhaMaCount+=1;
	//	}
	//}
	// 获取赢的桌子号

	// 奖励编号
	int winIndex = ((m_wBankerUser + GAME_PLAYER) - chairId)%GAME_PLAYER;
	CString str,StrTmp;
	str.Format("扎码个数%d个:",m_cbZhaMaCount);
	for (int i=0;i<m_cbZhaMaCount;i++)
	{
		m_cbZhaMaCardData[i] = m_cbRepertoryCard[--cbLeftCardCount];
		StrTmp.Format("0x%02x,",m_cbZhaMaCardData[i]);
		str += StrTmp;
		BYTE cbValue = (m_cbZhaMaCardData[i]&MASK_VALUE);
		BYTE cbColor = (m_cbZhaMaCardData[i]&MASK_COLOR) >> 4;
		
		// 字中发白分别对应1~3
		if (cbColor == 3 && cbValue >= 5)
		{
			cbValue = cbValue - 4;
		}
		// 一码全中
		if(isOneMa)
		{
			
			zhongmaCount++;
			m_bZhongZhaMa[i] = true;
			cbZhongMa[i] = true;
			return cbValue;
		}
		bool isZhoneMa = false;
		switch (winIndex)
		{
		// 庄家自己
		case 0:
			{
				if (cbValue==1 || cbValue==5 || cbValue==9)
				{
					isZhoneMa = true;
				}
			}
			break;
		// 下家
		case 1:
			{
				if ( cbValue==2 || cbValue==6)
				{
					isZhoneMa = true;
				}
				break;
			}
		// 对家
		case 2:
			{
				if (cbValue==3 || cbValue==7)
				{
					isZhoneMa = true;
				}
				break;
			}
		// 上家
		case 3:
			{
				if (cbValue==4 || cbValue==8)
				{
					isZhoneMa = true;
				}
				break;
			}
		default:
			break;
		}
		if (isZhoneMa == true)
		{
			zhongmaCount++;
			m_bZhongZhaMa[i] = true;
			cbZhongMa[i] = true;
		}
	}
	
	StrTmp.Format("中码%d个",zhongmaCount);
	str = str + StrTmp + "\n";
	//printf(str);
	return zhongmaCount;
}
void WriteLog(CString strFileName, CString strText)
{
	try
	{
		CTime tm = CTime::GetCurrentTime();
		CString strTime = tm.Format(_T("%Y-%m-%d %H:%M:%S"));
		//BOOL bFull = FALSE;
		CStdioFile file;
		if( file.Open(strFileName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite) != 0)
		{
			file.SeekToEnd();
			file.WriteString(strTime);
			file.WriteString(strText);
			file.WriteString(_T("\n\n"));
			//if(file.GetLength() > 2000000)
			//	bFull = TRUE;
			file.Close();
		}
	}
	catch(...)
	{
	}
}


//增加倍率与比率
WORD CTableFrameSink::GetTaxRation(LONG lScore, DWORD dwBasicScore)
{
	WORD wRation = m_pGameServiceOption->arTaxRation[m_pGameServiceOption->wRationCount-1].dwRation;
	DWORD dwMultiple = lScore / dwBasicScore;
	for (int i=0; i<m_pGameServiceOption->wRationCount; i++)
	{
		if (dwMultiple>=m_pGameServiceOption->arTaxRation[i].dwMin 
			&& dwMultiple<m_pGameServiceOption->arTaxRation[i].dwMax)
		{
			wRation = m_pGameServiceOption->arTaxRation[i].dwRation;
			break;
		}
	}

	return wRation;
}

bool CTableFrameSink::OnActionUserOffLine(WORD wChairID,IServerUserItem * pIServerUserItem)
{
	m_bAutoStustee[wChairID] = true;
	m_bPlayerOffLine[wChairID] = true;
	return true;
}

bool CTableFrameSink::OnActionUserLeft(WORD wChairID, IServerUserItem * pIServerUserItem)
{
	m_bAutoStustee[wChairID] = true;
	m_bPlayerOffLine[wChairID] = true;
	if (m_wCurrentUser == wChairID)
	{
		if (m_bBeginOutCard[wChairID]==0)
		{
			m_opterPassTimeArr[wChairID] = TIME_OPERATE_CARD;
		} 
		else
		{
			m_opterPassTimeArr[wChairID] = 6;
		}
	}
	
	return true;
}

bool CTableFrameSink::OnActionUserReConnect(WORD wChairID, IServerUserItem * pIServerUserItem)
{
	m_bAutoStustee[wChairID] = false;
	m_bPlayerOffLine[wChairID] = false;
	if (m_wCurrentUser == wChairID)
	{
		//m_opterPassTimeArr[wChairID] = TIME_OPERATE_CARD;
		if (m_pGameServiceOption->wGameZoneType==em_zoneType_zhuangJin)
		{
			m_opterPassTimeArr[wChairID] = TIME_OPERATE_CARD_ZIJIAN;
		} 
		else
		{
			m_opterPassTimeArr[wChairID] = TIME_OPERATE_CARD;
		}
	}
	return true;
}
CString CTableFrameSink::GetPlayerName(int nChairID)
{
	CString strRes = "";

	if (nChairID > -1 && nChairID < 4)
	{
		IServerUserItem *pServerUserItem = m_pITableFrame->GetServerUserItem(nChairID);
		if (pServerUserItem != NULL)
		{
			strRes.Format("(Name:%s,TableId:%d,ChairID:%d)", pServerUserItem->GetNickName(), pServerUserItem->GetTableID(), nChairID);
		}
	}	

	return strRes;
}
//发送解散倒计时
bool CTableFrameSink::SendJieSanTime()
{
	int selectCount = 0;
	for (int i=0;i<GAME_PLAYER;i++)
	{
		if (m_bSelectDisMiss[i])
		{
			selectCount++;
		}
	}
	if (selectCount>=1 && selectCount<=3)
	{
		m_JieSanTime--;
		CMD_S_JIESANTIME pJieSanTime;
		ZeroMemory(&pJieSanTime,sizeof(pJieSanTime));
		pJieSanTime.cbTime = m_JieSanTime;
		m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_JIESANTIME,&pJieSanTime,sizeof(pJieSanTime));
	}
	else
	{
		m_JieSanTime = TIME_JIESAN_LEN;
	}
	if (m_JieSanTime<=0)
	{
		CMD_S_DisMissRoom cDisMissroom;
		ZeroMemory(&cDisMissroom,sizeof(cDisMissroom));
		cDisMissroom.bDisMiss = true;
		cDisMissroom.bDisMissRoom = true;
		m_bGameOver = true;
		CopyMemory(cDisMissroom.nHuScore,m_AllHuTime,sizeof(cDisMissroom.nHuScore));
		CopyMemory(cDisMissroom.nMingGangScore,m_AllMingGangTime,sizeof(cDisMissroom.nMingGangScore));
		CopyMemory(cDisMissroom.nAnGangScore,m_AllAnGangTime,sizeof(cDisMissroom.nAnGangScore));
		CopyMemory(cDisMissroom.nFanGangScore,m_AllFanGangTime,sizeof(cDisMissroom.nFanGangScore));
		CopyMemory(cDisMissroom.nJieGangScore,m_AllJieGangTime,sizeof(cDisMissroom.nJieGangScore));
		CopyMemory(cDisMissroom.nZhongMaScore,m_AllZhongMaCount,sizeof(cDisMissroom.nZhongMaScore));
		CopyMemory(cDisMissroom.nWinScore,m_AllWinScore,sizeof(cDisMissroom.nWinScore));

		ZeroMemory(m_bDisMiss,sizeof(m_bDisMiss));
		ZeroMemory(m_bSelectDisMiss,sizeof(m_bSelectDisMiss));
		m_pITableFrame->SendTableData(INVALID_CHAIR,SUB_S_DISMISSROOM, &cDisMissroom, sizeof(cDisMissroom));
		if (m_bGameOver)
		{
			bool isFanHuanFangKa = false;
			if (m_cbHavePlayCount<=0)
			{
				isFanHuanFangKa = true;
			}
			m_RoomNum=0;
			m_MaShu = 0;
			m_cbHavePlayCount = 0;
			m_cbPlayJushu = 0;	
			m_wRequestChairID = INVALID_CHAIR;
			//m_pITableFrame->ConcludeZiJian(isFanHuanFangKa);
			m_pITableFrame->ConcludeGame(1111);
		}
		return true;
	}
	return true;
}
CString CTableFrameSink::getCString(WORD Action)
{
	CString str = "";
	CString tmpstr = "";
	if ((Action&WIK_LEFT)!=0 || (Action&WIK_CENTER)!=0 ||(Action&WIK_RIGHT)!=0)
	{
		tmpstr.Format(TEXT("%s"),"吃");
		str = str + tmpstr;
	}
	if ((Action&WIK_PENG)!=0 )
	{
		tmpstr.Format(TEXT("%s"),"碰");
		str = str + tmpstr;
	}
	if ((Action&WIK_GANG)!=0 )
	{
		tmpstr.Format(TEXT("%s"),"杠");
		str = str + tmpstr;
	}
	if ((Action&WIK_CHI_HU)!=0 )
	{
		tmpstr.Format(TEXT("%s"),"胡");
		str = str + tmpstr;
	}
	if (Action == WIK_NULL)
	{
		tmpstr.Format(TEXT("%s"),"无");
		str = str + tmpstr;
	}
	return str;
}
//设置是否能查听
void CTableFrameSink::SetChaTingCard(BYTE wChairID,bool IsSendcard)
{
	//是否能查听
	BYTE dwChiHuRight=0;	
	ZeroMemory(&m_ChaTingCardArray,sizeof(m_ChaTingCardArray));
	tagChiHuData chiHuTmp= getChiHuData();
	m_cbChaTing = m_GameLogic.AnalyseChaTingCard(m_cbCardIndex[wChairID],m_ChaTingCardArray,m_WeaveItemArray[wChairID],m_cbWeaveItemCount[wChairID],dwChiHuRight,0,IsSendcard,chiHuTmp);
	//获取对应胡牌剩余的个数
	if (m_cbChaTing)
	{			
		for (int i=0;i<m_ChaTingCardArray.cbDisCount;i++)
		{
			for (int j=0;j<m_ChaTingCardArray.cbHuCount[i];j++)
			{
				m_ChaTingCardArray.cbHupaiLessCount[i][j]=4;
			}
		}
		for (int i=0;i<GAME_PLAYER;i++)
		{
			BYTE viewID = i;//SwitchViewChairID(i);
			GetDisCardLessCount(m_cbDiscardCard[i],m_cbDiscardCount[i],m_WeaveItemArray[i],m_cbWeaveItemCount[i],m_ChaTingCardArray,IsSendcard);
			if (i==wChairID)
			{
				for (int j=0;j<m_ChaTingCardArray.cbDisCount;j++)
				{
					for (int k=0;k<m_ChaTingCardArray.cbHuCount[j];k++)
					{
						if(m_ChaTingCardArray.cbCardData[j][k]==0) continue;
						BYTE cbwHupaiindex = m_GameLogic.SwitchToCardIndex(m_ChaTingCardArray.cbCardData[j][k]);
						if (m_cbCardIndex[cbwHupaiindex]!=0)
						{
							m_ChaTingCardArray.cbHupaiLessCount[j][k] -= m_cbCardIndex[i][cbwHupaiindex];
						}
						for (int m=0;m<m_cbWeaveItemCount[i];m++)//自己暗杠的组合牌
						{
							if (m_WeaveItemArray[i][m].cbCenterCard==m_ChaTingCardArray.cbCardData[j][k])
							{
								if(m_WeaveItemArray[i][m].cbWeaveKind==WIK_GANG&&m_WeaveItemArray[i][m].cbPublicCard==false)//自己暗杠
								{							
									m_ChaTingCardArray.cbHupaiLessCount[j][k] = 0;
								}
							}
						}
					}
				}
			}
		}		
	}
}

//获取丢弃的牌剩余的个数
void CTableFrameSink::GetDisCardLessCount(const BYTE cbCardData[], BYTE wCardCount,tagWeaveItem m_cWeaveItemArray[],BYTE cbWeaveCount,tagChaTingItem &ChaTingCardArray,bool IsSendcard)
{
	if (IsSendcard==false) //打出牌后
	{
		for (int j=0;j<ChaTingCardArray.cbHuCount[0];j++)
		{
			BYTE cbwHupaiDate = ChaTingCardArray.cbCardData[0][j];
			for (int m=0;m<wCardCount;m++)//弃牌
			{
				BYTE disCardDate = cbCardData[m];
				if (cbwHupaiDate==disCardDate)
				{
					ChaTingCardArray.cbHupaiLessCount[0][j] -= 1;
				}							
			}	
			for (int m=0;m<cbWeaveCount;m++)//组合牌
			{
				if (m_cWeaveItemArray[m].cbCenterCard==cbwHupaiDate)
				{
					if(m_cWeaveItemArray[m].cbWeaveKind==WIK_PENG)
					{
						ChaTingCardArray.cbHupaiLessCount[0][j] -= 3;
					}
					else if(m_cWeaveItemArray[m].cbWeaveKind==WIK_GANG&&m_cWeaveItemArray[m].cbPublicCard)
					{							
						ChaTingCardArray.cbHupaiLessCount[0][j] = 0;
					}
				}
				if (m_cWeaveItemArray[m].cbWeaveKind==WIK_LEFT)
				{
					if (m_cWeaveItemArray[m].cbCenterCard == cbwHupaiDate || (m_cWeaveItemArray[m].cbCenterCard+1) == cbwHupaiDate || (m_cWeaveItemArray[m].cbCenterCard+2) == cbwHupaiDate)
					{
						ChaTingCardArray.cbHupaiLessCount[0][j] -= 1;
					}
				} 
				else if (m_cWeaveItemArray[m].cbWeaveKind==WIK_CENTER)
				{
					if (m_cWeaveItemArray[m].cbCenterCard == cbwHupaiDate || (m_cWeaveItemArray[m].cbCenterCard-1) == cbwHupaiDate || (m_cWeaveItemArray[m].cbCenterCard+1) == cbwHupaiDate)
					{
						ChaTingCardArray.cbHupaiLessCount[0][j] -= 1;
					}
				}
				else if (m_cWeaveItemArray[m].cbWeaveKind==WIK_RIGHT)
				{
					if (m_cWeaveItemArray[m].cbCenterCard == cbwHupaiDate || (m_cWeaveItemArray[m].cbCenterCard-1) == cbwHupaiDate || (m_cWeaveItemArray[m].cbCenterCard-2) == cbwHupaiDate)
					{
						ChaTingCardArray.cbHupaiLessCount[0][j] -= 1;
					}
				}
				/*else if (m_cWeaveItemArray[m].cbWeaveKind==WIK_SPE_FENGGANG || m_cWeaveItemArray[m].cbWeaveKind==WIK_SPE_BAIGANG)
				{
					for (int k=0;k<5;k++)
					{
						if (m_cWeaveItemArray[m].cbCarddata[k] == cbwHupaiDate)
						{
							ChaTingCardArray.cbHupaiLessCount[0][j] -= 1;
						}
					}
				}*/
			}
		}
	} 
	else //选择打牌时
	{
		for (int i=0;i<ChaTingCardArray.cbDisCount;i++)
		{
			for (int j=0;j<ChaTingCardArray.cbHuCount[i];j++)
			{
				BYTE cbwHupaiDate = ChaTingCardArray.cbCardData[i][j];
				for (int m=0;m<wCardCount;m++)//弃牌
				{
					BYTE disCardDate = cbCardData[m];
					if (cbwHupaiDate==disCardDate)
					{
						ChaTingCardArray.cbHupaiLessCount[i][j] -= 1;
					}							
				}	
				for (int m=0;m<cbWeaveCount;m++)//组合牌
				{
					if (m_cWeaveItemArray[m].cbCenterCard==cbwHupaiDate)
					{
						if(m_cWeaveItemArray[m].cbWeaveKind==WIK_PENG)
						{
							ChaTingCardArray.cbHupaiLessCount[i][j] -= 3;
						}
						else if(m_cWeaveItemArray[m].cbWeaveKind==WIK_GANG&&m_cWeaveItemArray[m].cbPublicCard)
						{							
							ChaTingCardArray.cbHupaiLessCount[i][j] = 0;
						}
					}
					if (m_cWeaveItemArray[m].cbWeaveKind==WIK_LEFT)
					{
						if (m_cWeaveItemArray[m].cbCenterCard == cbwHupaiDate || (m_cWeaveItemArray[m].cbCenterCard+1) == cbwHupaiDate || (m_cWeaveItemArray[m].cbCenterCard+2) == cbwHupaiDate)
						{
							ChaTingCardArray.cbHupaiLessCount[i][j] -= 1;
						}
					} 
					else if (m_cWeaveItemArray[m].cbWeaveKind==WIK_CENTER)
					{
						if (m_cWeaveItemArray[m].cbCenterCard == cbwHupaiDate || (m_cWeaveItemArray[m].cbCenterCard-1) == cbwHupaiDate || (m_cWeaveItemArray[m].cbCenterCard+1) == cbwHupaiDate)
						{
							ChaTingCardArray.cbHupaiLessCount[i][j] -= 1;
						}
					}
					else if (m_cWeaveItemArray[m].cbWeaveKind==WIK_RIGHT)
					{
						if (m_cWeaveItemArray[m].cbCenterCard == cbwHupaiDate || (m_cWeaveItemArray[m].cbCenterCard-1) == cbwHupaiDate || (m_cWeaveItemArray[m].cbCenterCard-2) == cbwHupaiDate)
						{
							ChaTingCardArray.cbHupaiLessCount[i][j] -= 1;
						}
					}
					/*else if (m_cWeaveItemArray[m].cbWeaveKind==WIK_SPE_FENGGANG || m_cWeaveItemArray[m].cbWeaveKind==WIK_SPE_BAIGANG)
					{
						for (int k=0;k<5;k++)
						{
							if (m_cWeaveItemArray[m].cbCarddata[k] == cbwHupaiDate)
							{
								ChaTingCardArray.cbHupaiLessCount[i][j] -= 1;
							}
						}
					}*/
				}
			}
		}
	}
}

// 设置跟庄
void CTableFrameSink::setFollowBank(bool isFollowBanks)
{
	if (isFollowBanks && m_nFollowBank > 0)
	{
		++m_wFollowBankCount;
	}
}

// 设置种牌的数据
void CTableFrameSink::setZhongPaiData(const BYTE wNextZhongPaiCardData)
{
	if (!m_LaiZi)
	{
		m_tZhongPaiData.m_cbCurrentZhongPaiCardData = INVALID_BYTE;
		m_tZhongPaiData.m_preZhongPaiCardData = INVALID_BYTE;
		m_tZhongPaiData.m_cbZhonePaiCount = 1;
	}
	if(m_tZhongPaiData.m_cbCurrentZhongPaiCardData == wNextZhongPaiCardData)
	{
		++m_tZhongPaiData.m_cbZhonePaiCount;
	}
	else
	{
		m_tZhongPaiData.m_cbZhonePaiCount = 1;
	}
	m_tZhongPaiData.m_preZhongPaiCardData = m_tZhongPaiData.m_cbCurrentZhongPaiCardData;
	if(DEF_TEST)
	{
		m_tZhongPaiData.m_cbCurrentZhongPaiCardData = 0x05;//wNextZhongPaiCardData;
	}
	else
	{
		m_tZhongPaiData.m_cbCurrentZhongPaiCardData = wNextZhongPaiCardData;	
	}
	//m_tZhongPaiData.m_cbCurrentZhongPaiCardData = wNextZhongPaiCardData;
}

// 计算如果有种牌就算出种牌的数值
void CTableFrameSink::getZhongPaiCardData()
{
	int total = m_wSiceCount + m_wSiceCount2;
	setZhongPaiData(m_cbRepertoryCard[total]);
}

// 是否跟庄
bool CTableFrameSink::IsFollowBank()const
{
	// 跟庄标志为TRUE，并且不能为天胡或地胡
	if (m_nFollowBankFlag)
	{
		return true;
	}

	return false;
}
