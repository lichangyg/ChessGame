﻿#ifndef TABLE_FRAME_SINK_HEAD_FILE
#define TABLE_FRAME_SINK_HEAD_FILE

#pragma once

#include "Stdafx.h"
#include "GameLogic.h"
#include <vector>
//////////////////////////////////////////////////////////////////////////
//枚举定义

//效验类型
enum enEstimatKind
{
	EstimatKind_OutCard,			//出牌效验
	EstimatKind_GangCard,			//杠牌效验
};

//////////////////////////////////////////////////////////////////////////

//游戏桌子类
class CTableFrameSink : public ITableFrameSink, public ITableUserAction
{
	//游戏变量
protected:
	WORD							m_wSiceCount;							//骰子点数
	WORD							m_wSiceCount2;							//骰子点数2
	WORD							m_wBankerUser;							//庄家用户
	WORD							m_wFollowBankCount;						// 跟庄次数
	WORD							m_wNextBankerUser;						//下局庄家用户
	WORD							m_wlastUser;							//拿最后一张牌用户
	tagZhonePaiData					m_tZhongPaiData;						// 种牌的数据
	bool							m_bFirstHuUser;							//是否第一个胡牌玩家
	LONG							m_lGameScore[GAME_PLAYER];				//游戏得分
	BYTE							m_cbQueMen[GAME_PLAYER];				//缺少花色
	bool							m_bPiaoQi[GAME_PLAYER];					//是否漂起
	bool							m_bPiaoQiHupai[GAME_PLAYER];			//是否漂起胡牌
	bool							m_bCanSelQuemen;
	bool							m_bPiaoQiHasSel[GAME_PLAYER];	
	bool							m_bCanSelChangCard;
	bool							m_bChangCardHasSel[GAME_PLAYER];
	BYTE							m_cbCardIndex[GAME_PLAYER][MAX_INDEX];	//用户扑克
	bool							m_bTrustee[GAME_PLAYER];							//是否托管
	BYTE							m_bBeginOutCard[GAME_PLAYER];			//首次出过牌用户标志
	bool							m_bTianDiHupai[GAME_PLAYER];			//天胡地胡用户标志
	bool							m_bDiHupai;								//是否地胡用户标志
	bool							m_bTianHupai;							//是否天胡用户标志
	bool							m_bIsGangKai;							// 是否杠上开花
	//选择换牌变量
	bool							m_bChangCard[GAME_PLAYER];				//是否换牌
	BYTE							m_bChangCardDate[GAME_PLAYER][MAX_CHANG];//各玩家选择需要换的牌
	BYTE							m_bChangCardCount[GAME_PLAYER];			//总共需要换牌的个数
	BYTE							m_bChangCardCountAll;					//总共需要换牌的个数
	BYTE							m_bChangDate[12];					//各玩家选择需要换的牌
	int								m_MahJongMultipleFan;				//封顶番数
	int								m_bMahJongMultipleFan[GAME_PLAYER]; //各玩家封顶番数
	
	//牌局变量
	DWORD                           m_dwStartTime;
	DWORD                           m_dwEndTime;
	TCHAR							m_recordID[40];		//	记录ID
	TCHAR                           m_tcAccount[300];
	TCHAR                           m_tcOriginCards[300];
	TCHAR                           m_tcRecord[4000];
	bool							m_cbGameIsEnd;						//游戏是否结束
	bool							m_bGoodCard;
	DWORD                           StartTableID;
	DWORD                           EndTableID;
	//出牌信息
protected:
	WORD							m_wOutCardUser;							//出牌用户
	BYTE							m_cbOutCardData;						//出牌扑克
	BYTE							m_cbOutCardCount;						//出牌数目
	BYTE							m_cbDiscardCount[GAME_PLAYER];			//丢弃数目
	BYTE							m_cbDiscardCard[GAME_PLAYER][20];		//丢弃记录
	BYTE							m_cbBaopai;								//宝牌
	//胡牌信息
protected:	
	bool                            m_bPlayerStatus[GAME_PLAYER];           //是否已经胡牌
	BYTE							m_cPlaySequenceHu[GAME_PLAYER];			//玩家胡牌顺序
	BYTE							m_cbHasHuCardData[GAME_PLAYER][MAX_COUNT];	//玩家胡牌后的数据
	BYTE							m_cbHuCardData[GAME_PLAYER];			//胡的那个牌
	BYTE							m_bHupaiType[GAME_PLAYER];			//胡牌类型(自摸胡牌未胡未听)

	LONG							lGameScore_all[GAME_PLAYER];			//游戏总积分
	LONG							lGameScore[GAME_PLAYER];				//自己胡牌得到的积分
	LONG							lGameScore_other[GAME_PLAYER][GAME_PLAYER];	//自己与其他玩家之间的积分
	BYTE							m_bHupaiTypeRight[GAME_PLAYER];		//胡牌类型(自摸胡牌未胡未听听牌花猪)
	DWORD							m_bHupaiKindName[GAME_PLAYER];			//胡牌类型名字
	DWORD							dwChiHuRight[GAME_PLAYER];			//胡牌类型
	BYTE							m_bHupaiZongfan[GAME_PLAYER];			//胡牌总番数
	LONG							lGameGangScore[GAME_PLAYER];			//游戏杠积分

	BYTE							m_bUserGangCount[GAME_PLAYER];		//杠牌数据
	BYTE							m_bUserGenCount[GAME_PLAYER];		//根的数据

	BYTE							m_bGangKai[GAME_PLAYER];			//杠上花
	BYTE							m_bGangPao[GAME_PLAYER];			//杠上炮
	BYTE							m_bGangHu[GAME_PLAYER];				//枪杠胡

	bool							m_bHaidiPao;						//海底炮
	bool							m_bHaidilao;						//海底捞
	bool							m_bisHZLaiZi;						// 是否红中癞子

	BYTE							m_bGangCount;							 //杠牌数据
	long							m_GangCount[GAME_PLAYER];				 //每次杠牌分数
	long							m_GangCountscore[GAME_PLAYER];			 //每次杠牌分数
	long							m_GangWinscore[GAME_PLAYER][GAME_PLAYER];//每次杠牌获得分数
	long							m_lPiaoQiscore[GAME_PLAYER];			 //玩家飘起的分数
	long							m_lJiadiScore[GAME_PLAYER];			//自摸加底的分数


	BYTE							m_cPlayHuCount;							//胡牌玩家的个数
	bool							m_bChaHuazhu[GAME_PLAYER];				//查花猪标志
	bool							m_bChaDajiao[GAME_PLAYER];				//查大叫标志
	WORD							m_cbWinMax[GAME_PLAYER];				//查大叫听牌获得的最大番

	bool							m_cbHupaiIndex[GAME_PLAYER];		//同时胡牌玩家
	BYTE							m_cbHupaiCount;						//同时胡牌玩家数
	BYTE							m_cbGameHuCount ;					//一炮多响
	BYTE							m_cbGameEndCount ;
	BYTE							m_cbHupaiOperateCount;						//一炮多响胡牌玩家数操作返回数
	bool							m_bOtherOperate;					//胡牌时，有另外的操作
	bool                            m_bPlayerNotHu[GAME_PLAYER];           //玩家能胡操作放弃
	//bool							m_cbOperateOther;					//是否同时有玩家操作
	//发牌信息
protected:
	BYTE							m_cbSendCardData;						//发牌扑克
	//BYTE							m_cbAICardColorCount;
	BYTE							m_cbSendCardCount;						//发牌数目
	BYTE							m_cbLeftCardCount;						//剩余数目
	BYTE							m_cbGetFinalyIndex;					//尾部去了几张
	WORD							m_cbfirstIndex;						//第一胡牌玩家
	WORD							m_cbscendIndex;						//第二胡牌玩家

	
	BYTE							m_cbRepertoryCard[MAX_REPERTORY];		 //库存扑克
	
	bool							m_bHasSendLastCard;						//是否已经发了最后一张牌
	bool							m_bHasChangCardend;						//已经换牌发送接束
	bool							m_bHasSendHuCard;						//有人胡牌后，已经重新发牌
	bool							m_bHasDingQue;							//定缺是否已经结束

	bool							m_baoTingstart;							//报听开始
	bool							m_baoTingend;							//报听结束
	BYTE							m_baoTingcount;							//当局总共报听的个数
	BYTE							m_bhasbaoting;							//已经报听
	//运行变量
protected:
	WORD							m_wResumeUser;							//还原用户
	WORD							m_wCurrentUser;							//当前用户
	WORD							m_wProvideUser;							//供应用户
	BYTE							m_cbProvideCard;						//供应扑克
	WORD							m_wLastOutcardUser;						//当次出牌用户

	//状态变量
protected:
	bool							m_bSendStatus;							//发牌状态
	bool							m_bGangStatus;							//抢杆状态
	bool							m_bEnjoinChiHu[GAME_PLAYER];			//禁止吃胡
	bool							m_bEnjoinChiPeng[GAME_PLAYER];			//禁止吃碰(听牌标记)									
	bool							m_bCanBuGang[GAME_PLAYER];				//能否补杠
	bool							m_bFirstChangeBao[GAME_PLAYER];				//是否第一次换宝
	bool							m_bFirstLookBao[GAME_PLAYER];				//是否第一次看宝
	bool							m_bCanLookBao[GAME_PLAYER];				//是否看宝
	bool							m_islookBaopai;							//是否有人看了宝牌
	bool							m_bFirstListen;
	bool							m_bFengZhang;							//是否分张
	BYTE							m_cbFengZhangCard[GAME_PLAYER];			//操作扑克
	bool							m_bStartAinFinish;						//客户端动画结束
	bool							m_bKaimen[GAME_PLAYER];					//开门标志
	bool							m_bEnjoinPeng[GAME_PLAYER][MAX_INDEX];			//控制是否可以碰
	bool							m_bEnjoinChiHuIndex[GAME_PLAYER][MAX_INDEX];			//控制是否可以吃胡
	//用户状态
public:
	bool							m_bResponse[GAME_PLAYER];				//响应标志
	WORD							m_cbUserAction[GAME_PLAYER];			//用户动作
	BYTE							m_cbOperateCard[GAME_PLAYER];			//操作扑克
	WORD							m_cbPerformAction[GAME_PLAYER];			//执行动作

	static LONG					m_LRoomAllUserNKuCun;	//	玩家实际总输赢库存积分
	static LONG					m_LRoomInitNKuCun;		//	玩家实际总输赢库存设定积分
	static TCHAR           		m_szIniFileName[MAX_PATH];	//
	int							m_iGoodCardPercent;		//AI好牌概率
	int							m_AmendPercent;		//概率修正值

	bool							m_bNeedWin[GAME_PLAYER];
	bool							m_bNeedLost[GAME_PLAYER];
	int								m_goodcardTime[GAME_PLAYER];//造牌Index
	int								m_lastgoodTime[GAME_PLAYER];//上次造牌Index
	//组合扑克
protected:
	BYTE							m_cbWeaveItemCount[GAME_PLAYER];		//组合数目
	tagWeaveItem					m_WeaveItemArray[GAME_PLAYER][MAX_WEAVE];//玩家已经吃，碰，杠的牌
	tagOutCardItem					m_OutCardItemArray;				//前3个玩家出的扑克
	//结束信息
protected:
	BYTE							m_cbChiHuCard;							//吃胡扑克
	tagChiHuResult					m_ChiHuResult[GAME_PLAYER];				//吃胡结果

	//组件变量
protected:
	CGameLogic						m_GameLogic;							//游戏逻辑
	ITableFrame						* m_pITableFrame;						//框架接口
	const tagGameServiceOption		* m_pGameServiceOption;					//配置参数

	//自动托管
protected:
	BYTE							m_bAutoStustee[GAME_PLAYER];		//是否自动托管
	bool							m_bPlayerOffLine[GAME_PLAYER];			//玩家离线状态
	int							m_opterPassTimeArr[GAME_PLAYER];
	BYTE							m_cbLastSendCardData;						//最近的发的牌
	BYTE							m_cbTheLastSendCardData;			//开始发牌时发给庄家最后的那张牌
	int								m_bServerTableID;					//服务桌子
	//掉落物品
	int m_gamePassSecond;
	bool m_bDropGoodThisTurn;

	//补杠 抢杠
	bool			m_bQiangGang;
	bool			m_bQiangGangHu;								//是否枪杆胡
	bool			m_bGangStatusOutcard;						//杠牌，补牌后打出的牌
	bool			m_bGangShangPao;							//是否杠上炮
	BYTE			m_cbQiangGangCardData;						//抢杠的牌
	BYTE			m_cbQiangGangUserID;						//被抢杠的人
	WORD			m_cbQiangGangOpterate;						//被抢杠的操作
	bool			m_bQiangGangCancel;						    //抢杠取消
	bool			m_bIsNoHaveQuemen;					        //没有缺门的牌

	LONG			m_RoomBasicScore;                       //底分/底注
	//宝牌	
	bool			m_bGetCardHead;
	int			m_baoPaiStartIndex;						//宝牌随机的开始位置
	int			m_baoPaiRandVal;							//宝牌随机数
	int			m_baoPaiCardIndex;							//宝牌在牌墙的位置
	std::vector<int>	m_baoPaiRandIndexArr;						//宝牌可以随机的位置(0-5)
	void ResetBaoPaiIndexArr(BYTE addCardData = 0);								//重新获取随机数据
	void GetBaoPai();										//重新换宝牌
	bool HuanBao1();

	int	HasOutCardCout(BYTE cbCardData);					//判断已经出了多少张牌

	void RandChangCardData(BYTE cbCardData[], BYTE cbMaxCount);
	//制造AI好牌
	void GetGoodCardData(BYTE cbCardData[]);
	//发送开始信息
	void SendStartGameCard();
	//派发庄家最后一个扑克
	void DispatchLastCardData();
	//判断是否过水不胡
	bool AnalyseChiHuResult(WORD wCurrentUser,WORD wOutCardUser,tagOutCardItem  &w_OutCardItemArray/*,bool w_bChiHuAddFan*/);
	//测试修改牌
	void AddTestCard(WORD wChairID, BYTE cbCardData);

	// 检测是否可以自摸玩法
	bool checkZiMo(DWORD dwChiHuKing);

	// 检测是否是鸡胡玩法
	bool checkJiHuWangFa()const;
	
	// 获取吃胡所需要的数据结构数据
	tagChiHuData getChiHuData()const;

	// 是否为大胡
	bool checkChiHuDaHu(DWORD dwChiHuKing);
	//钓鱼
	bool m_bCanSelDiaoYu;
	int m_lDiaoYuTimes[GAME_PLAYER];
	bool m_bDiaoYuHasSel[GAME_PLAYER];
	bool m_bLastFourCard;						//是剩下最后4张牌
	int						m_RoomNum;				//房间号
	int						m_LaiZi;				// 癞子标志
	int						m_nHaiDiLaoYueTwo;					// 是否海底捞月2番
	int						m_nDiHuTwo;							// 是否地2番
	int						m_nFollowBank;						// 是否跟庄
	int						m_nZhonePai;							// 是否有种牌
	bool					m_isZiMo;				// 是否自摸
	int						m_MaShu;				//扎码数
	BYTE					m_cbPlayJushu;			//创建的房间设定玩的局数
	BYTE					m_cbHavePlayCount;			//创建的房间已经玩的局数
	int						m_cbZhaMaCount;				//抓马的数目
	int						m_ZhongMaCount;				//中马的数目
	DWORD					m_nOwnerUserID;			//玩家房主的椅子号
	WORD					m_wRequestChairID;		//申请解散房间用户
	int						m_nLessTime;			//剩余解散房间时间
	bool					m_bIsLastGang;			//标志没用牌前是否为杠
	int						m_iRecordLastGangChairId;	// 上一次抢杠的供牌桌子

	BYTE					m_cbZhaMaCardData[MAX_ZhaMaNum]; //扎码牌值
	bool					m_bZhongZhaMa[MAX_ZhaMaNum];	//是否中码

	int						m_AllHuTime[GAME_PLAYER];				//总胡牌次数
	int						m_AllMingGangTime[GAME_PLAYER];			//总公杠次数
	int						m_AllAnGangTime[GAME_PLAYER];			//总暗杠次数
	int						m_AllFanGangTime[GAME_PLAYER];		//总放接杠次数
	int						m_AllJieGangTime[GAME_PLAYER];		//总放接杠次数
	int						m_AllZhongMaCount[GAME_PLAYER];			//总中码个数

	int						m_HuScore[GAME_PLAYER];						//每局胡牌分数
	int						m_MingGangScore[GAME_PLAYER];				//每局公杠（明杠）分数
	int						m_AnGangScore[GAME_PLAYER];					//每局暗杠分数
	int						m_FanJieGangScore[GAME_PLAYER];				//每局放/接杠分数
	int						m_ZhongMaScore[GAME_PLAYER];				//每局中码分数
	int						m_WinScore[GAME_PLAYER];					//每局总计分数

	int						m_zhongScore[GAME_PLAYER];					// 每局的种分

	int						m_FollowZhongScore[GAME_PLAYER];					// 每局的跟庄分
	int						m_AllFollowCount[GAME_PLAYER];				// 被跟庄的次数

	int						m_AllHuScore[GAME_PLAYER];					//每局胡牌分数
	int						m_AllMingGangScore[GAME_PLAYER];			//每局公杠（明杠）分数
	int						m_AllAnGangScore[GAME_PLAYER];				//每局暗杠分数
	int						m_AllFanJieGangScore[GAME_PLAYER];			//每局放/接杠分数
	int						m_AllZhongMaScore[GAME_PLAYER];				//每局中码分数
	int						m_AllWinScore[GAME_PLAYER];					//每局总计分数

	BYTE					m_cbDisCount;								//剩余没出的牌的个数
	BYTE					m_cbDisData[60];							//剩余没出的牌值
	bool                    m_bGameOver;								//房间游戏是否结束，需解散房间
	bool					m_bDisMiss[GAME_PLAYER];					//是否请求解散房间
	bool					m_bSelectDisMiss[GAME_PLAYER];				//是否已选择请求解散房间
	int						m_JieSanTime;								//解散时间
	tagChaTingItem			m_ChaTingCardArray;
	bool					m_cbChaTing;						//是否能查听
	BYTE					m_bLastGangByte;					//上一次抢杠的类型

	bool					m_nFollowBankFlag;					// 标志是否可以继续计算跟庄
	BYTE					m_nFollowCardData;				// 庄家出的第一张牌的牌数据
	//属性变量
protected:
	static const WORD				m_wPlayerCount;							//游戏人数
	static const enStartMode		m_GameStartMode;						//开始模式

	//税率表
	WORD GetTaxRation(LONG lScore, DWORD dwBasicScore);

	void SendCard();

	bool HasQiangGang(WORD wChairID, WORD cbOperateCode, BYTE cbOperateCard,BYTE bGangType);

	WORD HasSpeGang(WORD wChairID, BYTE cbOperateCard);

	void FengZhang();			//分张发牌

	bool OnFengZhangOperateCard(WORD wChairID, WORD cbOperateCode, BYTE cbOperateCard);

	CString GetPlayerName(int nChairID);
	//函数定义
public:
	//构造函数
	CTableFrameSink();
	//析构函数
	virtual ~CTableFrameSink();

	//基础接口
public:
	//释放对象
	virtual VOID __cdecl Release() { }
	//是否有效
	virtual bool __cdecl IsValid() { return AfxIsValidAddress(this,sizeof(CTableFrameSink))?true:false; }
	//接口查询
	virtual void * __cdecl QueryInterface(const IID & Guid, DWORD dwQueryVer);

	//管理接口
public:
	//初始化
	virtual bool __cdecl InitTableFrameSink(IUnknownEx * pIUnknownEx);
	//复位桌子
	virtual void __cdecl RepositTableFrameSink();

	//信息接口
public:
	//开始模式
	virtual enStartMode __cdecl GetGameStartMode();
	//游戏状态
	virtual bool __cdecl IsUserPlaying(WORD wChairID);

	//游戏事件
public:
	//游戏开始
	virtual bool __cdecl OnEventGameStart();
	//游戏结束
	virtual bool __cdecl OnEventGameEnd(WORD wChairID, IServerUserItem * pIServerUserItem, BYTE cbReason);
	//发送场景
	virtual bool __cdecl SendGameScene(WORD wChiarID, IServerUserItem * pIServerUserItem, BYTE cbGameStatus, bool bSendSecret);

	//事件接口
public:
	//定时器事件
	virtual bool __cdecl OnTimerMessage(WORD wTimerID, WPARAM wBindParam);
	//游戏消息处理
	virtual bool __cdecl OnGameMessage(WORD wSubCmdID, const void * pDataBuffer, WORD wDataSize, IServerUserItem * pIServerUserItem);
	//框架消息处理
	virtual bool __cdecl OnFrameMessage(WORD wSubCmdID, const void * pDataBuffer, WORD wDataSize, IServerUserItem * pIServerUserItem);

	//用户事件
public:
	//用户断线
	virtual bool __cdecl OnActionUserOffLine(WORD wChairID,IServerUserItem * pIServerUserItem);
	//用户重入
	virtual bool __cdecl OnActionUserReConnect(WORD wChairID,IServerUserItem * pIServerUserItem);
	//用户坐下
	virtual bool __cdecl OnActionUserSitDown(WORD wChairID,IServerUserItem * pIServerUserItem, bool bLookonUser);
	//用户起立
	virtual bool __cdecl OnActionUserStandUp(WORD wChairID,IServerUserItem * pIServerUserItem, bool bLookonUser);
	//用户同意
	virtual bool __cdecl OnActionUserReady(WORD wChairID,IServerUserItem * pIServerUserItem, void * pData, WORD wDataSize) { return true; }
	//用户强退
	virtual bool __cdecl OnActionUserLeft(WORD wChairID, IServerUserItem * pIServerUserItem);

	
	//游戏事件
protected:
	//用户听牌
	bool OnUserListenCard(WORD wChairID,bool wbListen);
	//用户出牌
	bool OnUserOutCard(WORD wChairID, BYTE cbCardData);
	//用户操作
	bool OnUserOperateCard(WORD wChairID, WORD cbOperateCode, BYTE cbOperateCard);

	//辅助函数
protected:
	void ReadConfig();
	//发送操作
	bool SendOperateNotify();
	//发送报听
	bool SendBaoTingNotify();
	//玩家胡牌
	bool OnEventHupai(WORD wChairID, IServerUserItem * pIServerUserItem);
	//派发扑克
	bool DispatchCardData(WORD wCurrentUser, bool bGetHand = true);
	//派发庄家最后一个扑克
	bool DispatchLastCardData(WORD wCurrentUser,bool bGetHand = true);
	//响应判断
	bool EstimateUserRespond(WORD wCenterUser, BYTE cbCenterCard, enEstimatKind EstimatKind);
	//宝牌设定
	void Baopai(BYTE cIndex, BYTE addCard = 0);
	//混乱扑克
	void RandCardData(BYTE cbCardData[]);
	//修改混乱扑克
	void RemakeRandCardData(BYTE cbCardData[MAX_REPERTORY], BYTE byCardIndex, BYTE &cbLeftCnt);
	void RemakeRandCardDatas(BYTE cbCardData[MAX_REPERTORY], BYTE byCardIndex[MAX_COUNT], BYTE &cbLeftCnt);
	//	三家闭
	bool bSanJiaBi(WORD wChairID);

	bool IsMenQing(WORD wChairID);		//是否门清
	//任务胡牌类型
	void TaskHuType(WORD wChairID,WORD cbOperateCode);
	//任务条件
	void TaskType(WORD wChairID,WORD cbOperateCode);
	//任务条件
	void TaskGangType(WORD wChairID,WORD dGangCount);

	WORD CheckCurrOperate(WORD wCurrentUser, BYTE cbSendCardData);

	int GetZhaMaCount(){ return m_MaShu;}
	int AddZhaMaData(BYTE cbCardIndex[MAX_INDEX],int wChairId,BYTE cbZhongMa[MAX_ZhaMaNum],bool isOneMa);
	// 赢的用户
	int getWinUser();
	//申请解散房间
	bool OnUserDisMissRoom(WORD wChairID,bool bdismiss);
	//发送解散倒计时
	bool SendJieSanTime();
	CString getCString(WORD Action);
	//设置是否能查听
	void SetChaTingCard(BYTE wChairID,bool IsSendcard);
	//获取丢弃的牌剩余的个数
	void GetDisCardLessCount(const BYTE cbCardData[], BYTE wCardCount,tagWeaveItem m_cWeaveItemArray[],BYTE cbWeaveCount,tagChaTingItem &ChaTingCardArray,bool IsSendcard);
	//取消杠
	//void GangCardQuexiao(tagGangCardResult GangCardResult,BYTE m_cbQueMen,WORD m_cbUserAction);

	// 设置跟庄
	void setFollowBank(bool isFollowBanks);

	// 设置种牌的数据
	void setZhongPaiData(const BYTE wNextZhongPaiCardData);

	// 是否海底捞月2番
	bool checkHaiDiLaoYue()const;
	// 是否地2番
	bool checkDiHu()const;
	// 是否跟庄
	bool checkFollowBank()const;
	// 是否有种牌
	bool checkZhongPai()const;

	// 计算如果有种牌就算出种牌的数值
	void getZhongPaiCardData();

	// 是否跟庄
	bool IsFollowBank()const;
};

//////////////////////////////////////////////////////////////////////////

#endif